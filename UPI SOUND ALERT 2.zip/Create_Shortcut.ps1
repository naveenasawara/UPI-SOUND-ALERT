
$WshShell = New-Object -ComObject WScript.Shell
$Shortcut = $WshShell.CreateShortcut("$([Environment]::GetFolderPath('Desktop'))\LedgerFlow.lnk")
$Shortcut.TargetPath = "$PSScriptRoot\Run_App.bat"
$Shortcut.WorkingDirectory = "$PSScriptRoot"
$Shortcut.IconLocation = "shell32.dll, 43" 
$Shortcut.Description = "Launch LedgerFlow Financial Management"
$Shortcut.Save()
Write-Host "------------------------------------------------" -ForegroundColor Cyan
Write-Host "LedgerFlow Desktop Shortcut Created Successfully!" -ForegroundColor Green
Write-Host "You can now launch the app directly from your desktop." -ForegroundColor Gray
Write-Host "------------------------------------------------" -ForegroundColor Cyan

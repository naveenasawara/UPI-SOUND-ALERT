"use client"

import { Customer, LedgerEntry } from "@/app/lib/types";
import { Sparkles, User, Check, Search } from "lucide-react";
import { cn, formatCurrency } from "@/lib/utils";

interface StylePreviewPaneProps {
  customer: Customer | null;
  entries: LedgerEntry[];
  activeCardStyle: string;
  activePattiDesign: string;
}

export function StylePreviewPane({ customer, entries, activeCardStyle, activePattiDesign }: StylePreviewPaneProps) {
  const sampleCustomer = {
    name: "Naveen Asawara",
    phone: "+91-9993440441",
    balance: 45000,
    lastActivity: "12 Mar 2024"
  };

  return (
    <div className="flex flex-col h-full bg-muted/10 overflow-hidden animate-in fade-in slide-in-from-right-2 duration-300">
      <header className="flex items-center justify-center px-4 h-[60px] border-b shrink-0 bg-background z-50">
        <div className="flex items-center gap-3">
          <Sparkles className="h-5 w-5 text-primary" />
          <h2 className="text-base font-black uppercase tracking-[0.15em] text-foreground">STYLE PREVIEW</h2>
        </div>
      </header>

      <div className="flex-1 flex flex-col items-center justify-center p-8 overflow-hidden relative">
        <div className="w-full max-w-sm space-y-8" data-card-style={activeCardStyle} data-patti-design={activePattiDesign}>
          <div className="text-center space-y-2">
            <h3 className="text-[11px] font-black uppercase tracking-[0.3em] text-muted-foreground">Live Demonstration</h3>
            <p className="text-[9px] font-bold text-slate-400 uppercase italic">Visualizing {activePattiDesign.toUpperCase()} layout</p>
          </div>

          {/* Symmetrical Search Bar Preview */}
          <div className="search-bar-card opacity-80 scale-95 pointer-events-none">
            <div className="flex items-center gap-2 flex-1">
              <Search className="h-4 w-4 text-muted-foreground ml-2" />
              <div className="text-[12px] font-bold text-slate-300 uppercase tracking-widest">Search UI Sync</div>
            </div>
          </div>

          <div 
            className="ledger-row group w-full flex items-center justify-between px-4 border-2 shadow-sm text-left h-[60px] bg-background rounded-lg select-none"
            style={{ '--status-color': 'var(--color-payment)' } as any}
          >
            <div className="flex items-center gap-4">
              <div className="custom-checkbox-wrapper checked" style={{ '--status-color': 'var(--color-payment)' } as any}>
                <Check className="check-icon h-3 w-3" />
              </div>
              <div className="flex flex-col min-w-0">
                <div className="font-bold text-[14px] text-foreground tracking-tight truncate">{sampleCustomer.name}</div>
                <div className="text-[12px] text-slate-400 font-semibold leading-tight">{sampleCustomer.lastActivity}</div>
              </div>
            </div>
            <div className="text-right flex flex-col items-end">
              <div className="font-bold text-[14px] text-[var(--color-payment)]">
                Rs. {formatCurrency(sampleCustomer.balance)}
              </div>
              <div className="text-[13px] font-bold text-slate-400 mt-0.5">Balance</div>
            </div>
          </div>

          <div className="p-4 bg-background/50 border border-muted rounded-xl space-y-3">
             <div className="flex items-center gap-2">
               <div className="h-1.5 w-1.5 rounded-full bg-primary" />
               <span className="text-[10px] font-black text-muted-foreground uppercase">Protected Structure</span>
             </div>
             <p className="text-[11px] font-bold text-slate-500 leading-relaxed uppercase">
               The vertical patti design and status colors are permanently locked to ensure financial clarity across all themes.
             </p>
          </div>
        </div>
      </div>

      <div className="h-[70px] bg-background border-t flex items-center justify-center px-4 shrink-0">
         <p className="text-[9px] font-black text-muted-foreground uppercase tracking-widest text-center max-w-sm">
           Advanced UI Styling • High-Density Layout Synchronization
         </p>
      </div>
    </div>
  );
}

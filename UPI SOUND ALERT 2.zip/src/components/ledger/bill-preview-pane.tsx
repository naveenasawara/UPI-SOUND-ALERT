
"use client"

import { useMemo, useRef, useState, useEffect } from 'react';
import { Customer, LedgerEntry, Company } from "@/app/lib/types";
import { 
  ReceiptText,
  Loader2,
  History,
  FileDown,
  ArrowLeft
} from "lucide-react";
import { cn, formatCurrency } from "@/lib/utils";
import { format, parseISO, isBefore, startOfDay } from "date-fns";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { jsPDF } from 'jspdf';
import autoTable from 'jspdf-autotable';

interface BillPreviewPaneProps {
  customer: Customer | null;
  entries: LedgerEntry[];
  allEntries: LedgerEntry[];
  businessName: string;
  businessLogo?: string | null;
  currentCompany: Company | null;
  customers: Customer[];
  onSelectCustomer: (id: string) => void;
  onReturnToLedger: () => void;
  batchCustomerIds: string[];
  onGenerateBatch: (ids: string[]) => void;
}

const getDataUri = (url: string): Promise<string> => {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = 'Anonymous';
    img.onload = () => {
      const canvas = document.createElement('canvas');
      canvas.width = img.width;
      canvas.height = img.height;
      const ctx = canvas.getContext('2d');
      ctx?.drawImage(img, 0, 0);
      resolve(canvas.toDataURL('image/png'));
    };
    img.onerror = () => reject('Could not load image');
    img.src = url;
  });
};

export function BillPreviewPane({ 
  customer, 
  entries, 
  allEntries,
  businessName, 
  businessLogo,
  currentCompany,
  customers,
  onSelectCustomer,
  onReturnToLedger,
  batchCustomerIds,
  onGenerateBatch
}: BillPreviewPaneProps) {
  const { toast } = useToast();
  const captureRef = useRef<HTMLDivElement>(null);
  const [previewImg, setPreviewImg] = useState<string | null>(null);
  const [lastBillImg, setLastBillImg] = useState<string | null>(null);
  const [isCapturing, setIsCapturing] = useState(false);
  
  useEffect(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('na_last_bill_preview');
      if (saved) setLastBillImg(saved);
    }
  }, []);

  const sortedEntries = useMemo(() => {
    return [...entries].sort((a, b) => {
      const dateDiff = parseISO(a.date).getTime() - parseISO(b.date).getTime();
      if (dateDiff !== 0) return dateDiff;
      return (a.createdAt || 0) - (b.createdAt || 0);
    });
  }, [entries]);

  const billStats = useMemo(() => {
    if (!customer) return { payment: 0, received: 0, net: 0, openingBalance: 0 };
    
    const dates = sortedEntries.length > 0 ? sortedEntries.map(e => parseISO(e.date).getTime()) : [Date.now()];
    const minDate = startOfDay(new Date(Math.min(...dates)));

    const openingBalance = allEntries
      .filter(e => e.customerId === customer.id && e.type !== 'forward' && isBefore(parseISO(e.date), minDate))
      .reduce((sum, e) => sum + (e.type === 'payment' ? e.amount : -e.amount), 0);

    const payment = sortedEntries.filter(e => e.type === 'payment').reduce((s, e) => s + e.amount, 0);
    const received = sortedEntries.filter(e => e.type === 'received').reduce((s, e) => s + e.amount, 0);
    return { payment, received, net: payment - received, openingBalance };
  }, [sortedEntries, customer, allEntries]);

  const dateRangeLabel = useMemo(() => {
    if (sortedEntries.length === 0) return format(new Date(), 'dd/MM/yyyy');
    const dates = sortedEntries.map(e => parseISO(e.date).getTime());
    const minDate = new Date(Math.min(...dates));
    const maxDate = new Date(Math.max(...dates));
    return `${format(minDate, 'dd/MM/yyyy')} TO ${format(maxDate, 'dd/MM/yyyy')}`;
  }, [sortedEntries]);

  useEffect(() => {
    const generatePreview = async () => {
      if (!captureRef.current || !customer) {
        setPreviewImg(null);
        return;
      }

      setIsCapturing(true);
      try {
        const html2canvas = (await import('html2canvas')).default;
        const target = captureRef.current;
        if (!target || !(target instanceof HTMLElement)) {
           throw new Error("Invalid DOM element for preview capture");
        }

        const canvas = await html2canvas(target, {
          scale: 2, 
          useCORS: true,
          backgroundColor: '#ffffff',
          logging: false,
          width: 800,
        });
        const dataUri = canvas.toDataURL('image/png');
        setPreviewImg(dataUri);
        
        if (entries.length > 0) {
          localStorage.setItem('na_last_bill_preview', dataUri);
          setLastBillImg(dataUri);
        }
      } catch (err) {
        console.warn("Retrying preview capture...");
      } finally {
        setIsCapturing(false);
      }
    };

    const timer = setTimeout(generatePreview, 500); 
    return () => clearTimeout(timer);
  }, [customer, sortedEntries, businessName, businessLogo, billStats, currentCompany]);

  const handleGenerateBill = async () => {
    if (batchCustomerIds.length > 1) {
      onGenerateBatch(batchCustomerIds);
      return;
    }

    if (!customer || entries.length === 0) return;

    const docPdf = new jsPDF();
    const pageWidth = docPdf.internal.pageSize.getWidth();
    const pageHeight = docPdf.internal.pageSize.getHeight();
    const margin = 14;
    
    let headerTextX = margin;
    if (businessLogo) {
      try {
        docPdf.addImage(businessLogo, 'PNG', margin, 12, 22, 22);
        headerTextX += 26;
      } catch (e) {}
    }

    docPdf.setFont("helvetica", "bold");
    docPdf.setFontSize(22);
    docPdf.setTextColor(0, 0, 0);
    docPdf.text(businessName, headerTextX, 20);
    
    docPdf.setFont("helvetica", "normal");
    docPdf.setFontSize(10);
    docPdf.setTextColor(100, 100, 100);
    docPdf.text(currentCompany?.mobile || "", headerTextX, 26);
    docPdf.text(currentCompany?.email || "", headerTextX, 31);
    
    docPdf.setDrawColor(0, 0, 0);
    docPdf.setLineWidth(0.2);
    docPdf.line(margin, 44, pageWidth - margin, 44);

    docPdf.setFont("helvetica", "bold");
    docPdf.setFontSize(18);
    docPdf.setTextColor(0, 0, 0);
    docPdf.text(customer.name, margin, 52);
    
    docPdf.setFontSize(11);
    docPdf.setTextColor(52, 152, 219); 
    docPdf.text(`Opening Balance: Rs. ${formatCurrency(billStats.openingBalance)}`, pageWidth - margin, 52, { align: 'right' });

    docPdf.setFontSize(11);
    docPdf.setTextColor(100, 100, 100);
    docPdf.setFont("helvetica", "bold");
    docPdf.text("Bill Summary", margin, 58);

    docPdf.setFontSize(11);
    docPdf.setTextColor(100, 100, 100);
    docPdf.setFont("helvetica", "normal");
    docPdf.text(dateRangeLabel, margin, 64);

    const countText = `Total Transactions: ${entries.length}`;
    docPdf.setFontSize(11);
    docPdf.setFont("helvetica", "bold");
    docPdf.setTextColor(120, 120, 120);
    docPdf.text(countText, margin, 70);

    const tableData = sortedEntries.map(entry => {
      let amountCell: any = { content: '-', styles: {} };
      if (entry.type === 'payment' || entry.type === 'forward') {
        amountCell = { content: `+ Rs. ${formatCurrency(entry.amount)}`, styles: { textColor: [231, 76, 60] } };
      } else if (entry.type === 'received') {
        amountCell = { content: `- Rs. ${formatCurrency(entry.amount)}`, styles: { textColor: [39, 174, 96] } };
      }

      return [
        format(parseISO(entry.date), 'dd/MM/yy'),
        /^\d/.test(entry.description) ? `Des No. ${entry.description}` : entry.description || '-',
        amountCell
      ];
    });

    autoTable(docPdf, {
      startY: 78,
      head: [['Date', 'Des No.', 'Amount (Rs)']],
      body: tableData,
      theme: 'grid',
      headStyles: { fillColor: [0, 0, 0], textColor: [255, 255, 255], fontStyle: 'bold', halign: 'center' },
      bodyStyles: { fontSize: 11, halign: 'center', textColor: [0, 0, 0], fontStyle: 'bold' },
      columnStyles: { 
        0: { cellWidth: 35 }, 
        2: { halign: 'right', fontStyle: 'bold' } 
      },
      alternateRowStyles: { fillColor: [245, 245, 245] },
    });

    const finalY = (docPdf as any).lastAutoTable.finalY || 100;
    let summaryY = finalY + 20;

    if (summaryY + 60 > pageHeight) {
      docPdf.addPage();
      summaryY = 40;
    }
    
    docPdf.setFontSize(11);
    docPdf.setTextColor(0, 0, 0);
    docPdf.setFont("helvetica", "bold");
    
    docPdf.text("Opening Balance - Rs.", margin, summaryY);
    docPdf.setTextColor(52, 152, 219); 
    docPdf.text(formatCurrency(billStats.openingBalance), margin + 45, summaryY);

    docPdf.setTextColor(0, 0, 0);
    docPdf.text("Total Payment - Rs.", margin, summaryY + 8);
    docPdf.setTextColor(52, 152, 219); 
    docPdf.text(formatCurrency(billStats.payment), margin + 45, summaryY + 8);

    docPdf.setTextColor(0, 0, 0);
    docPdf.text("Total Received - Rs.", margin, summaryY + 16);
    docPdf.setTextColor(52, 152, 219); 
    docPdf.text(formatCurrency(billStats.received), margin + 45, summaryY + 16);
    
    const finalNet = billStats.openingBalance + billStats.payment - billStats.received;
    docPdf.setTextColor(0, 0, 0);
    docPdf.text("Total Amount - Rs.", margin, summaryY + 24);
    docPdf.setTextColor(52, 152, 219); 
    docPdf.text(formatCurrency(Math.abs(finalNet)), margin + 45, summaryY + 24);

    const upiId = currentCompany?.upiId || "9993440441@ybl";
    const qrSize = 32;
    const upiStr = `upi://pay?pa=${upiId}&pn=${encodeURIComponent(businessName)}&cu=INR`;
    const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(upiStr)}`;
    
    try {
      const qrDataUri = await getDataUri(qrUrl);
      docPdf.addImage(qrDataUri, 'PNG', pageWidth - margin - qrSize, summaryY - 2, qrSize, qrSize);
      docPdf.setFontSize(8);
      docPdf.setTextColor(0, 0, 0);
      docPdf.text("SCAN TO PAY", pageWidth - margin - (qrSize / 2), summaryY + qrSize + 2, { align: 'center' });
    } catch (e) {}

    const footerLineY = summaryY + 45;
    docPdf.setDrawColor(0, 0, 0);
    docPdf.setLineWidth(0.1);
    docPdf.line(margin, footerLineY, pageWidth - margin, footerLineY);
    docPdf.setFontSize(8.5);
    docPdf.setFont("helvetica", "normal");
    docPdf.setTextColor(100, 100, 100);
    
    const bankDetails = `Bank: ${currentCompany?.bankName || '-'} | A/c: ${currentCompany?.accountNumber || '-'} | IFSC: ${currentCompany?.ifscCode || '-'} | UPI: ${currentCompany?.upiId || '-'}`;
    docPdf.text(bankDetails, margin, footerLineY + 6);

    const dates = sortedEntries.map(e => parseISO(e.date).getTime());
    const minDate = new Date(Math.min(...dates));
    const maxDate = new Date(Math.max(...dates));
    const rangeFileName = `${format(minDate, 'dd MM yy')} TO ${format(maxDate, 'dd MM yy')}`;
    docPdf.save(`${customer.name.toUpperCase()} ${rangeFileName} BILL.pdf`);
  };

  return (
    <div className="flex h-full flex-col bg-muted/20 overflow-hidden box-border relative group">
      <div className="absolute pointer-events-none overflow-hidden" style={{ left: '-9999px', top: 0, opacity: 1, zIndex: -50 }} aria-hidden="true" tabIndex={-1}>
        <div 
          ref={captureRef}
          className="w-[800px] bg-white p-14 flex flex-col"
          style={{ fontFamily: 'Helvetica, Arial, sans-serif', color: '#000000', minHeight: '1131px' }}
        >
          <div className="flex items-center mb-6">
            {businessLogo && (
              <img src={businessLogo} style={{ width: '80px', height: '80px', borderRadius: '40px', objectFit: 'cover', marginRight: '24px' }} alt="logo" />
            )}
            <div className="flex flex-col">
              <h1 className="text-[32px] font-bold leading-tight m-0">{businessName}</h1>
              <p className="text-[14px] text-[#666] m-0 mt-1">{currentCompany?.mobile}</p>
              <p className="text-[14px] text-[#666] m-0">{currentCompany?.email}</p>
            </div>
          </div>

          <div className="h-[1px] bg-black mb-8" />

          <div className="flex flex-col mb-8">
            <div className="flex justify-between items-start">
               <h2 className="text-[28px] font-bold m-0">{customer?.name || "Customer Name"}</h2>
               <p className="text-[16px] font-bold text-[#3498db] m-0">Opening Balance: Rs. {formatCurrency(billStats.openingBalance)}</p>
            </div>
            <p className="text-[16px] font-bold text-[#666] m-0 mt-2 uppercase">Bill Summary</p>
            <p className="text-[16px] text-[#666] m-0 mt-1">{dateRangeLabel}</p>
            <p className="text-[16px] font-bold text-[#666] m-0 uppercase mt-2">Total Transactions: {sortedEntries.length}</p>
          </div>

          <div className="mb-10">
            <table className="w-full border-collapse">
              <thead>
                <tr className="bg-[#000000] text-white">
                  <th className="py-3 px-2 text-center text-[14px] border border-[#ddd]">Date</th>
                  <th className="py-3 px-2 text-center text-[14px] border border-[#ddd]">Des No.</th>
                  <th className="py-3 px-2 text-center text-[14px] border border-[#ddd]">Amount (Rs)</th>
                </tr>
              </thead>
              <tbody className="font-bold">
                {sortedEntries.length === 0 ? (
                  <tr>
                    <td colSpan={3} className="py-20 text-center text-slate-300 font-bold italic text-sm border border-[#ddd]">
                      No transactions selected for this bill
                    </td>
                  </tr>
                ) : (
                  sortedEntries.map((e, idx) => (
                    <tr key={e.id} className={idx % 2 === 1 ? 'bg-[#f5f5f5]' : 'bg-white'}>
                      <td className="py-3 px-2 text-center text-[14px] border border-[#ddd] font-bold">{format(parseISO(e.date), 'dd/MM/yy')}</td>
                      <td className="py-3 px-2 text-center text-[14px] border border-[#ddd] font-bold">
                        {/^\d/.test(e.description) ? <>Des No. <span style={{ fontSize: 'calc(1em + 1px)' }}>{e.description}</span></> : (e.description || '-')}
                      </td>
                      <td className={cn(
                        "py-3 px-2 text-right text-[14px] font-bold border border-[#ddd]",
                        e.type === 'payment' || e.type === 'forward' ? "text-[#e74c3c]" : "text-[#27ae60]"
                      )}>
                        {e.type === 'payment' || e.type === 'forward' ? '+' : '-'} Rs. {formatCurrency(e.amount)}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>

          <div className="mt-auto pt-10 flex justify-between items-start">
            <div className="text-[16px] space-y-2 font-bold">
              <p className="m-0">Opening Balance - Rs. <span className="ml-2 text-[#3498db]">{formatCurrency(billStats.openingBalance)}</span></p>
              <p className="m-0">Total Payment - Rs. <span className="ml-2 text-[#3498db]">{formatCurrency(billStats.payment)}</span></p>
              <p className="m-0">Total Received - Rs. <span className="ml-2 text-[#3498db]">{formatCurrency(billStats.received)}</span></p>
              <p className="m-0 mt-4 text-[20px] font-bold">
                Total Amount - Rs. <span className="ml-2 text-[#3498db]">{formatCurrency(Math.abs(billStats.openingBalance + billStats.net))}</span>
              </p>
            </div>

            <div className="text-center flex flex-col items-center">
              <img 
                src={`https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=${encodeURIComponent(`upi://pay?pa=${currentCompany?.upiId || '9993440441@ybl'}&pn=${encodeURIComponent(businessName)}&cu=INR`)}`} 
                style={{ width: '120px', height: '120px' }}
                alt="QR"
              />
              <p className="text-[10px] font-bold mt-2 uppercase tracking-widest">SCAN TO PAY</p>
            </div>
          </div>

          <div className="mt-12 border-t border-black pt-2">
            <p className="text-[12px] text-[#666] m-0 text-center font-medium">
              Bank: {currentCompany?.bankName || '-'} | A/c: {currentCompany?.accountNumber || '-'} | IFSC: {currentCompany?.ifscCode || '-'} | UPI: {currentCompany?.upiId || '-'}
            </p>
          </div>
        </div>
      </div>

      <div className="flex-1 flex flex-col items-center justify-center p-2 overflow-hidden relative">
        <div className="w-full h-full flex flex-col items-center justify-center relative overflow-hidden">
          {!customer ? (
            lastBillImg ? (
              <div className="w-full h-full bg-background shadow-2xl border-2 border-muted rounded-sm relative group overflow-hidden">
                <div className="h-full w-full flex flex-col p-0 overflow-hidden animate-in fade-in duration-500">
                  <div className="relative flex-1 min-h-0 w-full overflow-y-auto custom-scrollbar p-4 flex flex-col items-center">
                    <img 
                      src={lastBillImg} 
                      className="w-full max-w-[800px] h-auto shadow-2xl rounded-sm mb-12 bg-white" 
                      alt="Last Bill"
                    />
                  </div>
                </div>
              </div>
            ) : (
              <div className="w-full h-full bg-background shadow-2xl border-2 border-muted flex flex-col items-center justify-center text-center opacity-20 rounded-sm">
                <ReceiptText className="h-16 w-16 mb-4" />
                <p className="font-black text-sm uppercase tracking-[0.3em] text-foreground">Select a customer on the left to begin bill</p>
              </div>
            )
          ) : (
            <div className="w-full h-full bg-background shadow-2xl border-2 border-muted rounded-sm relative group overflow-hidden">
              {isCapturing && (
                <div className="absolute inset-0 bg-background/50 backdrop-blur-[2px] z-20 flex items-center justify-center">
                  <Loader2 className="h-8 w-8 animate-spin text-primary" />
                </div>
              )}
              
              {previewImg ? (
                <div className="h-full w-full flex flex-col p-0 overflow-hidden animate-in fade-in duration-300">
                  <div className="relative flex-1 min-h-0 w-full overflow-y-auto custom-scrollbar p-4 flex flex-col items-center">
                    <img 
                      src={previewImg} 
                      className="w-full max-w-[800px] h-auto shadow-2xl rounded-sm mb-12 bg-white" 
                      alt="Bill Preview"
                    />
                  </div>
                </div>
              ) : (
                <div className="h-full w-full items-center justify-center">
                  <Loader2 className="h-10 w-10 animate-spin text-primary/20" />
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      <div className="h-[70px] bg-background border-t flex items-center justify-center px-4 shrink-0 z-50 gap-3">
        <Button 
          variant="outline"
          onClick={onReturnToLedger}
          className="flex-1 max-w-[120px] h-11 border-2 border-primary/20 text-primary font-black text-xs uppercase tracking-widest rounded-xl"
        >
          <ArrowLeft className="h-4 w-4 mr-2" /> BACK
        </Button>
        <Button 
          disabled={(!customer || entries.length === 0) && batchCustomerIds.length <= 1}
          onClick={handleGenerateBill}
          className="flex-1 max-w-md h-11 bg-primary hover:bg-primary/90 text-white font-black text-xs uppercase tracking-[0.2em] shadow-lg flex items-center justify-center gap-2 transition-all active:scale-[0.98] rounded-xl"
        >
          <FileDown className="h-4 w-4" />
          {batchCustomerIds.length > 1 ? `GENERATE BATCH BILL (${batchCustomerIds.length})` : `GENERATE BILL (${entries.length})`}
        </Button>
      </div>
    </div>
  );
}

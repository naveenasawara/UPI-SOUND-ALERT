"use client"

import { useMemo } from 'react';
import { Button } from "@/components/ui/button";
import { 
  BarChart3, 
  ArrowLeft,
  LayoutDashboard,
  CalendarDays,
  History,
  TrendingUp,
  TrendingDown
} from "lucide-react";
import { 
  format, 
  parseISO, 
  startOfDay, 
  endOfDay, 
  startOfMonth, 
  endOfMonth, 
  isValid, 
  parse 
} from 'date-fns';
import { cn, formatCurrency } from "@/lib/utils";
import { LedgerEntry, Customer } from '@/app/lib/types';
import { Card } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

interface AnalyticsPaneProps {
  entries: LedgerEntry[];
  customers: Customer[];
  onClose: () => void;
  range: {
    customerId: string;
    startDate: string;
    endDate: string;
  };
  setRange: (range: any) => void;
}

export function AnalyticsPane({ 
  entries, 
  onClose, 
  range,
  setRange
}: AnalyticsPaneProps) {
  
  const dynamicMonths = useMemo(() => {
    const monthsMap = new Set<string>();
    entries.forEach(e => {
      if (!e.date) return;
      const d = parseISO(e.date);
      if (isValid(d)) {
        monthsMap.add(format(d, 'MMMM yyyy'));
      }
    });

    return Array.from(monthsMap).sort((a, b) => {
      const da = parse(a, 'MMMM yyyy', new Date());
      const db = parse(b, 'MMMM yyyy', new Date());
      return db.getTime() - da.getTime(); 
    });
  }, [entries]);

  const activeMonthValue = useMemo(() => {
    if (!range || !range.startDate || !range.endDate) return '';
    const start = parseISO(range.startDate);
    const end = parseISO(range.endDate);
    if (!isValid(start) || !isValid(end)) return '';
    
    const expectedStart = format(startOfMonth(start), 'yyyy-MM-dd');
    const expectedEnd = format(endOfMonth(start), 'yyyy-MM-dd');
    
    if (range.startDate === expectedStart && range.endDate === expectedEnd) {
      return format(start, 'MMMM yyyy');
    }
    return '';
  }, [range]);

  const handleMonthSelect = (monthStr: string) => {
    const date = parse(monthStr, 'MMMM yyyy', new Date());
    const start = format(startOfMonth(date), 'yyyy-MM-dd');
    const end = format(endOfMonth(date), 'yyyy-MM-dd');
    setRange({ ...range, startDate: start, endDate: end });
  };

  const grandTotal = useMemo(() => {
    return entries.reduce((acc, e) => {
      if (e.type === 'forward') return acc;
      if (e.type === 'payment') acc.payment += e.amount;
      else if (e.type === 'received') acc.received += e.amount;
      return acc;
    }, { payment: 0, received: 0 });
  }, [entries]);

  const monthlySummary = useMemo(() => {
    if (!range || !range.startDate || !range.endDate) return { totalPayment: 0, totalReceived: 0 };
    const start = startOfDay(parseISO(range.startDate));
    const end = endOfDay(parseISO(range.endDate));

    if (!isValid(start) || !isValid(end)) return { totalPayment: 0, totalReceived: 0 };

    const filtered = entries.filter(e => {
      if (!e.date || e.type === 'forward') return false;
      const d = parseISO(e.date);
      return d >= start && d <= end;
    });

    const totalPayment = filtered.filter(e => e.type === 'payment').reduce((s, e) => s + e.amount, 0);
    const totalReceived = filtered.filter(e => e.type === 'received').reduce((s, e) => s + e.amount, 0);
    
    return {
      totalPayment,
      totalReceived
    };
  }, [entries, range]);

  const historyStats = useMemo(() => {
    const dailyMap: Record<string, { payment: number; received: number }> = {};
    entries.forEach(e => {
      if (e.type === 'forward') return;
      const dateKey = e.date;
      if (!dailyMap[dateKey]) dailyMap[dateKey] = { payment: 0, received: 0 };
      if (e.type === 'payment') dailyMap[dateKey].payment += e.amount;
      else if (e.type === 'received') dailyMap[dateKey].received += e.amount;
    });
    return Object.entries(dailyMap).map(([date, totals]) => ({ date, ...totals })).sort((a, b) => b.date.localeCompare(a.date));
  }, [entries]);

  const isDaySelected = (date: string) => {
    return range?.startDate === date && range?.endDate === date;
  };

  return (
    <div className="flex flex-col h-full bg-background overflow-hidden box-border">
      <div className="flex-1 min-h-0 flex flex-col p-3 bg-muted/20">
        <Card className="shrink-0 border-2 border-primary/10 shadow-md overflow-hidden bg-card w-full mb-4">
          <div className="p-4 space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <div className="p-3 bg-muted/20 rounded-xl border border-muted">
                <span className="text-[10px] font-black text-muted-foreground uppercase tracking-widest block mb-1">Grand Payment</span>
                <span className="text-[15px] font-black text-[#e74c3c] tracking-tight">Rs. {formatCurrency(grandTotal.payment)}</span>
              </div>
              <div className="p-3 bg-muted/20 rounded-xl border border-muted">
                <span className="text-[10px] font-black text-muted-foreground uppercase tracking-widest block mb-1">Grand Received</span>
                <span className="text-[15px] font-black text-[#27ae60] tracking-tight">Rs. {formatCurrency(grandTotal.received)}</span>
              </div>
            </div>

            <Select value={activeMonthValue} onValueChange={handleMonthSelect}>
              <SelectTrigger className="h-11 text-[11px] font-black uppercase border-2 border-muted bg-background hover:bg-muted/50 transition-colors focus:ring-primary shadow-sm rounded-lg">
                <div className="flex items-center gap-2">
                  <CalendarDays className="h-4 w-4 text-primary" />
                  <SelectValue placeholder="SELECT BUSINESS MONTH" />
                </div>
              </SelectTrigger>
              <SelectContent className="z-[100] p-1.5 min-w-[200px] max-h-[300px]">
                {dynamicMonths.map(month => (
                  <SelectItem key={month} value={month} className="text-[11px] font-bold uppercase py-2.5 px-3">
                    {month}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <div className="grid grid-cols-2 gap-3 pt-4 border-t border-muted">
              <div className="p-3 bg-muted/20 rounded-xl border border-muted">
                <span className="text-[10px] font-black text-muted-foreground uppercase tracking-widest block mb-1">Month Payment</span>
                <span className="text-[15px] font-black text-[#e74c3c] tracking-tight">Rs. {formatCurrency(monthlySummary.totalPayment)}</span>
              </div>
              <div className="p-3 bg-muted/20 rounded-xl border border-muted">
                <span className="text-[10px] font-black text-muted-foreground uppercase tracking-widest block mb-1">Month Received</span>
                <span className="text-[15px] font-black text-[#27ae60] tracking-tight">Rs. {formatCurrency(monthlySummary.totalReceived)}</span>
              </div>
            </div>
          </div>
        </Card>

        <Card className="flex-1 min-h-0 flex flex-col border-2 border-primary/5 shadow-sm overflow-hidden bg-card">
          <div className="bg-muted/30 px-4 py-2 border-b flex items-center gap-2 h-10 shrink-0">
             <History className="h-3.5 w-3.5 text-muted-foreground" />
             <span className="text-[12px] font-black text-muted-foreground uppercase tracking-widest">Daily History Journal</span>
          </div>
          <div className="flex-1 overflow-y-auto p-2 custom-scrollbar bg-card">
            {historyStats.length === 0 ? (
              <div className="h-48 flex flex-col items-center justify-center text-slate-300 gap-2 opacity-50">
                <BarChart3 className="h-10 w-10" />
                <p className="text-[11px] font-black uppercase tracking-widest">Empty Ledger</p>
              </div>
            ) : (
              <div className="flex flex-col">
                {historyStats.map((day) => (
                  <div 
                    key={day.date} 
                    onClick={() => setRange({ ...range, startDate: day.date, endDate: day.date })}
                    className={cn(
                      "mb-2 bg-background border-2 rounded-lg p-3 flex items-center hover:border-primary/30 transition-all shadow-sm cursor-pointer",
                      isDaySelected(day.date) ? "border-primary ring-2 ring-primary/5 bg-primary/5 shadow-inner" : "border-muted"
                    )}
                  >
                    <div className="w-1/3 text-[13px] font-black text-foreground text-center truncate">{format(parseISO(day.date), 'dd MMM yyyy')}</div>
                    <div className="w-1/3 text-[14px] font-black text-[#e74c3c] text-center">{day.payment > 0 ? formatCurrency(day.payment) : '-'}</div>
                    <div className="w-1/3 text-[14px] font-black text-[#27ae60] text-center">{day.received > 0 ? formatCurrency(day.received) : '-'}</div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </Card>
      </div>

      <div className="h-[70px] p-3 border-t bg-background shrink-0 flex items-center justify-center z-50">
        <Button onClick={onClose} className="w-full h-11 bg-primary hover:bg-primary/90 text-white font-black text-xs uppercase tracking-[0.2em] shadow-lg flex items-center justify-center gap-2 transition-all active:scale-[0.98] rounded-xl">
          <ArrowLeft className="h-4 w-4" /> RETURN TO LEDGER
        </Button>
      </div>
    </div>
  );
}

"use client"

// This component has been replaced by RangeReportPane to support more flexible reporting.
// Redirecting to RangeReportPane functionality.

export { RangeReportPane as DayReportPane } from './range-report-pane';


"use client"

import { useState } from 'react';
import { LedgerEntry } from "@/app/lib/types";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Trash2, Edit2, Search, ArrowUpDown, Calendar as CalendarIcon, Hash } from "lucide-react";
import { cn } from "@/lib/utils";

interface TransactionListProps {
  entries: LedgerEntry[];
  onDelete: (id: string) => void;
  onEdit: (entry: LedgerEntry) => void;
}

export function TransactionList({ entries, onDelete, onEdit }: TransactionListProps) {
  const [filterText, setFilterText] = useState('');
  const [sortField, setSortField] = useState<'date' | 'amount'>('date');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('desc');

  const filteredEntries = entries
    .filter(e => {
      const matchesText = e.description.toLowerCase().includes(filterText.toLowerCase());
      return matchesText;
    })
    .sort((a, b) => {
      const factor = sortOrder === 'asc' ? 1 : -1;
      if (sortField === 'date') return (new Date(a.date).getTime() - new Date(b.date).getTime()) * factor;
      return (a.amount - b.amount) * factor;
    });

  const toggleSort = (field: 'date' | 'amount') => {
    if (sortField === field) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortOrder('desc');
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex bg-card p-2 rounded-lg border shadow-sm items-center px-4">
        <Search className="h-4 w-4 text-muted-foreground mr-2" />
        <Input 
          placeholder="Search Des No...." 
          value={filterText}
          onChange={(e) => setFilterText(e.target.value)}
          className="border-none shadow-none focus-visible:ring-0 placeholder:text-muted-foreground/60"
        />
      </div>

      <div className="rounded-lg border bg-card shadow-sm overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow className="bg-muted/30">
              <TableHead onClick={() => toggleSort('date')} className="cursor-pointer hover:bg-muted/50 transition-colors w-40">
                <div className="flex items-center gap-1.5"><CalendarIcon className="h-3.5 w-3.5" /> Date <ArrowUpDown className="h-3 w-3" /></div>
              </TableHead>
              <TableHead>
                <div className="flex items-center gap-1.5"><Hash className="h-3.5 w-3.5" /> Details</div>
              </TableHead>
              <TableHead onClick={() => toggleSort('amount')} className="cursor-pointer hover:bg-muted/50 transition-colors text-right w-48">
                <div className="flex items-center justify-end gap-1.5">Amount <ArrowUpDown className="h-3 w-3" /></div>
              </TableHead>
              <TableHead className="w-20"></TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredEntries.length === 0 ? (
              <TableRow>
                <TableCell colSpan={4} className="h-32 text-center text-muted-foreground">
                  No records found in this ledger.
                </TableCell>
              </TableRow>
            ) : (
              filteredEntries.map((entry) => (
                <TableRow 
                  key={entry.id} 
                  className={cn(
                    "group transition-colors border-l-4 border-l-transparent",
                    entry.type === 'payment' ? "hover:bg-destructive/5 border-l-destructive" : "hover:bg-green-600/5 border-l-green-600"
                  )}
                >
                  <TableCell className="text-xs font-medium text-muted-foreground">
                    {new Date(entry.date).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' })}
                  </TableCell>
                  <TableCell className="font-bold text-foreground">
                    {entry.description ? <>Des No. <span style={{ fontSize: 'calc(1em + 1px)' }}>{entry.description}</span></> : 'No Des No.'}
                  </TableCell>
                  <TableCell className={`text-right font-bold ${entry.type === 'payment' ? 'text-destructive' : 'text-green-600'}`}>
                    <div className="flex flex-col items-end">
                      <span>Rs. {Math.abs(entry.amount).toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
                      <span className="text-[10px] uppercase opacity-70">{entry.type === 'payment' ? 'Payment' : 'Received'}</span>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex justify-end gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                      <Button variant="ghost" size="icon" onClick={() => onEdit(entry)} className="h-8 w-8 text-primary">
                        <Edit2 className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="icon" onClick={() => onDelete(entry.id)} className="h-8 w-8 text-destructive">
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}

"use client"

import { useState } from 'react';
import { LedgerEntry, Customer } from "@/app/lib/types";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Trash2, RotateCcw, Search, Users, ReceiptText } from "lucide-react";
import { cn, formatCurrency } from "@/lib/utils";
import { format } from "date-fns";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

interface RecycleBinHistoryPaneProps {
  deletedEntries: LedgerEntry[];
  deletedCustomers: Customer[];
  deletedMemos: any[];
  customers: Customer[];
  onRestoreEntry: (id: string) => void;
  onPermanentlyDeleteEntry: (id: string) => void;
  onRestoreCustomer: (id: string) => void;
  onPermanentlyDeleteCustomer: (id: string) => void;
  onRestoreMemo: (id: string) => void;
  onPermanentlyDeleteMemo: (id: string) => void;
}

export function RecycleBinHistoryPane({
  deletedEntries,
  deletedCustomers,
  customers,
  onRestoreEntry,
  onPermanentlyDeleteEntry,
  onRestoreCustomer,
  onPermanentlyDeleteCustomer,
}: RecycleBinHistoryPaneProps) {
  const [search, setSearch] = useState('');
  const [activeTab, setActiveTab] = useState<'entries' | 'customers'>('entries');

  const formatDescription = (desc: string) => {
    if (/^(\d{3,5}|\d+-\d+)$/.test(desc)) {
      return `Design No. ${desc}`;
    }
    return desc || 'No details';
  };

  const filteredEntries = (deletedEntries || []).filter(e => {
    const customer = customers.find(c => c.id === e.customerId);
    return (
      customer?.name.toLowerCase().includes(search.toLowerCase()) ||
      e.description.toLowerCase().includes(search.toLowerCase())
    );
  });

  const filteredDeletedCustomers = (deletedCustomers || []).filter(c => 
    c.name.toLowerCase().includes(search.toLowerCase())
  );

  const handleClearAllHistory = () => {
    deletedEntries.forEach(e => onPermanentlyDeleteEntry(e.id));
    deletedCustomers.forEach(c => onPermanentlyDeleteCustomer(c.id));
  };

  const isEmpty = 
    (activeTab === 'entries' && filteredEntries.length === 0) ||
    (activeTab === 'customers' && filteredDeletedCustomers.length === 0);

  return (
    <div className="h-full flex flex-col bg-background animate-in fade-in duration-500 overflow-hidden">
      <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as any)} className="flex-1 flex flex-col min-h-0 bg-muted/10">
        <div className="px-6 pt-4 bg-background border-b shadow-sm z-10">
          <TabsList className="grid grid-cols-2 w-full max-w-sm h-10 bg-muted p-1 rounded-lg">
            <TabsTrigger 
              value="entries" 
              className="text-[10px] font-black uppercase tracking-tighter flex items-center justify-center gap-1.5 data-[state=active]:text-primary data-[state=active]:bg-background data-[state=active]:shadow-sm"
            >
              <ReceiptText className="h-3.5 w-3.5" /> ENTRIES ({deletedEntries?.length || 0})
            </TabsTrigger>
            <TabsTrigger 
              value="customers" 
              className="text-[10px] font-black uppercase tracking-tighter flex items-center justify-center gap-1.5 data-[state=active]:text-primary data-[state=active]:bg-background data-[state=active]:shadow-sm"
            >
              <Users className="h-3.5 w-3.5" /> NAMES ({deletedCustomers?.length || 0})
            </TabsTrigger>
          </TabsList>

          <div className="py-4">
            <div className="relative max-w-md">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input 
                placeholder={`Filter deleted ${activeTab}...`} 
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-10 h-10 border-2 border-muted bg-muted/30 focus-visible:ring-primary font-bold text-sm"
              />
            </div>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto">
          {isEmpty ? (
            <div className="h-full flex flex-col items-center justify-center text-center p-12 opacity-30">
              <div className="h-20 w-20 bg-muted text-muted-foreground rounded-3xl flex items-center justify-center shadow-inner mb-4">
                <Trash2 className="h-10 w-10" />
              </div>
              <p className="font-black text-sm uppercase tracking-[0.3em] text-foreground">No Deleted Items</p>
              <p className="text-[10px] font-bold uppercase mt-2 text-muted-foreground">All purged or no recent deletions</p>
            </div>
          ) : (
            <>
              <TabsContent value="entries" className="m-0 h-full p-0">
                <Table>
                  <TableHeader className="bg-background sticky top-0 z-10 border-b">
                    <TableRow>
                      <TableHead className="uppercase text-[11px] font-black text-muted-foreground tracking-[0.2em] pl-8 h-12">Entry Detail & Date</TableHead>
                      <TableHead className="text-right uppercase text-[11px] font-black text-muted-foreground tracking-[0.2em] pr-8 h-12">Amount</TableHead>
                      <TableHead className="w-32"></TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredEntries.map((entry) => {
                      const customer = customers.find((c) => c.id === entry.customerId);
                      return (
                        <TableRow 
                          key={entry.id} 
                          className="border-b bg-card hover:bg-muted/30 transition-colors h-[72px]"
                        >
                          <TableCell className="py-3 pl-8">
                            <div className="flex flex-col">
                              <span className="font-black text-[13px] text-foreground leading-tight">
                                {formatDescription(entry.description)}
                              </span>
                              <span className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest mt-1">
                                {customer?.name || "Archived"} • {format(new Date(entry.date), "dd MMM yyyy")}
                              </span>
                            </div>
                          </TableCell>
                          <TableCell className="text-right pr-8 align-middle">
                            <div className={cn(
                              "font-black text-[15px] tracking-tight",
                              entry.type === 'payment' ? "text-[#e74c3c]" : "text-[#27ae60]"
                            )}>
                              {entry.type === 'payment' ? '-' : '+'} Rs. {formatCurrency(entry.amount)}
                            </div>
                          </TableCell>
                          <TableCell className="pr-6 py-3">
                            <div className="flex justify-end gap-2">
                              <Button variant="outline" size="icon" className="h-9 w-9 text-primary border-2 border-primary/20 hover:bg-primary/5 shadow-sm" onClick={() => onRestoreEntry(entry.id)}>
                                <RotateCcw className="h-4 w-4" />
                              </Button>
                              <Button variant="outline" size="icon" className="h-9 w-9 text-destructive border-2 border-destructive/20 hover:bg-destructive/5 shadow-sm" onClick={() => onPermanentlyDeleteEntry(entry.id)}>
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </TabsContent>

              <TabsContent value="customers" className="m-0 h-full p-0">
                <Table>
                  <TableHeader className="bg-background sticky top-0 z-10 border-b">
                    <TableRow>
                      <TableHead className="uppercase text-[11px] font-black text-muted-foreground tracking-[0.2em] pl-8 h-12">Customer Identity</TableHead>
                      <TableHead className="text-right uppercase text-[11px] font-black text-muted-foreground tracking-[0.2em] pr-8 h-12">Closing Balance</TableHead>
                      <TableHead className="w-32"></TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredDeletedCustomers.map((customer) => (
                      <TableRow 
                        key={customer.id} 
                        className="border-b bg-card hover:bg-muted/30 transition-colors h-[72px]"
                      >
                        <TableCell className="py-3 pl-8">
                          <div className="flex flex-col">
                            <span className="font-black text-[14px] text-foreground leading-tight">{customer.name}</span>
                            <span className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest mt-1">
                              {customer.phones?.[0] || 'Contact Private'}
                            </span>
                          </div>
                        </TableCell>
                        <TableCell className="text-right pr-8 align-middle">
                          <div className={cn(
                            "font-black text-[15px] tracking-tight",
                            customer.balance > 0 ? "text-[#e74c3c]" : "text-[#27ae60]"
                          )}>
                            Rs. {formatCurrency(Math.abs(customer.balance))}
                          </div>
                        </TableCell>
                        <TableCell className="pr-6 py-3">
                          <div className="flex justify-end gap-2">
                            <Button variant="outline" size="icon" className="h-9 w-9 text-primary border-2 border-primary/20 hover:bg-primary/5 shadow-sm" onClick={() => onRestoreCustomer(customer.id)}>
                              <RotateCcw className="h-4 w-4" />
                            </Button>
                            <Button variant="outline" size="icon" className="h-9 w-9 text-destructive border-2 border-destructive/20 hover:bg-destructive/5 shadow-sm" onClick={() => onPermanentlyDeleteCustomer(customer.id)}>
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TabsContent>
            </>
          )}
        </div>
      </Tabs>

      <div className="h-[70px] p-3 border-t bg-background shrink-0 flex items-center justify-center">
        <Button 
          onClick={handleClearAllHistory}
          disabled={!deletedEntries?.length && !deletedCustomers?.length}
          className="w-full h-11 bg-background border-2 border-destructive text-destructive hover:bg-destructive/5 font-black text-xs uppercase tracking-[0.2em] shadow-lg flex items-center justify-center gap-2 transition-all active:scale-[0.98] rounded-xl disabled:opacity-50 disabled:grayscale"
        >
          <Trash2 className="h-4 w-4" />
          CLEAR ALL HISTORY
        </Button>
      </div>
    </div>
  );
}

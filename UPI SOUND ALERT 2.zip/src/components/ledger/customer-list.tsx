
"use client"

import { LedgerEntry } from "@/app/lib/types";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Card } from "@/components/ui/card";
import { User, TrendingUp, ReceiptText } from "lucide-react";

interface CustomerListProps {
  entries: LedgerEntry[];
}

interface CustomerSummary {
  name: string;
  totalVolume: number;
  transactionCount: number;
  lastActive: string;
}

export function CustomerList({ entries }: CustomerListProps) {
  // Aggregate unique customers
  const customerMap = entries.reduce((acc, entry) => {
    const name = entry.customerId; // Note: In the revised structure, we use customerId
    if (!acc[name]) {
      acc[name] = {
        name: "Customer " + name.slice(0, 4), // Fallback
        totalVolume: 0,
        transactionCount: 0,
        lastActive: entry.date,
      };
    }
    
    acc[name].totalVolume += entry.amount;
    acc[name].transactionCount += 1;
    if (new Date(entry.date) > new Date(acc[name].lastActive)) {
      acc[name].lastActive = entry.date;
    }
    
    return acc;
  }, {} as Record<string, CustomerSummary>);

  const customers = Object.values(customerMap).sort((a, b) => b.totalVolume - a.totalVolume);

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card className="p-6 bg-card border shadow-sm flex items-center gap-4">
          <div className="p-3 bg-primary/10 rounded-full text-primary">
            <User className="h-6 w-6" />
          </div>
          <div>
            <div className="text-2xl font-bold">{customers.length}</div>
            <div className="text-sm text-muted-foreground">Total Customers</div>
          </div>
        </Card>
        <Card className="p-6 bg-card border shadow-sm flex items-center gap-4">
          <div className="p-3 bg-green-500/10 rounded-full text-green-600">
            <TrendingUp className="h-6 w-6" />
          </div>
          <div>
            <div className="text-2xl font-bold">
              Rs. {customers.reduce((sum, c) => sum + Math.max(0, c.totalVolume), 0).toLocaleString()}
            </div>
            <div className="text-sm text-muted-foreground">Total Customer Volume</div>
          </div>
        </Card>
      </div>

      <div className="rounded-lg border bg-card shadow-sm overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow className="bg-muted/50">
              <TableHead>Customer Name</TableHead>
              <TableHead className="text-center">Transactions</TableHead>
              <TableHead className="text-right">Total Volume</TableHead>
              <TableHead className="text-right">Last Activity</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {customers.length === 0 ? (
              <TableRow>
                <TableCell colSpan={4} className="h-32 text-center text-muted-foreground">
                  No customer data available.
                </TableCell>
              </TableRow>
            ) : (
              customers.map((customer) => (
                <TableRow key={customer.name} className="hover:bg-accent/5 transition-colors">
                  <TableCell className="font-medium">
                    <div className="flex items-center gap-2">
                      <User className="h-4 w-4 text-muted-foreground" />
                      {customer.name}
                    </div>
                  </TableCell>
                  <TableCell className="text-center font-mono">
                    <div className="flex items-center justify-center gap-1">
                      <ReceiptText className="h-3 w-3 text-muted-foreground" />
                      {customer.transactionCount}
                    </div>
                  </TableCell>
                  <TableCell className={`text-right font-mono font-bold ${customer.totalVolume >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                    Rs. {customer.totalVolume.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                  </TableCell>
                  <TableCell className="text-right text-xs text-muted-foreground">
                    {new Date(customer.lastActive).toLocaleDateString()}
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}

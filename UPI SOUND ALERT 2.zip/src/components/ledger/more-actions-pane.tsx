
"use client"

import { Button } from "@/components/ui/button";
import { 
  UserPlus, 
  BarChart3, 
  Trash2, 
  RefreshCw,
  X,
  ChevronRight,
  Users,
  Receipt,
  Wallet
} from "lucide-react";
import { Card } from "@/components/ui/card";

interface MoreActionsPaneProps {
  onNavigate: (view: any) => void;
  onRestartAndSync: () => void;
  onClose: () => void;
}

export function MoreActionsPane({ onNavigate, onRestartAndSync, onClose }: MoreActionsPaneProps) {
  const actions = [
    { id: 'customers', name: 'Business Ledger', icon: Users, desc: 'View all customer accounts', color: 'text-primary', bg: 'bg-primary/5' },
    { id: 'bill', name: 'Bill Generation', icon: Receipt, desc: 'Create custom bills', color: 'text-orange-600', bg: 'bg-orange-50' },
    { id: 'analytics', name: 'Balance Sheet', icon: BarChart3, desc: 'Profit & Loss analytics', color: 'text-purple-600', bg: 'bg-purple-50' },
    { id: 'cash', name: 'Cash Ledger', icon: Wallet, desc: 'Track petty cash flow', color: 'text-sky-600', bg: 'bg-sky-50' },
    { id: 'add-customer', name: 'Add New Customer', icon: UserPlus, desc: 'Register a new contact', color: 'text-blue-600', bg: 'bg-blue-50' },
    { id: 'recycle-bin', name: 'Recycle Bin', icon: Trash2, desc: 'Restore deleted records', color: 'text-rose-600', bg: 'bg-rose-50' },
  ];

  return (
    <div className="flex flex-col h-full bg-white dark:bg-card overflow-hidden">
      <div className="flex items-center justify-between px-4 h-14 border-b shrink-0 bg-primary/5">
        <div className="flex items-center gap-2 text-primary font-black uppercase tracking-tighter">
          SYSTEM MENU
        </div>
        <Button variant="ghost" size="icon" onClick={onClose} className="h-8 w-8">
          <X className="h-4 w-4" />
        </Button>
      </div>

      <div className="flex-1 p-4 overflow-y-auto space-y-3">
        <div className="grid grid-cols-1 gap-3">
          {actions.map((action) => (
            <Card 
              key={action.id} 
              className="p-4 border-2 border-slate-100 hover:border-primary/20 transition-all cursor-pointer active:scale-[0.98] group flex items-center justify-between shadow-sm"
              onClick={() => onNavigate(action.id)}
            >
              <div className="flex items-center gap-4">
                <div className={`h-12 w-12 rounded-2xl ${action.bg} ${action.color} flex items-center justify-center shrink-0`}>
                  <action.icon className="h-6 w-6" />
                </div>
                <div className="flex flex-col">
                  <span className="font-black text-sm uppercase tracking-tight text-black">{action.name}</span>
                  <span className="text-[11px] font-bold text-muted-foreground uppercase">{action.desc}</span>
                </div>
              </div>
              <ChevronRight className="h-5 w-5 text-muted-foreground/30 group-hover:text-primary transition-colors" />
            </Card>
          ))}
        </div>

        <div className="pt-4 pb-8">
          <Button 
            variant="outline" 
            className="w-full h-14 border-2 border-dashed border-primary/20 text-primary font-black text-xs uppercase tracking-widest hover:bg-primary/5"
            onClick={onRestartAndSync}
          >
            <RefreshCw className="h-4 w-4 mr-2" />
            Restart & Sync System
          </Button>
        </div>
      </div>
    </div>
  );
}


"use client"

import { useState, useRef, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { 
  StickyNote, 
  X, 
  Plus, 
  Save, 
  Pencil, 
  Image as ImageIcon,
  ArrowLeft
} from "lucide-react";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { cn } from "@/lib/utils";
import { Memo } from '@/app/lib/types';

interface MemoPaneProps {
  editingMemo: Memo | null;
  onClearEditing: () => void;
  onClose: () => void;
  onAddMemo: (title: string, content: string, imageUrl?: string) => void;
  onUpdateMemo: (id: string, title: string, content: string, imageUrl?: string) => void;
}

export function MemoPane({ editingMemo, onClearEditing, onClose, onAddMemo, onUpdateMemo }: MemoPaneProps) {
  const [newTitle, setNewTitle] = useState('');
  const [newMemo, setNewMemo] = useState('');
  const [newImageUrl, setNewImageUrl] = useState<string | undefined>(undefined);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (editingMemo) {
      setNewTitle(editingMemo.title);
      setNewMemo(editingMemo.content);
      setNewImageUrl(editingMemo.imageUrl);
    } else {
      resetForm();
    }
  }, [editingMemo]);

  const handleSaveMemo = () => {
    if (!newMemo.trim() && !newImageUrl) return;
    
    if (editingMemo) {
      onUpdateMemo(editingMemo.id, newTitle.trim(), newMemo.trim(), newImageUrl);
      onClearEditing();
    } else {
      onAddMemo(newTitle.trim(), newMemo.trim(), newImageUrl);
    }
    
    resetForm();
  };

  const resetForm = () => {
    setNewTitle('');
    setNewMemo('');
    setNewImageUrl(undefined);
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      setNewImageUrl(event.target?.result as string);
    };
    reader.readAsDataURL(file);
  };

  return (
    <div className="flex flex-col h-full bg-background overflow-hidden box-border">
      <div className="flex-1 overflow-hidden p-3 flex flex-col bg-muted/10">
        {/* Input Card at Top */}
        <Card className={cn(
          "w-full max-w-[480px] p-3 border-2 shadow-lg space-y-2 transition-all rounded-2xl mx-auto bg-card",
          editingMemo ? "border-orange-200" : "border-primary/10"
        )}>
          <div className="space-y-2">
            <div className="space-y-1">
              <label className="text-[9px] font-black uppercase tracking-[0.2em] text-muted-foreground px-1">Memo Category</label>
              <div className="flex gap-2">
                <Input 
                  placeholder="e.G. Card, Payment Note..."
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  className="h-8 font-black uppercase tracking-widest text-[10px] border-2 border-primary/10 bg-background focus-visible:ring-primary shadow-inner rounded-xl"
                />
                {editingMemo && (
                  <Button variant="ghost" size="sm" onClick={onClearEditing} className="h-8 w-8 shrink-0 text-orange-600 hover:bg-orange-100 rounded-xl">
                    <X className="h-4 w-4" />
                  </Button>
                )}
              </div>
            </div>

            <div className="space-y-1">
              <label className="text-[9px] font-black uppercase tracking-[0.2em] text-muted-foreground px-1">Content</label>
              <Textarea 
                placeholder="Write your note here..." 
                value={newMemo}
                onChange={(e) => setNewMemo(e.target.value)}
                className="min-h-[100px] font-bold border-2 border-primary/10 bg-background focus-visible:ring-primary shadow-inner resize-none text-[13px] rounded-xl"
              />
            </div>
          </div>
        </Card>

        {/* Action Controls at Bottom (Pushed down by mt-auto) */}
        <div className="mt-auto w-full max-w-[480px] mx-auto space-y-3 pb-2">
          {newImageUrl && (
            <div className="relative group w-full max-h-[160px] rounded-xl overflow-hidden border-2 border-primary/10 shadow-lg animate-in zoom-in-95">
              <img src={newImageUrl} alt="Attachment" className="w-full h-full object-contain bg-muted" />
              <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                <Button 
                  variant="destructive" 
                  size="icon" 
                  className="h-8 w-8 shadow-2xl scale-90 group-hover:scale-100 transition-transform rounded-full" 
                  onClick={() => setNewImageUrl(undefined)}
                >
                  <X className="h-3 w-3" />
                </Button>
              </div>
            </div>
          )}

          <div className="flex gap-2">
            <input type="file" ref={fileInputRef} onChange={handleImageUpload} accept="image/*" className="hidden" />
            <Button 
              variant="outline" 
              className="h-12 w-12 border-2 border-primary/20 text-primary hover:bg-primary/5 shrink-0 shadow-sm rounded-xl" 
              onClick={() => fileInputRef.current?.click()}
            >
              <ImageIcon className="h-5 w-5" />
            </Button>
            <Button 
              onClick={handleSaveMemo} 
              disabled={!newMemo.trim() && !newImageUrl} 
              className={cn(
                "flex-1 h-12 font-black text-[12px] uppercase tracking-[0.2em] shadow-lg transition-all active:scale-[0.98] rounded-xl",
                editingMemo ? "bg-orange-600 hover:bg-orange-700" : "bg-primary hover:bg-primary/90 text-white"
              )}
            >
              {editingMemo ? <><Save className="h-4 w-4 mr-2" /> UPDATE</> : <><Save className="h-4 w-4 mr-2" /> SAVE MEMO</>}
            </Button>
          </div>
        </div>
      </div>

      <div className="h-[70px] p-3 border-t bg-background shrink-0 flex items-center justify-center z-20">
        <Button 
          onClick={onClose}
          className="w-full h-11 bg-primary hover:bg-primary/90 text-white font-black text-xs uppercase tracking-[0.2em] shadow-lg flex items-center justify-center gap-2 transition-all active:scale-[0.98] rounded-xl"
        >
          <ArrowLeft className="h-4 w-4" />
          RETURN TO LEDGER
        </Button>
      </div>
    </div>
  );
}

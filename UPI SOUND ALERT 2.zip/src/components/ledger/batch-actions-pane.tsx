
"use client"

import { Customer } from "@/app/lib/types";
import { Button } from "@/components/ui/button";
import { FileText, X, Eye, Download, Users, CalendarDays } from "lucide-react";
import { useState } from "react";
import { format, startOfMonth } from "date-fns";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";

interface BatchActionsPaneProps {
  selectedCustomers: Customer[];
  onGenerate: (startDate: string, endDate: string, action: 'save' | 'view') => void;
  onClose: () => void;
}

export function BatchActionsPane({ selectedCustomers, onGenerate, onClose }: BatchActionsPaneProps) {
  const [startDate, setStartDate] = useState(format(startOfMonth(new Date()), 'yyyy-MM-dd'));
  const [endDate, setEndDate] = useState(format(new Date(), 'yyyy-MM-dd'));

  return (
    <div className="flex flex-col h-full bg-background overflow-hidden animate-in fade-in slide-in-from-right-2">
      {/* 60px Height Header */}
      <div className="h-[60px] border-b flex items-center justify-between px-4 bg-white dark:bg-card shrink-0 shadow-sm">
        <div className="flex items-center gap-2 text-primary font-black uppercase tracking-widest">
          <Users className="h-5 w-5" />
          {selectedCustomers.length} CUSTOMERS SELECTED
        </div>
        <Button variant="ghost" size="icon" onClick={onClose} className="h-8 w-8 text-black">
          <X className="h-4 w-4" />
        </Button>
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-6">
        <Card className="p-5 border-2 border-primary/10 bg-primary/5 space-y-5 shadow-inner rounded-xl">
          <div className="flex items-center gap-2 text-primary">
            <CalendarDays className="h-4 w-4" />
            <h3 className="text-[11px] font-black uppercase tracking-widest">Select Report Period</h3>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <Label className="text-[11px] font-black uppercase text-primary/70 tracking-widest">Start Date</Label>
              <Input 
                type="date" 
                value={startDate} 
                onChange={(e) => setStartDate(e.target.value)} 
                className="h-10 font-bold border-primary/20 bg-white focus-visible:ring-primary shadow-sm" 
              />
            </div>
            <div className="space-y-1.5">
              <Label className="text-[11px] font-black uppercase text-primary/70 tracking-widest">End Date</Label>
              <Input 
                type="date" 
                value={endDate} 
                onChange={(e) => setEndDate(e.target.value)} 
                className="h-10 font-bold border-primary/20 bg-white focus-visible:ring-primary shadow-sm" 
              />
            </div>
          </div>
          
          <div className="pt-2 border-t border-primary/5">
            <p className="text-[10px] font-bold text-muted-foreground uppercase leading-relaxed">
              * A professional chronological statement will be generated for each customer on a separate page.
            </p>
          </div>
        </Card>

        <div className="space-y-3">
          <h4 className="text-[10px] font-black uppercase tracking-widest text-slate-400 px-1 flex items-center gap-2">
            <FileText className="h-3 w-3" />
            Customers in Batch
          </h4>
          <div className="grid gap-2">
            {selectedCustomers.map(c => (
              <div key={c.id} className="flex items-center justify-between p-4 bg-white dark:bg-card border-2 border-slate-100 rounded-lg h-[60px] shadow-sm">
                <span className="font-bold text-[14px] text-black">{c.name}</span>
                <span className="text-[11px] font-black text-primary/60 uppercase tracking-tighter">
                  Rs. {Math.abs(c.balance).toLocaleString()}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* 70px Standard Footer */}
      <div className="h-[70px] p-3 border-t bg-white dark:bg-card shrink-0 flex gap-3 items-center">
        <Button 
          variant="outline"
          onClick={() => onGenerate(startDate, endDate, 'view')} 
          className="flex-1 h-11 border-2 border-primary/20 text-primary hover:bg-primary/5 font-black text-xs shadow-sm uppercase tracking-widest"
        >
          <Eye className="h-4 w-4 mr-2" />
          VIEW
        </Button>
        <Button 
          onClick={() => onGenerate(startDate, endDate, 'save')} 
          className="flex-1 h-11 bg-primary hover:bg-primary/90 text-primary-foreground font-black text-xs shadow-lg uppercase tracking-widest"
        >
          <Download className="h-4 w-4 mr-2" />
          DOWNLOAD
        </Button>
      </div>
    </div>
  );
}


"use client"

import { useState, useMemo } from 'react';
import { Button } from "@/components/ui/button";
import { 
  StickyNote, 
  Trash2, 
  Pencil, 
  Copy,
  ArrowUp,
  ArrowDown,
  History,
  ArrowLeft,
  ArrowDownWideNarrow,
  ArrowUpNarrowWide
} from "lucide-react";
import { Card } from "@/components/ui/card";
import { format } from 'date-fns';
import { cn } from "@/lib/utils";
import { Memo } from '@/app/lib/types';
import { useToast } from "@/hooks/use-toast";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";

interface MemoHistoryPaneProps {
  memos: Memo[];
  onEdit: (memo: Memo) => void;
  onDeleteMemo: (id: string) => void;
  onMoveMemo: (id: string, direction: 'up' | 'down') => void;
  onClear: () => void;
  onClose: () => void;
}

export function MemoHistoryPane({ memos, onEdit, onDeleteMemo, onMoveMemo, onClear, onClose }: MemoHistoryPaneProps) {
  const { toast } = useToast();
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('asc');

  const sortedMemos = useMemo(() => {
    return [...memos].sort((a, b) => {
      if (sortOrder === 'asc') {
        return (a.order || 0) - (b.order || 0);
      }
      return (b.order || 0) - (a.order || 0);
    });
  }, [memos, sortOrder]);

  const handleCopy = (content: string) => {
    navigator.clipboard.writeText(content).then(() => {
      toast({
        description: "Memo content copied to clipboard",
      });
    }).catch(() => {
      toast({
        variant: "destructive",
        description: "Failed to copy memo",
      });
    });
  };

  return (
    <div className="h-full flex flex-col bg-background animate-in fade-in duration-500 overflow-hidden">
      {/* Sorting Toolbar */}
      <div className="flex items-center justify-between px-6 py-3 bg-muted/30 border-b shrink-0">
        <div className="flex items-center gap-2 text-muted-foreground">
          {sortOrder === 'asc' ? <ArrowUpNarrowWide className="h-4 w-4" /> : <ArrowDownWideNarrow className="h-4 w-4" />}
          <span className="text-[10px] font-black uppercase tracking-widest">Auditing Order</span>
        </div>
        <Tabs value={sortOrder} onValueChange={(v: any) => setSortOrder(v)} className="h-8">
          <TabsList className="h-8 bg-muted/50 p-1 rounded-lg border">
            <TabsTrigger value="asc" className="text-[9px] font-black uppercase px-3 h-6 data-[state=active]:bg-primary data-[state=active]:text-white">Oldest First</TabsTrigger>
            <TabsTrigger value="desc" className="text-[9px] font-black uppercase px-3 h-6 data-[state=active]:bg-primary data-[state=active]:text-white">Latest First</TabsTrigger>
          </TabsList>
        </Tabs>
      </div>

      <div className="flex-1 overflow-y-auto p-6 space-y-6 bg-muted/20">
        {memos.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center text-center max-w-md mx-auto space-y-4 opacity-30">
            <div className="h-20 w-20 bg-muted text-muted-foreground rounded-3xl flex items-center justify-center shadow-inner">
               <StickyNote className="h-10 w-10" />
            </div>
            <p className="font-black text-sm uppercase tracking-[0.3em] text-foreground">No Memos Found</p>
            <p className="text-[10px] font-bold uppercase text-muted-foreground">Add a note on the left to get started</p>
          </div>
        ) : (
          <div className="max-w-3xl mx-auto w-full space-y-4">
            {sortedMemos.map((memo, index) => {
              // Find original index for move functionality
              const originalIndex = memos.findIndex(m => m.id === memo.id);
              
              return (
                <Card 
                  key={memo.id} 
                  className="p-5 border-2 border-muted hover:border-primary/20 transition-all shadow-sm bg-card group relative overflow-hidden"
                >
                  <div className="flex justify-between items-start mb-3">
                    <div className="flex flex-col">
                      <div className="flex items-center gap-2">
                        <div className="h-2 w-2 rounded-full bg-primary" />
                        <span className="text-[13px] font-black text-foreground uppercase tracking-widest truncate max-w-[300px]">
                          {memo.title || 'General Note'}
                        </span>
                      </div>
                      <span className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest mt-1">
                        {format(memo.createdAt, 'dd MMM yyyy • hh:mm a')}
                      </span>
                    </div>
                    <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                      {/* Manual Reordering - Only show in ASC mode to prevent visual logic conflicts */}
                      {sortOrder === 'asc' && (
                        <>
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            className="h-8 w-8 text-muted-foreground" 
                            onClick={() => onMoveMemo(memo.id, 'up')} 
                            disabled={originalIndex === 0}
                            title="Move Up"
                          >
                            <ArrowUp className="h-4 w-4" />
                          </Button>
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            className="h-8 w-8 text-muted-foreground" 
                            onClick={() => onMoveMemo(memo.id, 'down')} 
                            disabled={originalIndex === memos.length - 1}
                            title="Move Down"
                          >
                            <ArrowDown className="h-4 w-4" />
                          </Button>
                          <div className="w-px h-4 bg-muted mx-1" />
                        </>
                      )}
                      
                      <Button variant="ghost" size="icon" className="h-8 w-8 text-primary hover:bg-primary/5" onClick={() => handleCopy(memo.content)} title="Copy Content">
                        <Copy className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="icon" className="h-8 w-8 text-primary hover:bg-primary/5" onClick={() => onEdit(memo)} title="Edit Memo">
                        <Pencil className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive hover:bg-destructive/5" onClick={() => onDeleteMemo(memo.id)} title="Delete Memo">
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>

                  <div className="flex gap-6">
                    {memo.imageUrl && (
                      <div className="w-32 aspect-[3/2] rounded-lg overflow-hidden border border-muted shadow-inner shrink-0 cursor-zoom-in" onClick={() => window.open(memo.imageUrl, '_blank')}>
                        <img src={memo.imageUrl} alt="Attachment" className="w-full h-full object-cover" />
                      </div>
                    )}
                    <p className="text-[14px] font-bold text-muted-foreground leading-relaxed whitespace-pre-wrap flex-1">
                      {memo.content}
                    </p>
                  </div>
                </Card>
              );
            })}
          </div>
        )}
      </div>

      {/* Action Footer */}
      <div className="h-[70px] p-3 border-t bg-background shrink-0 flex items-center justify-center">
        <Button 
          onClick={onClear}
          disabled={memos.length === 0}
          className="w-full h-11 bg-background border-2 border-destructive text-destructive hover:bg-destructive/5 font-black text-xs uppercase tracking-[0.2em] shadow-lg flex items-center justify-center gap-2 transition-all active:scale-[0.98] rounded-xl disabled:opacity-50 disabled:grayscale"
        >
          <Trash2 className="h-4 w-4" />
          CLEAR HISTORY
        </Button>
      </div>
    </div>
  );
}

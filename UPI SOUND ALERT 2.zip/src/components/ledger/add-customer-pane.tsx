
"use client"

import { Button } from "@/components/ui/button";
import { UserPlus, X, Plus } from "lucide-react";
import { CustomerForm } from "./customer-form";
import { Customer } from "@/app/lib/types";

interface AddCustomerPaneProps {
  onSubmit: (name: string, phones: string[], emails: string[], avatarUrl?: string) => void;
  onAddCustomer: () => void;
  onClose: () => void;
  existingCustomers?: Customer[];
}

export function AddCustomerPane({ onSubmit, onAddCustomer, onClose, existingCustomers = [] }: AddCustomerPaneProps) {
  return (
    <div className="flex flex-col h-full bg-background overflow-hidden">
      <div className="flex items-center justify-between px-4 h-[60px] border-b shrink-0 bg-primary/5">
        <div className="header-title">
          <UserPlus />
          <span>Add New Customer</span>
        </div>
        <Button variant="ghost" size="icon" onClick={onClose} className="h-9 w-9 text-foreground">
          <X className="h-5 w-5" />
        </Button>
      </div>

      <div className="flex-1 overflow-hidden">
        <CustomerForm 
          id="add-customer-form"
          onSubmit={onSubmit} 
          onCancel={onClose}
          showButtons={false}
          existingCustomers={existingCustomers}
        />
      </div>

      <div className="h-[70px] p-3 border-t bg-background flex items-center justify-center shrink-0">
        <button 
          type="submit"
          form="add-customer-form"
          className="w-full bg-primary hover:bg-primary/90 text-white py-3.5 rounded-xl font-black flex items-center justify-center gap-2 transition-all uppercase text-xs tracking-widest shadow-lg active:scale-[0.98]"
        >
          <Plus className="w-5 h-5" />
          ADD CUSTOMER
        </button>
      </div>
    </div>
  );
}

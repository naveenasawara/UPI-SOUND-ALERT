
"use client"

import { LedgerEntry, Customer } from "@/app/lib/types";
import { Button } from "@/components/ui/button";
import { 
  ArrowLeft, 
  ArrowUp, 
  ArrowDown, 
  ReceiptText,
  CalendarDays,
  FileDown
} from "lucide-react";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { cn, formatCurrency } from "@/lib/utils";
import { format, parseISO } from 'date-fns';

interface RangeReportPaneProps {
  range: { customerId: string; startDate: string; endDate: string; };
  setRange: (range: any) => void;
  entries: LedgerEntry[];
  customers: Customer[];
  onGenerate: (type: any, startDate: string, endDate: string, action: any, targetId: string) => void;
  onClose: () => void;
}

export function RangeReportPane({ range, setRange, onGenerate, onClose, entries, customers }: RangeReportPaneProps) {
  // Filter entries for the selected range
  const filteredEntries = entries.filter(e => {
    if (!e.date || e.type === 'forward') return false;
    return e.date >= range.startDate && e.date <= range.endDate;
  }).sort((a, b) => b.createdAt - a.createdAt);

  return (
    <div className="flex flex-col h-full bg-background overflow-hidden animate-in fade-in slide-in-from-right-2 duration-300">
      {/* Content Area */}
      <div className="flex-1 p-3 space-y-4 bg-muted/20 overflow-y-auto custom-scrollbar">
        {/* Date Selector Module */}
        <Card className="p-4 border-2 border-primary/10 shadow-sm bg-card space-y-4 shrink-0">
           <div className="flex items-center gap-2 mb-1">
             <CalendarDays className="h-4 w-4 text-primary" />
             <Label className="text-[11px] font-black uppercase tracking-widest text-muted-foreground">Audit Range Selector</Label>
           </div>
           <div className="grid grid-cols-2 gap-3">
             <div className="space-y-1">
               <span className="text-[9px] font-black text-muted-foreground uppercase ml-1 opacity-60">Start Period</span>
               <Input 
                 type="date" 
                 value={range.startDate} 
                 onChange={(e) => setRange({ ...range, startDate: e.target.value })} 
                 className="h-10 font-bold border-2 border-muted focus-visible:ring-primary shadow-sm bg-background" 
               />
             </div>
             <div className="space-y-1">
               <span className="text-[9px] font-black text-muted-foreground uppercase ml-1 opacity-60">End Period</span>
               <Input 
                 type="date" 
                 value={range.endDate} 
                 onChange={(e) => setRange({ ...range, endDate: e.target.value })} 
                 className="h-10 font-bold border-2 border-muted focus-visible:ring-primary shadow-sm bg-background" 
               />
             </div>
           </div>
        </Card>

        {/* Transaction Log Module */}
        <div className="flex flex-col space-y-3 pb-8">
          <div className="px-2 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <ReceiptText className="h-3.5 w-3.5 text-muted-foreground" />
              <h3 className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">Transaction Audit Log</h3>
            </div>
            <span className="text-[9px] font-black text-primary bg-primary/10 px-2 py-0.5 rounded-full uppercase tracking-tighter">
              {filteredEntries.length} Records
            </span>
          </div>
          
          <div className="space-y-0.5">
            {filteredEntries.length === 0 ? (
              <div className="h-64 flex flex-col items-center justify-center text-center opacity-20 gap-4">
                <div className="h-16 w-16 bg-muted rounded-2xl flex items-center justify-center">
                  <ReceiptText className="h-8 w-8" />
                </div>
                <p className="font-black text-[11px] uppercase tracking-[0.2em]">No Records in Range</p>
              </div>
            ) : (
              filteredEntries.map((entry) => {
                const customer = customers.find(c => c.id === entry.customerId);
                const isBadDebts = entry.description.toLowerCase().trim() === 'bad debts';
                const statusColor = isBadDebts ? "var(--color-bad-debts)" : (entry.type === 'payment' ? "var(--color-payment)" : "var(--color-received)");

                return (
                  <div 
                    key={entry.id}
                    className="ledger-row group w-full bg-card border-2 border-muted rounded-xl mb-1.5 p-3.5 flex items-center justify-between select-none hover:border-primary/20 transition-all shadow-sm"
                    style={{ '--status-color': statusColor } as any}
                  >
                    <div className="flex items-center gap-3.5 min-w-0">
                      <div className={cn(
                        "h-9 w-9 rounded-full flex items-center justify-center shrink-0 border border-current/10 status-lock shadow-inner",
                        isBadDebts ? "bg-[#f97316]/15 text-[#f97316]" : 
                        (entry.type === 'payment' ? "bg-[#e74c3c]/15 text-[#e74c3c]" : "bg-[#27ae60]/15 text-[#27ae60]")
                      )}>
                        {entry.type === 'payment' ? <ArrowUp className="h-4 w-4" /> : <ArrowDown className="h-4 w-4" />}
                      </div>
                      <div className="flex flex-col min-w-0">
                        <span className="font-bold text-[13px] text-foreground truncate max-w-[180px] leading-tight">
                          {customer?.name || 'Unknown Account'}
                        </span>
                        <span className="text-[10px] font-black text-muted-foreground uppercase mt-1 truncate leading-tight opacity-70">
                          {format(parseISO(entry.date), 'dd MMM yy')} • {entry.description || 'Details'}
                        </span>
                      </div>
                    </div>
                    <div className="text-right pl-3">
                      <div className={cn(
                        "font-black text-[14px] tracking-tight leading-none",
                        isBadDebts ? "text-[#f97316]" : 
                        (entry.type === 'payment' ? "text-[#e74c3c]" : "text-[#27ae60]")
                      )}>
                        Rs. {formatCurrency(entry.amount)}
                      </div>
                      <span className="text-[8px] font-black text-muted-foreground uppercase tracking-widest mt-1 inline-block opacity-40">
                        {entry.type}
                      </span>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      </div>

      {/* Persistent Footer */}
      <div className="h-[70px] p-3 border-t bg-background shrink-0 flex gap-3 items-center z-20">
        <Button 
          variant="outline" 
          onClick={onClose} 
          className="flex-1 h-11 font-black text-[10px] uppercase tracking-widest rounded-xl border-2 border-muted hover:bg-muted/50"
        >
          <ArrowLeft className="h-4 w-4 mr-2" /> BACK
        </Button>
        <Button 
          onClick={() => onGenerate('custom', range.startDate, range.endDate, 'save', range.customerId)} 
          className="flex-[2] h-11 bg-primary hover:bg-primary/90 text-white font-black text-[10px] uppercase tracking-widest shadow-lg rounded-xl transition-all active:scale-[0.98]"
        >
          <FileDown className="h-4 w-4 mr-2" /> GENERATE REPORT
        </Button>
      </div>
    </div>
  );
}

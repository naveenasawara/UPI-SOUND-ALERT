
"use client"

import { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { LedgerEntry } from "@/app/lib/types";
import { generateSpendingInsights, GenerateSpendingInsightsOutput } from "@/ai/flows/generate-spending-insights";
import { BrainCircuit, Loader2, TrendingDown, TrendingUp, Lightbulb } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface AIInsightsProps {
  entries: LedgerEntry[];
}

export function AIInsights({ entries }: AIInsightsProps) {
  const [insights, setInsights] = useState<GenerateSpendingInsightsOutput | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const handleGenerate = async () => {
    if (entries.length < 3) {
      toast({ description: "Add at least 3 transactions to generate useful insights.", variant: "destructive" });
      return;
    }

    setIsLoading(true);
    try {
      const startDate = entries[entries.length - 1].date;
      const endDate = entries[0].date;
      
      const result = await generateSpendingInsights({
        ledgerEntries: entries,
        startDate,
        endDate
      });
      setInsights(result);
    } catch (error) {
      toast({ description: "Failed to generate AI insights. Please try again later.", variant: "destructive" });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      {!insights ? (
        <Card className="flex flex-col items-center justify-center p-12 text-center bg-accent/5 border-dashed border-2">
          <BrainCircuit className="h-12 w-12 text-accent mb-4 opacity-50" />
          <CardTitle className="mb-2">Discover Spending Patterns</CardTitle>
          <CardDescription className="max-w-md mb-6">
            Let Upi Sound Alert's AI analyze your transactions to provide personalized financial tips and habit-forming suggestions.
          </CardDescription>
          <Button onClick={handleGenerate} disabled={isLoading} size="lg" className="shadow-lg">
            {isLoading ? <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Analyzing...</> : "Generate Insights"}
          </Button>
        </Card>
      ) : (
        <div className="grid gap-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="h-5 w-5 text-primary" />
                Overall Summary
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground leading-relaxed">{insights.overallSummary}</p>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {insights.categoryInsights.map((cat, idx) => (
              <Card key={idx} className="overflow-hidden">
                <div className={`h-1 w-full ${cat.totalAmount < 0 ? 'bg-red-400' : 'bg-green-400'}`} />
                <CardHeader className="pb-2">
                  <div className="flex justify-between items-center">
                    <CardTitle className="text-base">{cat.category}</CardTitle>
                    <span className="text-xs font-bold px-2 py-1 rounded bg-secondary">{cat.percentageOfTotal.toFixed(1)}%</span>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="text-lg font-bold mb-1">Rs. {Math.abs(cat.totalAmount).toLocaleString()}</div>
                  <p className="text-sm text-muted-foreground">{cat.insight}</p>
                </CardContent>
              </Card>
            ))}
          </div>

          <Card className="bg-primary/5">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingDown className="h-5 w-5 text-accent" />
                Spending Patterns
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">{insights.spendingPatterns}</p>
            </CardContent>
          </Card>

          <Card className="bg-secondary/50">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Lightbulb className="h-5 w-5 text-yellow-500" />
                Actionable Suggestions
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2">
                {insights.suggestions.map((s, idx) => (
                  <li key={idx} className="flex gap-2 items-start text-sm">
                    <div className="h-5 w-5 shrink-0 rounded-full bg-primary/10 text-primary flex items-center justify-center font-bold text-[10px] mt-0.5">{idx + 1}</div>
                    {s}
                  </li>
                ))}
              </ul>
            </CardContent>
            <div className="p-4 pt-0">
               <Button variant="ghost" className="w-full text-xs" onClick={() => setInsights(null)}>Reset Analysis</Button>
            </div>
          </Card>
        </div>
      )}
    </div>
  );
}

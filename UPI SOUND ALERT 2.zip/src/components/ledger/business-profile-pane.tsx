
"use client"

import { useState, useRef, useEffect } from 'react';
import { Company } from "@/app/lib/types";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { 
  Building2, 
  Save, 
  Plus, 
  Trash2, 
  Phone, 
  Mail, 
  User, 
  Upload, 
  ChevronRight,
  ArrowLeft,
  LogOut
} from "lucide-react";
import { Card } from "@/components/ui/card";
import { cn } from "@/lib/utils";
import { useAuth } from '@/firebase';
import { signOut } from 'firebase/auth';

interface BusinessProfilePaneProps {
  companies: Company[];
  currentCompany: Company | null;
  onUpdate: (data: Partial<Company>) => void;
  onSelectCompany: (id: string) => void;
  onAddCompany: () => void;
  onDeleteCompany: (company: Company) => void;
  onClose: () => void;
}

export function BusinessProfilePane({ 
  companies, 
  currentCompany, 
  onUpdate, 
  onSelectCompany, 
  onAddCompany, 
  onDeleteCompany,
  onClose
}: BusinessProfilePaneProps) {
  const auth = useAuth();
  const [formData, setFormData] = useState({
    name: '', ownerName: '', mobile: '', email: ''
  });
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (currentCompany) {
      setFormData({
        name: currentCompany.name,
        ownerName: currentCompany.ownerName || '',
        mobile: currentCompany.mobile,
        email: currentCompany.email || ''
      });
    }
  }, [currentCompany]);

  const handleSave = () => {
    onUpdate({
      name: formData.name,
      ownerName: formData.ownerName,
      mobile: formData.mobile,
      email: formData.email
    });
  };

  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      onUpdate({ logoUrl: event.target?.result as string });
    };
    reader.readAsDataURL(file);
  };

  const handleSignOut = async () => {
    try {
      await signOut(auth);
    } catch (error) {
      console.error("Sign out failed", error);
    }
  };

  return (
    <div className="flex flex-col h-full bg-background overflow-hidden box-border">
      <div className="flex-1 overflow-y-auto custom-scrollbar p-4 space-y-4 bg-muted/10">
        {/* Branding & Logo Section */}
        <section className="space-y-2">
          <div className="px-1 flex items-center gap-2">
            <div className="h-1 w-1 rounded-full bg-primary" />
            <h3 className="text-[10px] font-black uppercase tracking-[0.2em] text-muted-foreground">Branding Identity</h3>
          </div>
          <Card className="p-2.5 border-2 border-primary/5 bg-card flex items-center gap-3 shadow-sm">
            <div 
              className="h-12 w-12 rounded-xl border-2 border-primary/20 bg-primary/5 flex items-center justify-center overflow-hidden cursor-pointer group relative"
              onClick={() => fileInputRef.current?.click()}
            >
              {currentCompany?.logoUrl ? (
                <img src={currentCompany.logoUrl} alt="Logo" className="h-full w-full object-cover" />
              ) : (
                <Building2 className="h-5 w-5 text-primary/40" />
              )}
              <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center text-white">
                <Upload className="h-3 w-3" />
              </div>
            </div>
            <input type="file" ref={fileInputRef} onChange={handleLogoUpload} accept="image/*" className="hidden" />
            <div className="flex flex-col">
              <span className="text-[12px] font-black text-foreground uppercase tracking-tight truncate max-w-[200px]">{currentCompany?.name}</span>
              <span className="text-[9px] font-bold text-muted-foreground uppercase">Update logo</span>
            </div>
          </Card>
        </section>

        {/* Profile Settings */}
        <section className="space-y-2">
          <div className="px-1 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="h-1 w-1 rounded-full bg-primary" />
              <h3 className="text-[10px] font-black uppercase tracking-[0.2em] text-muted-foreground">Profile Settings</h3>
            </div>
          </div>
          
          <Card className="p-3 border-2 border-primary/5 bg-card space-y-3 shadow-sm">
            <div className="space-y-1">
              <Label className="text-[9px] font-black uppercase tracking-widest text-muted-foreground ml-1">Company Name</Label>
              <Input 
                value={formData.name} 
                onChange={(e) => setFormData({...formData, name: e.target.value})}
                className="h-8 font-bold border-muted bg-muted/5 focus-visible:ring-primary text-[12px]"
                placeholder="Enter Company Name..."
              />
            </div>
            
            <div className="space-y-1">
              <Label className="text-[9px] font-black uppercase tracking-widest text-muted-foreground ml-1">Business Owner Name</Label>
              <div className="relative">
                <User className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3 w-3 text-muted-foreground" />
                <Input 
                  value={formData.ownerName} 
                  onChange={(e) => setFormData({...formData, ownerName: e.target.value})}
                  className="h-8 font-bold border-muted bg-muted/5 pl-8 focus-visible:ring-primary text-[12px]"
                  placeholder="Enter Owner Name..."
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <Label className="text-[9px] font-black uppercase tracking-widest text-muted-foreground ml-1">Mobile</Label>
                <div className="relative">
                  <Phone className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3 w-3 text-muted-foreground" />
                  <Input 
                    value={formData.mobile} 
                    onChange={(e) => setFormData({...formData, mobile: e.target.value})}
                    className="h-8 font-bold border-muted bg-muted/5 pl-8 focus-visible:ring-primary text-[12px]"
                    placeholder="Mobile Number"
                  />
                </div>
              </div>
              <div className="space-y-1">
                <Label className="text-[9px] font-black uppercase tracking-widest text-muted-foreground ml-1">Email</Label>
                <div className="relative">
                  <Mail className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3 w-3 text-muted-foreground" />
                  <Input 
                    value={formData.email} 
                    onChange={(e) => setFormData({...formData, email: e.target.value})}
                    className="h-8 font-bold border-muted bg-muted/5 pl-8 focus-visible:ring-primary text-[12px]"
                    placeholder="Business Email"
                  />
                </div>
              </div>
            </div>
          </Card>
        </section>

        {/* Company Switcher */}
        <section className="space-y-2">
          <div className="px-1 flex items-center gap-2">
            <div className="h-1 w-1 rounded-full bg-primary" />
            <h3 className="text-[10px] font-black uppercase tracking-[0.2em] text-muted-foreground">My Businesses</h3>
          </div>
          
          <div className="grid gap-1.5 max-h-[160px] overflow-y-auto custom-scrollbar pr-1">
            {companies.map((co) => (
              <Card 
                key={co.id}
                onClick={() => onSelectCompany(co.id)}
                className={cn(
                  "p-2 border-2 transition-all cursor-pointer group hover:border-primary/30 flex items-center justify-between",
                  currentCompany?.id === co.id ? "border-primary bg-primary/5 shadow-inner" : "border-muted bg-card"
                )}
              >
                <div className="flex items-center gap-2">
                  <div className={cn(
                    "h-7 w-7 rounded-lg flex items-center justify-center shrink-0 border-2",
                    currentCompany?.id === co.id ? "bg-primary text-white border-primary" : "bg-muted text-muted-foreground border-transparent"
                  )}>
                    <Building2 className="h-3.5 w-3.5" />
                  </div>
                  <span className="font-bold text-[12px] text-foreground tracking-tight truncate max-w-[150px]">{co.name}</span>
                </div>
                <div className="flex items-center gap-0.5 opacity-0 group-hover:opacity-100 transition-opacity">
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    className="h-7 w-7 text-destructive/40 hover:text-destructive hover:bg-destructive/5"
                    onClick={(e) => { e.stopPropagation(); onDeleteCompany(co); }}
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </Button>
                  <ChevronRight className="h-3.5 w-3.5 text-muted-foreground/30" />
                </div>
              </Card>
            ))}
            
            <div className="flex gap-2 mt-0.5">
              <Button 
                variant="outline" 
                onClick={onAddCompany}
                className="flex-1 h-8 border-2 border-dashed border-primary/20 text-primary font-black text-[8px] uppercase tracking-widest hover:bg-primary/5 rounded-lg"
              >
                <Plus className="h-3 w-3 mr-1.5" /> Register New
              </Button>
              <Button 
                variant="outline" 
                onClick={handleSignOut}
                className="flex-1 h-8 border-2 border-destructive/20 text-destructive font-black text-[8px] uppercase tracking-widest hover:bg-destructive/5 rounded-lg"
              >
                <LogOut className="h-3 w-3 mr-1.5" /> Sign Out
              </Button>
            </div>
          </div>
        </section>
      </div>

      <div className="h-[70px] p-3 border-t bg-background shrink-0 flex gap-3 items-center">
        <Button 
          onClick={handleSave}
          className="flex-1 h-11 bg-primary hover:bg-primary/90 text-white font-black text-xs uppercase tracking-widest shadow-lg rounded-xl transition-all active:scale-[0.98]"
        >
          <Save className="h-4 w-4 mr-2" />
          SAVE PROFILE
        </Button>
        <Button 
          variant="outline"
          onClick={onClose}
          className="flex-1 h-11 border-2 border-primary/20 text-primary font-black text-xs uppercase tracking-widest rounded-xl"
        >
          <ArrowLeft className="h-4 w-4 mr-2" />
          BACK
        </Button>
      </div>
    </div>
  );
}

"use client"

import { LedgerEntry, Customer } from "@/app/lib/types";
import { formatCurrency } from '@/lib/utils';
import { cn } from "@/lib/utils";
import { ArrowUp, ArrowDown, ArrowLeft, LayoutDashboard } from "lucide-react";
import { Button } from "@/components/ui/button";

interface DayAuditListProps {
  entries: LedgerEntry[];
  customers: Customer[];
  type: 'payment' | 'received';
  onClose: () => void;
}

export function DayAuditList({ entries, customers, type, onClose }: DayAuditListProps) {
  return (
    <div className="flex flex-col h-full bg-background overflow-hidden box-border">
      <div className="flex-1 overflow-y-auto p-3 bg-muted/20 custom-scrollbar timeline-scroll-area">
        <div className="grid">
          {entries.length === 0 ? (
            <div className="p-12 text-center text-muted-foreground opacity-30 flex flex-col items-center gap-4">
              <LayoutDashboard className="h-10 w-10" />
              <p className="font-black text-xs uppercase tracking-widest">No {type} records today</p>
            </div>
          ) : (
            entries.map((entry) => {
              const customer = customers.find(c => c.id === entry.customerId);
              const isBadDebts = entry.description.toLowerCase().trim() === 'bad debts';
              const statusColor = isBadDebts ? "var(--color-bad-debts)" : (entry.type === 'payment' ? "var(--color-payment)" : "var(--color-received)");

              return (
                <div 
                  key={entry.id}
                  className="ledger-row group w-full bg-card border-2 rounded-xl mb-2 shadow-sm transition-all h-[64px] p-4 flex flex-col justify-center select-none border-muted"
                  style={{ '--status-color': statusColor } as any}
                >
                  <div className="flex items-center gap-4 w-full">
                    <div className={cn(
                      "h-10 w-10 rounded-full flex items-center justify-center shrink-0 shadow-sm border border-current/10 status-lock",
                      isBadDebts ? "bg-[#f97316]/15 text-[#f97316]" : (entry.type === 'payment' ? "bg-[#e74c3c]/15 text-[#e74c3c]" : "bg-[#27ae60]/15 text-[#27ae60]")
                    )}>
                      {entry.type === 'payment' ? <ArrowUp className="h-4 w-4 icon-lock" /> : <ArrowDown className="h-4 w-4 icon-lock" />}
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex justify-between items-center w-full">
                        <span className="font-bold text-[14px] text-foreground truncate leading-tight pr-4">
                          {customer?.name || 'Unknown'} - {/^\d/.test(entry.description) ? `Des No. ${entry.description}` : (entry.description || 'Details')}
                        </span>
                        <span className={cn(
                          "font-black text-[14px] shrink-0 text-right leading-tight",
                          isBadDebts ? "text-[var(--color-bad-debts)]" : (entry.type === 'payment' ? "text-[var(--color-payment)]" : "text-[var(--color-received)]")
                        )}>
                          Rs. {formatCurrency(entry.amount)}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>

      <div className="h-[70px] p-3 border-t bg-background shrink-0 flex items-center justify-center z-20">
        <Button 
          onClick={onClose}
          className="w-full h-11 bg-primary hover:bg-primary/90 text-white font-black text-xs uppercase tracking-[0.2em] shadow-lg flex items-center justify-center gap-2 transition-all active:scale-[0.98] rounded-xl"
        >
          <ArrowLeft className="h-4 w-4" />
          RETURN TO LEDGER
        </Button>
      </div>
    </div>
  );
}
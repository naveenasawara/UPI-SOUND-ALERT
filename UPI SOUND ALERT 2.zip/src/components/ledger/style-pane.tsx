"use client"

import { Button } from "@/components/ui/button";
import { 
  Sparkles, 
  X, 
  ArrowLeft, 
  Layout, 
  Check, 
  Square, 
  Hexagon,
  Minus,
  GripVertical,
  Columns,
  ArrowDown,
  StretchVertical
} from "lucide-react";
import { Card } from "@/components/ui/card";
import { cn } from "@/lib/utils";

interface StylePaneProps {
  onClose: () => void;
  activeCardStyle: string;
  onSetCardStyle: (style: string) => void;
  activePattiDesign: 'solid' | 'dotted' | 'double' | 'gradient' | 'pillar';
  onSetPattiDesign: (design: 'solid' | 'dotted' | 'double' | 'gradient' | 'pillar') => void;
}

export function StylePane({ 
  onClose, 
  activeCardStyle, 
  onSetCardStyle, 
  activePattiDesign, 
  onSetPattiDesign 
}: StylePaneProps) {
  const cardVariants = [
    { id: 'bold', name: 'Standard Bold', desc: 'Heavy shadows & thick patti', icon: Layout },
    { id: 'simple', name: 'Simple Border', desc: 'Minimal outline & light shadow', icon: Square },
    { id: 'glass', name: 'Flat Glass', desc: 'Glass background & bottom bar', icon: Sparkles },
    { id: 'tile', name: 'Accent Tile', desc: 'Tile design with top boundary', icon: Layout },
  ];

  const pattiDesigns = [
    { id: 'solid', name: 'Standard Solid', icon: Minus },
    { id: 'dotted', name: 'Dotted Trail', icon: GripVertical },
    { id: 'double', name: 'Double Stripe', icon: Columns },
    { id: 'gradient', name: 'Gradient Fade', icon: ArrowDown },
    { id: 'pillar', name: 'Rounded Pillar', icon: StretchVertical },
  ];

  return (
    <div className="flex flex-col h-full bg-background overflow-hidden animate-in fade-in slide-in-from-left-2 duration-300">
      <div className="flex items-center justify-between px-4 h-[60px] border-b shrink-0 bg-background">
        <div className="flex items-center gap-2 text-foreground font-black uppercase tracking-tighter text-[14px]">
          <Sparkles className="h-5 w-5 text-primary" />
          REPORT STYLER
        </div>
        <Button variant="ghost" size="icon" onClick={onClose} className="h-8 w-8 text-foreground">
          <X className="h-4 w-4" />
        </Button>
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-8 bg-muted/20">
        <section className="space-y-3">
          <div className="flex items-center gap-2 px-1">
            <Layout className="h-4 w-4 text-primary" />
            <h3 className="text-[11px] font-black uppercase tracking-[0.2em] text-muted-foreground">Card Style Variants</h3>
          </div>
          
          <div className="grid gap-2">
            {cardVariants.map((v) => (
              <Card 
                key={v.id}
                onClick={() => onSetCardStyle(v.id)}
                className={cn(
                  "p-4 border-2 transition-all cursor-pointer group hover:border-primary/40 active:scale-[0.98] relative",
                  activeCardStyle === v.id ? "border-primary bg-primary/5 shadow-inner" : "border-muted bg-card"
                )}
              >
                <div className="flex items-center gap-4">
                  <div className={cn(
                    "h-10 w-10 rounded-xl flex items-center justify-center shrink-0 border-2 transition-colors",
                    activeCardStyle === v.id ? "bg-primary text-white border-primary" : "bg-muted text-muted-foreground border-transparent"
                  )}>
                    <v.icon className="h-5 w-5" />
                  </div>
                  <div className="flex flex-col min-w-0">
                    <span className="font-black text-[13px] uppercase tracking-tight text-foreground">{v.name}</span>
                    <span className="text-[10px] font-bold text-muted-foreground uppercase">{v.desc}</span>
                  </div>
                  {activeCardStyle === v.id && (
                    <div className="ml-auto h-6 w-6 bg-primary text-white rounded-full flex items-center justify-center scale-90">
                      <Check className="h-3.5 w-3.5" />
                    </div>
                  )}
                </div>
              </Card>
            ))}
          </div>
        </section>

        <section className="space-y-3">
          <div className="flex items-center gap-2 px-1">
            <StretchVertical className="h-4 w-4 text-primary" />
            <h3 className="text-[11px] font-black uppercase tracking-[0.2em] text-muted-foreground">Side Patti Design</h3>
          </div>
          
          <div className="grid grid-cols-1 gap-2">
            {pattiDesigns.map((d) => (
              <Card 
                key={d.id}
                onClick={() => onSetPattiDesign(d.id as any)}
                className={cn(
                  "p-4 border-2 transition-all cursor-pointer group hover:border-primary/40 active:scale-[0.98] relative",
                  activePattiDesign === d.id ? "border-primary bg-primary/5 shadow-inner" : "border-muted bg-card"
                )}
              >
                <div className="flex items-center gap-4">
                  <div className={cn(
                    "h-10 w-10 rounded-xl flex items-center justify-center shrink-0 border-2 transition-colors",
                    activePattiDesign === d.id ? "bg-primary text-white border-primary" : "bg-muted text-muted-foreground border-transparent"
                  )}>
                    <d.icon className="h-5 w-5" />
                  </div>
                  <span className="font-black text-[13px] uppercase tracking-tight text-foreground">{d.name}</span>
                  {activePattiDesign === d.id && (
                    <div className="ml-auto h-6 w-6 bg-primary text-white rounded-full flex items-center justify-center scale-90">
                      <Check className="h-3.5 w-3.5" />
                    </div>
                  )}
                </div>
              </Card>
            ))}
          </div>
        </section>

        <div className="p-4 bg-primary/5 border-2 border-dashed border-primary/20 rounded-xl">
           <p className="text-[10px] font-bold text-primary/70 uppercase leading-relaxed text-center">
             * All patti designs are synchronized with your selected branding colors and maintain Ledger Status logic.
           </p>
        </div>
      </div>

      <div className="h-[70px] p-3 border-t bg-background shrink-0 flex items-center justify-center">
        <Button onClick={onClose} className="w-full h-11 bg-primary hover:bg-primary/90 text-white font-black text-xs uppercase tracking-[0.2em] shadow-lg flex items-center justify-center gap-2 transition-all active:scale-[0.98] rounded-xl">
          <ArrowLeft className="h-4 w-4" /> RETURN TO LEDGER
        </Button>
      </div>
    </div>
  );
}

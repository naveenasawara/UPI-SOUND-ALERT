
"use client"

import { useMemo, useState } from 'react';
import { CashEntry } from "@/app/lib/types";
import { formatCurrency } from "@/lib/utils";
import { format } from 'date-fns';
import { Card } from "@/components/ui/card";
import { Wallet, TrendingUp, TrendingDown, History, Trash2, Pencil, ArrowDownWideNarrow, ArrowUpNarrowWide } from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";

interface CashHistoryPaneProps {
  entries: CashEntry[];
  onClear: () => void;
  onEdit: (entry: CashEntry) => void;
  onDelete: (id: string) => void;
}

export function CashHistoryPane({ entries, onClear, onEdit, onDelete }: CashHistoryPaneProps) {
  const [sortOrder, setSortOrder] = useState<'desc' | 'asc'>('desc');

  const balance = useMemo(() => {
    return entries.reduce((acc, e) => {
      return e.type === 'in' ? acc + e.amount : acc - e.amount;
    }, 0);
  }, [entries]);

  const sortedEntries = useMemo(() => {
    return [...entries].sort((a, b) => {
      if (sortOrder === 'desc') {
        return (b.createdAt || 0) - (a.createdAt || 0);
      }
      return (a.createdAt || 0) - (b.createdAt || 0);
    });
  }, [entries, sortOrder]);

  return (
    <div className="h-full flex flex-col bg-background animate-in fade-in duration-500 overflow-hidden">
      {/* Summary Header */}
      <div className="p-4 shrink-0 bg-muted/20 border-b">
        <Card className="p-4 bg-card border-2 border-primary/10 shadow-lg flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="h-10 w-10 rounded-xl bg-primary/10 text-primary flex items-center justify-center">
              <Wallet className="h-5 w-5" />
            </div>
            <div className="flex flex-col">
              <span className="text-[9px] font-black text-muted-foreground uppercase tracking-widest leading-none mb-1">Available Cash Balance</span>
              <span className={cn(
                "text-xl font-black tracking-tighter leading-none",
                balance >= 0 ? "text-[#27ae60]" : "text-destructive"
              )}>
                Rs. {formatCurrency(Math.abs(balance))}
                {balance < 0 && <span className="text-[10px] ml-1 font-bold">(OVERDRAWN)</span>}
              </span>
            </div>
          </div>
        </Card>
      </div>

      {/* Sorting Toolbar */}
      <div className="flex items-center justify-between px-6 py-2.5 bg-muted/30 border-b shrink-0">
        <div className="flex items-center gap-2 text-muted-foreground">
          {sortOrder === 'asc' ? <ArrowUpNarrowWide className="h-4 w-4" /> : <ArrowDownWideNarrow className="h-4 w-4" />}
          <span className="text-[10px] font-black uppercase tracking-widest">History Order</span>
        </div>
        <Tabs value={sortOrder} onValueChange={(v: any) => setSortOrder(v)} className="h-8">
          <TabsList className="h-8 bg-muted/50 p-1 rounded-lg border">
            <TabsTrigger value="desc" className="text-[9px] font-black uppercase px-3 h-6 data-[state=active]:bg-primary data-[state=active]:text-white">Latest First</TabsTrigger>
            <TabsTrigger value="asc" className="text-[9px] font-black uppercase px-3 h-6 data-[state=active]:bg-primary data-[state=active]:text-white">Oldest First</TabsTrigger>
          </TabsList>
        </Tabs>
      </div>

      <div className="flex-1 overflow-y-auto p-6 space-y-4 bg-muted/20">
        {entries.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center text-center opacity-30 gap-4">
            <div className="h-20 w-20 bg-muted text-muted-foreground rounded-3xl flex items-center justify-center shadow-inner">
               <History className="h-10 w-10" />
            </div>
            <p className="font-black text-sm uppercase tracking-[0.3em] text-foreground">Cash History Empty</p>
          </div>
        ) : (
          <div className="max-w-3xl mx-auto w-full space-y-3 pb-8">
            {sortedEntries.map((entry) => (
              <Card 
                key={entry.id} 
                className="p-4 border-2 border-muted hover:border-primary/5 transition-all shadow-sm bg-card group relative"
              >
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    {entry.type === 'in' ? (
                      <TrendingUp className="h-3.5 w-3.5 text-[#27ae60]" />
                    ) : (
                      <TrendingDown className="h-3.5 w-3.5 text-destructive" />
                    )}
                    <span className="text-[10px] font-black text-muted-foreground uppercase tracking-widest">
                      {format(entry.createdAt, 'dd MMM yyyy • hh:mm a')}
                    </span>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className={cn(
                      "text-lg font-black tracking-tighter",
                      entry.type === 'in' ? "text-[#27ae60]" : "text-destructive"
                    )}>
                      {entry.type === 'in' ? '+' : '-'} Rs. {formatCurrency(entry.amount)}
                    </span>
                    
                    <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                      <Button 
                        variant="ghost" 
                        size="icon" 
                        className="h-8 w-8 text-primary hover:bg-primary/5"
                        onClick={() => onEdit(entry)}
                      >
                        <Pencil className="h-3.5 w-3.5" />
                      </Button>
                      <Button 
                        variant="ghost" 
                        size="icon" 
                        className="h-8 w-8 text-destructive hover:bg-destructive/5"
                        onClick={() => onDelete(entry.id)}
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </Button>
                    </div>
                  </div>
                </div>
                
                <div className="flex flex-col">
                  <span className="text-[13px] font-bold text-foreground uppercase tracking-tight leading-relaxed">
                    {entry.remark || (entry.type === 'in' ? 'Cash Received' : 'Cash Paid')}
                  </span>
                </div>
              </Card>
            ))}
          </div>
        )}
      </div>

      <div className="h-[70px] p-3 border-t bg-background shrink-0 flex items-center justify-center">
        <Button 
          onClick={onClear}
          disabled={entries.length === 0}
          className="w-full h-11 bg-background border-2 border-destructive text-destructive hover:bg-destructive/5 font-black text-xs uppercase tracking-[0.2em] shadow-lg flex items-center justify-center gap-2 transition-all active:scale-[0.98] rounded-xl disabled:opacity-50 disabled:grayscale"
        >
          <Trash2 className="h-4 w-4" />
          CLEAR HISTORY
        </Button>
      </div>
    </div>
  );
}

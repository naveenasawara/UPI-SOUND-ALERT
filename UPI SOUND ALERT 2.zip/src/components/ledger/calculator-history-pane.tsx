
"use client"

import { useState, useMemo } from 'react';
import { Button } from "@/components/ui/button";
import { History, Trash2, Calculator, ArrowUpNarrowWide, ArrowDownWideNarrow } from "lucide-react";
import { Card } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { format } from 'date-fns';
import { CalculationHistory } from '@/app/lib/types';
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";

interface CalculatorHistoryPaneProps {
  history: CalculationHistory[];
  onClear: () => void;
}

export function CalculatorHistoryPane({ history, onClear }: CalculatorHistoryPaneProps) {
  const [sortOrder, setSortOrder] = useState<'desc' | 'asc'>('desc');

  const sortedHistory = useMemo(() => {
    return [...history].sort((a, b) => {
      if (sortOrder === 'desc') {
        return b.timestamp - a.timestamp;
      }
      return a.timestamp - b.timestamp;
    });
  }, [history, sortOrder]);

  return (
    <div className="h-full flex flex-col bg-background animate-in fade-in duration-500 overflow-hidden">
      {/* Sorting Toolbar */}
      <div className="flex items-center justify-between px-6 py-3 bg-muted/30 border-b shrink-0">
        <div className="flex items-center gap-2 text-muted-foreground">
          {sortOrder === 'asc' ? <ArrowUpNarrowWide className="h-4 w-4" /> : <ArrowDownWideNarrow className="h-4 w-4" />}
          <span className="text-[10px] font-black uppercase tracking-widest">History Order</span>
        </div>
        <Tabs value={sortOrder} onValueChange={(v: any) => setSortOrder(v)} className="h-8">
          <TabsList className="h-8 bg-muted/50 p-1 rounded-lg border">
            <TabsTrigger value="desc" className="text-[9px] font-black uppercase px-3 h-6 data-[state=active]:bg-primary data-[state=active]:text-white">Latest First</TabsTrigger>
            <TabsTrigger value="asc" className="text-[9px] font-black uppercase px-3 h-6 data-[state=active]:bg-primary data-[state=active]:text-white">Oldest First</TabsTrigger>
          </TabsList>
        </Tabs>
      </div>

      <div className="flex-1 overflow-y-auto p-6 space-y-6 bg-muted/20">
        {history.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center text-center max-w-md mx-auto space-y-4 opacity-30">
            <div className="h-20 w-20 bg-muted text-muted-foreground rounded-3xl flex items-center justify-center shadow-inner">
               <Calculator className="h-10 w-10" />
            </div>
            <p className="font-black text-sm uppercase tracking-[0.3em] text-foreground">No Calculations Yet</p>
          </div>
        ) : (
          <div className="max-w-xl mx-auto w-full space-y-3">
            {sortedHistory.map((item) => (
              <Card 
                key={item.id} 
                className="p-5 border-2 border-muted hover:border-primary/20 transition-all shadow-sm bg-card group"
              >
                <div className="flex justify-between items-start mb-2">
                  <div className="flex items-center gap-2">
                    <div className="h-2 w-2 rounded-full bg-primary/40 group-hover:bg-primary transition-colors" />
                    <span className="text-[10px] font-black text-muted-foreground uppercase tracking-widest">
                      {format(item.timestamp, 'dd MMM yyyy • hh:mm a')}
                    </span>
                  </div>
                </div>
                
                <div className="flex flex-col">
                  <div className="text-[13px] font-bold text-muted-foreground uppercase tracking-tighter truncate">
                    {item.equation} =
                  </div>
                  <div className="text-2xl font-black text-primary tracking-tighter mt-1">
                    {item.result}
                  </div>
                </div>
              </Card>
            ))}
          </div>
        )}
      </div>

      {/* Clear History Footer */}
      {history.length > 0 && (
        <div className="h-[70px] p-3 border-t bg-background shrink-0 flex items-center justify-center">
          <Button 
            onClick={onClear}
            className="w-full h-11 bg-background border-2 border-destructive text-destructive hover:bg-destructive/5 font-black text-xs uppercase tracking-[0.2em] shadow-lg flex items-center justify-center gap-2 transition-all active:scale-[0.98] rounded-xl"
          >
            <Trash2 className="h-4 w-4" />
            CLEAR HISTORY
          </Button>
        </div>
      )}
    </div>
  );
}

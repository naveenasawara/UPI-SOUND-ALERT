
"use client"

import { format } from 'date-fns';
import { Card } from "@/components/ui/card";
import { History, Trash2, Smartphone, Volume2, ShieldCheck, Bug, MessageSquareCode, Package, AppWindow } from "lucide-react";
import { cn, formatCurrency } from "@/lib/utils";
import { Button } from "@/components/ui/button";

interface AlertHistoryPaneProps {
  logs: any[];
  onClear: () => void;
}

export function AlertHistoryPane({ logs, onClear }: AlertHistoryPaneProps) {
  return (
    <div className="h-full flex flex-col bg-background animate-in fade-in duration-500 overflow-hidden">
      <header className="flex items-center justify-between px-6 h-[60px] border-b shrink-0 bg-muted/30">
        <div className="flex items-center gap-2">
          <History className="h-4 w-4 text-muted-foreground" />
          <span className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">Detection History Journal</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-[9px] font-black bg-primary/10 text-primary px-2 py-0.5 rounded-full uppercase">
            {logs.length} Total Records
          </span>
        </div>
      </header>

      <div className="flex-1 overflow-y-auto p-4 space-y-2 bg-muted/10 custom-scrollbar">
        {logs.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center text-center opacity-30 gap-4">
            <div className="h-20 w-20 bg-muted text-muted-foreground rounded-3xl flex items-center justify-center shadow-inner">
               <Volume2 className="h-10 w-10" />
            </div>
            <p className="font-black text-sm uppercase tracking-[0.3em] text-foreground">Journal is Empty</p>
            <p className="text-[10px] font-bold uppercase text-muted-foreground">Waiting for incoming signals or test mock alerts</p>
          </div>
        ) : (
          <div className="max-w-4xl mx-auto w-full space-y-1 pb-8">
            {logs.map((log) => (
              <div 
                key={log.id} 
                className={cn(
                  "ledger-row p-3 bg-card flex items-start justify-between group transition-all h-auto border-b animate-in slide-in-from-top-4 duration-300",
                  log.isDebug && "bg-amber-500/5"
                )}
                style={{ '--status-color': log.color || '#727374' } as any}
              >
                <div className="flex items-start gap-4 min-w-0 flex-1">
                  <div 
                    className="h-10 w-10 rounded-full flex items-center justify-center shrink-0 border border-current/10 mt-1"
                    style={{ backgroundColor: `${log.color}15`, color: log.color }}
                  >
                    {log.isDebug ? <Bug className="h-5 w-5" /> : <Smartphone className="h-5 w-5" />}
                  </div>
                  
                  <div className="flex flex-col min-w-0 flex-1">
                    <div className="flex items-center gap-2">
                       <span className="text-[15px] font-black text-foreground truncate tracking-tight">
                         {log.amount > 0 ? `Rs. ${formatCurrency(log.amount)}` : (log.title || log.app)}
                       </span>
                       {log.isDebug && (
                         <span className="text-[8px] font-black bg-amber-50 text-amber-600 border border-amber-200 px-1.5 py-0.5 rounded uppercase">Verified</span>
                       )}
                    </div>

                    <div className="flex items-center gap-1.5 mt-1">
                      <span className="text-[9px] font-black uppercase tracking-widest px-1.5 py-0.5 bg-muted rounded border border-muted-foreground/10 text-muted-foreground flex items-center gap-1">
                        <AppWindow className="h-2.5 w-2.5" />
                        {log.app}
                      </span>
                      <span className="text-[9px] font-bold text-muted-foreground uppercase opacity-60">
                        {format(log.timestamp, 'hh:mm:ss a')}
                      </span>
                    </div>

                    {/* Raw Captured Message */}
                    <div className="mt-2 flex flex-col gap-1.5 p-2 bg-muted/30 rounded-lg border border-dashed group-hover:bg-background transition-colors">
                       <div className="flex items-center gap-1.5 text-[8px] font-black text-muted-foreground uppercase opacity-50">
                         <Package className="h-2.5 w-2.5" />
                         Package: {log.package}
                       </div>
                       <div className="flex items-start gap-2">
                         <MessageSquareCode className="h-3 w-3 text-primary mt-0.5 shrink-0" />
                         <span className="text-[11px] font-medium text-foreground leading-tight italic break-words">
                           "{log.rawMessage}"
                         </span>
                       </div>
                    </div>
                  </div>
                </div>
                
                <div className="flex flex-col items-end gap-1 shrink-0 ml-4 pt-1">
                  <div className="flex items-center gap-1 text-[8px] font-black text-[#27ae60] bg-[#27ae60]/10 px-2 py-0.5 rounded border border-[#27ae60]/20 uppercase whitespace-nowrap shadow-sm">
                    <ShieldCheck className="h-2.5 w-2.5" />
                    Captured
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <div className="h-[70px] p-3 border-t bg-background shrink-0 flex items-center justify-center">
        <Button 
          onClick={onClear}
          disabled={logs.length === 0}
          className="w-full h-11 bg-background border-2 border-destructive text-destructive hover:bg-destructive/5 font-black text-xs uppercase tracking-[0.2em] shadow-lg flex items-center justify-center gap-2 transition-all active:scale-[0.98] rounded-xl disabled:opacity-50"
        >
          <Trash2 className="h-4 w-4" />
          PURGE HISTORY JOURNAL
        </Button>
      </div>
    </div>
  );
}

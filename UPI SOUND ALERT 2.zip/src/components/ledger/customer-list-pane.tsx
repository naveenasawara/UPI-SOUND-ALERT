
"use client"

import { useState, useMemo, useRef } from 'react';
import { Customer } from "@/app/lib/types";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { 
  Search, 
  Plus,
  ListFilter,
  SortAsc,
  SortDesc,
  ArrowUpNarrowWide,
  ArrowDownWideNarrow,
  History,
  Zap,
  ShieldCheck
} from "lucide-react";
import { cn, formatCurrency } from "@/lib/utils";
import { format, startOfMonth, subMonths } from "date-fns";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
  DropdownMenuRadioGroup,
  DropdownMenuRadioItem,
} from "@/components/ui/dropdown-menu";

type FilterType = 'all' | 'payment' | 'received' | 'settled';
type SortKey = 'name' | 'balance' | 'activity';
type SortOrder = 'asc' | 'desc';
type SortMode = 'single' | 'double';

interface CustomerListPaneProps {
  customers: (Customer & { isBadDebt?: boolean, lastActivityAt?: number })[];
  selectedCustomerId: string | null;
  onSelectCustomer: (id: string | null) => void;
  onAddCustomer: () => void;
  searchQuery: string;
  onSearchChange: (q: string) => void;
}

export function CustomerListPane({ 
  customers, 
  selectedCustomerId, 
  onSelectCustomer, 
  onAddCustomer,
  searchQuery,
  onSearchChange
}: CustomerListPaneProps) {
  const [filterType, setFilterType] = useState<FilterType>('all');
  const [sortKey, setSortKey] = useState<SortKey>('name');
  const [sortOrder, setSortOrder] = useState<SortOrder>('asc');
  const [sortMode, setSortMode] = useState<SortMode>('single');
  
  const inputRef = useRef<HTMLInputElement>(null);

  const filteredCustomers = useMemo(() => {
    let result = customers.filter(c => c.name.toLowerCase().includes(searchQuery.toLowerCase()));
    
    // Applying status filters
    if (filterType === 'payment') result = result.filter(c => c.balance > 0);
    else if (filterType === 'received') result = result.filter(c => c.balance < 0);
    else if (filterType === 'settled') result = result.filter(c => c.balance === 0);

    // Applying Sorting Engine
    result.sort((a, b) => {
      // 1. DOUBLE SORT: Financial Grouping Logic (Dues > Rs 1 -> Settled 0 -> Others | All A-Z)
      if (sortMode === 'double') {
        const getFinancialTier = (bal: number) => {
          if (bal > 1) return 1; // High Dues
          if (bal === 0) return 2; // Settled
          return 3; // Others (Advance/Credits)
        };

        const tierA = getFinancialTier(a.balance);
        const tierB = getFinancialTier(b.balance);

        if (tierA !== tierB) return tierA - tierB;
        // Sub-sort by Name A-Z within financial tiers
        return a.name.localeCompare(b.name);
      }

      // 2. SINGLE SORT: Temporal Grouping Logic (Active [Last/Curr Month] -> Inactive | Selected Key)
      const recentCutoff = startOfMonth(subMonths(new Date(), 1)).getTime();
      const aIsRecent = (a.lastActivityAt || 0) >= recentCutoff;
      const bIsRecent = (b.lastActivityAt || 0) >= recentCutoff;
      
      if (aIsRecent && !bIsRecent) return -1;
      if (!aIsRecent && bIsRecent) return 1;

      // Tier comparison same, apply primary sort key
      let comparison = 0;
      if (sortKey === 'name') {
        comparison = a.name.localeCompare(b.name);
      } else if (sortKey === 'balance') {
        comparison = Math.abs(a.balance) - Math.abs(b.balance);
      } else if (sortKey === 'activity') {
        comparison = (a.lastActivityAt || 0) - (b.lastActivityAt || 0);
      }

      if (sortOrder === 'desc') comparison *= -1;
      if (comparison === 0) return a.name.localeCompare(b.name);

      return comparison;
    });

    return result;
  }, [customers, searchQuery, filterType, sortKey, sortOrder, sortMode]);

  return (
    <div className="flex flex-col flex-1 min-h-0 bg-background overflow-hidden box-border">
      <div className="search-bar-card" onClick={() => inputRef.current?.focus()}>
        <Search className="h-4 w-4 text-muted-foreground ml-2" />
        <Input 
          ref={inputRef} 
          placeholder={`${customers.length} Search Registry...`} 
          value={searchQuery} 
          onChange={(e) => onSearchChange(e.target.value)} 
          className="border-none bg-transparent focus-visible:ring-0 h-9 text-[14px] font-bold shadow-none flex-1" 
        />
        
        <div className="flex items-center gap-1 pr-2">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="h-8 w-8 hover:bg-primary/5 text-primary">
                <ListFilter className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-72 z-[100]">
              <DropdownMenuLabel className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">Sorting Mode</DropdownMenuLabel>
              <DropdownMenuRadioGroup value={sortMode} onValueChange={(v) => setSortMode(v as SortMode)}>
                <DropdownMenuRadioItem value="single" className="text-[11px] font-bold uppercase py-2.5">
                  <Zap className="mr-2 h-3.5 w-3.5 opacity-60 text-amber-500" /> Single Sort (Temporal)
                </DropdownMenuRadioItem>
                <DropdownMenuRadioItem value="double" className="text-[11px] font-bold uppercase py-2.5">
                  <ShieldCheck className="mr-2 h-3.5 w-3.5 opacity-60 text-primary" /> Double Sort (Financial)
                </DropdownMenuRadioItem>
              </DropdownMenuRadioGroup>

              <DropdownMenuSeparator />

              <DropdownMenuLabel className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">Ordering Logic</DropdownMenuLabel>
              <DropdownMenuRadioGroup value={`${sortKey}-${sortOrder}`} onValueChange={(val) => {
                const [key, order] = val.split('-') as [SortKey, SortOrder];
                setSortKey(key);
                setSortOrder(order);
              }}>
                <DropdownMenuRadioItem value="name-asc" className="text-[11px] font-bold uppercase py-2.5">
                  <SortAsc className="mr-2 h-3.5 w-3.5 opacity-60" /> Name A-Z
                </DropdownMenuRadioItem>
                <DropdownMenuRadioItem value="name-desc" className="text-[11px] font-bold uppercase py-2.5">
                  <SortDesc className="mr-2 h-3.5 w-3.5 opacity-60" /> Name Z-A
                </DropdownMenuRadioItem>
                <DropdownMenuRadioItem value="balance-desc" className="text-[11px] font-bold uppercase py-2.5">
                  <ArrowUpNarrowWide className="mr-2 h-3.5 w-3.5 opacity-60" /> Balance High-Low
                </DropdownMenuRadioItem>
                <DropdownMenuRadioItem value="balance-asc" className="text-[11px] font-bold uppercase py-2.5">
                  <ArrowDownWideNarrow className="mr-2 h-3.5 w-3.5 opacity-60" /> Balance Low-High
                </DropdownMenuRadioItem>
                <DropdownMenuRadioItem value="activity-desc" className="text-[11px] font-bold uppercase py-2.5">
                  <History className="mr-2 h-3.5 w-3.5 opacity-60" /> Recent Activity
                </DropdownMenuRadioItem>
                <DropdownMenuRadioItem value="activity-asc" className="text-[11px] font-bold uppercase py-2.5">
                  <History className="mr-2 h-3.5 w-3.5 opacity-60 rotate-180" /> Ancient Activity
                </DropdownMenuRadioItem>
              </DropdownMenuRadioGroup>
              
              <DropdownMenuSeparator />
              
              <div className="px-3 py-2 bg-muted/20 rounded-md m-1">
                <p className="text-[8px] font-black text-muted-foreground uppercase leading-tight">
                  {sortMode === 'double' 
                    ? "Financial: [Dues > Rs 1] > [Settled 0] > [Others] | Sub-sort Name A-Z" 
                    : "Temporal: [Active (Last/Curr Month)] > [Inactive] | Sorted by Key Above"
                  }
                </p>
              </div>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>

      <div className="flex-1 min-h-0 overflow-y-auto">
        {filteredCustomers.map((customer) => {
          const isSelected = selectedCustomerId === customer.id;
          const statusColor = customer.isBadDebt ? "var(--color-bad-debts)" : (customer.balance > 0 ? "var(--color-payment)" : (customer.balance < 0 ? "var(--color-received)" : "var(--color-settled)"));
          return (
            <div key={customer.id} onClick={() => onSelectCustomer(customer.id)} className={cn("ledger-row flex items-center justify-between px-4 h-[60px] cursor-pointer mb-0.5", isSelected && "bg-primary/5")} style={{ '--status-color': statusColor } as any}>
              <div className="flex items-center gap-4">
                <Avatar className="h-10 w-10 border-2 border-primary/10 avatar-lock">
                  <AvatarImage src={customer.avatarUrl} className="object-cover" />
                  <AvatarFallback className="font-black text-[14px]">{customer.name.charAt(0)}</AvatarFallback>
                </Avatar>
                <div className="flex flex-col min-w-0">
                  <span className="font-bold text-[14px] text-foreground truncate">{customer.name}</span>
                  <span className="text-[11px] text-slate-400 font-semibold">{customer.lastActivityAt ? format(customer.lastActivityAt, 'dd/MM/yy') : 'No activity'}</span>
                </div>
              </div>
              <div className="text-right">
                <div className={cn("font-bold text-[14px]", customer.balance > 0 ? "text-[#e74c3c]" : "text-[#27ae60]")}>Rs. {formatCurrency(Math.abs(customer.balance))}</div>
              </div>
            </div>
          );
        })}
        {filteredCustomers.length === 0 && (
          <div className="h-full flex flex-col items-center justify-center text-center p-8 opacity-20">
            <ListFilter className="h-10 w-10 mb-2" />
            <p className="text-[11px] font-black uppercase tracking-widest">No Matches Found</p>
          </div>
        )}
      </div>

      <div className="h-[70px] p-3 border-t bg-background flex items-center shrink-0 z-20">
        <button onClick={onAddCustomer} className="w-full bg-primary hover:bg-primary/90 text-white py-3.5 rounded-xl font-black uppercase text-xs tracking-widest shadow-lg">
          <Plus className="w-5 h-5 mr-2 inline" /> ADD CUSTOMER
        </button>
      </div>
    </div>
  );
}

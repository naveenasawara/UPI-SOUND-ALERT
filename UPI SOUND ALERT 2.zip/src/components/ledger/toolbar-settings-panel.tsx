"use client"

import { Button } from "@/components/ui/button";
import { 
  X, 
  Settings2, 
  Check
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Switch } from "@/components/ui/switch";

interface ToolbarSettingsPanelProps {
  onClose: () => void;
  allActions: any[];
  pinnedActions: string[];
  onTogglePin: (id: string) => void;
  isSplitMode: boolean;
}

export function ToolbarSettingsPanel({ 
  onClose, 
  allActions, 
  pinnedActions, 
  onTogglePin,
  isSplitMode
}: ToolbarSettingsPanelProps) {
  return (
    <div className="absolute inset-0 z-[100] bg-background border-l flex flex-col overflow-hidden animate-in slide-in-from-right duration-300 shadow-2xl">
      {/* Panel Header */}
      <div className="h-[60px] border-b bg-background flex items-center justify-end px-4 shrink-0">
        <Button variant="ghost" size="icon" onClick={onClose} className="h-9 w-9 hover:bg-destructive/10 hover:text-destructive transition-colors">
          <X className="h-5 w-5" />
        </Button>
      </div>

      {/* Scrollable Action List */}
      <div className="flex-1 overflow-y-auto custom-scrollbar p-6 space-y-6 bg-muted/10">
        <div className="space-y-4">
          <div className="px-1 flex items-center gap-2">
            <div className="h-1 w-1 rounded-full bg-primary" />
            <h3 className="text-[11px] font-black uppercase tracking-[0.2em] text-muted-foreground">Action Visibility Panning</h3>
          </div>
          
          <div className="grid gap-2">
            {allActions.map((action) => {
              const isPinned = pinnedActions.includes(action.id);
              const isActionActive = action.id === 'split' ? isSplitMode : false;

              return (
                <div 
                  key={action.id} 
                  className={cn(
                    "flex items-center justify-between p-4 bg-card border-2 rounded-xl transition-all shadow-sm",
                    isActionActive ? "border-primary/40 bg-primary/5" : "border-muted"
                  )}
                >
                  <div className="flex items-center gap-4 flex-1">
                    <div className={cn(
                      "h-10 w-10 rounded-xl flex items-center justify-center border-2 transition-colors",
                      isActionActive ? "bg-primary text-white border-primary" : "bg-muted text-muted-foreground border-transparent"
                    )}>
                      <action.icon className="h-5 w-5" />
                    </div>
                    <div className="flex flex-col">
                      <span className="font-black text-[13px] uppercase tracking-tight text-foreground">{action.label}</span>
                      <span className="text-[10px] font-bold text-muted-foreground uppercase">
                        {isPinned ? 'Pinned to Toolbar' : 'Available in Menu'}
                      </span>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-3 px-2">
                    <span className={cn(
                      "text-[9px] font-black uppercase tracking-widest",
                      isPinned ? "text-[#27ae60]" : "text-muted-foreground"
                    )}>
                      {isPinned ? 'Show' : 'Hide'}
                    </span>
                    <Switch 
                      checked={isPinned}
                      onCheckedChange={() => onTogglePin(action.id)}
                      className="data-[state=checked]:bg-[#27ae60]"
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Panel Footer - Synchronized 70px Height */}
      <footer className="h-[70px] p-3 border-t bg-background shrink-0 flex items-center justify-center z-50">
        <Button 
          onClick={onClose}
          className="w-full h-11 bg-primary hover:bg-primary/90 text-white font-black text-xs uppercase tracking-widest shadow-lg rounded-xl transition-all active:scale-[0.98]"
        >
          <Check className="h-4 w-4 mr-2" /> DONE & EXIT
        </Button>
      </footer>
    </div>
  );
}
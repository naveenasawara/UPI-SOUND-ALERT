
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { LedgerEntry } from "@/app/lib/types";
import { ArrowDownLeft, ArrowUpRight, Landmark } from "lucide-react";

interface SummaryCardsProps {
  entries: LedgerEntry[];
}

export function SummaryCards({ entries }: SummaryCardsProps) {
  const payment = entries.filter(e => e.amount > 0).reduce((acc, curr) => acc + curr.amount, 0);
  const received = entries.filter(e => e.amount < 0).reduce((acc, curr) => acc + Math.abs(curr.amount), 0);
  const balance = payment - received;

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
      <Card className="border-b-4 border-b-destructive shadow-sm">
        <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
          <CardTitle className="text-sm font-semibold uppercase tracking-wider text-muted-foreground">Payment</CardTitle>
          <div className="p-1.5 bg-destructive/10 rounded-full">
            <ArrowDownLeft className="h-4 w-4 text-destructive" />
          </div>
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold text-destructive">Rs. {payment.toLocaleString(undefined, { minimumFractionDigits: 2 })}</div>
        </CardContent>
      </Card>
      
      <Card className="border-b-4 border-b-green-600 shadow-sm">
        <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
          <CardTitle className="text-sm font-semibold uppercase tracking-wider text-muted-foreground">Received</CardTitle>
          <div className="p-1.5 bg-green-600/10 rounded-full">
            <ArrowUpRight className="h-4 w-4 text-green-600" />
          </div>
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold text-green-600">Rs. {received.toLocaleString(undefined, { minimumFractionDigits: 2 })}</div>
        </CardContent>

      <Card className="border-b-4 border-b-primary shadow-sm bg-primary/5">
        <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
          <CardTitle className="text-sm font-semibold uppercase tracking-wider text-primary">Net Balance</CardTitle>
          <div className="p-1.5 bg-primary/10 rounded-full">
            < Landmark className="h-4 w-4 text-primary" />
          </div>
        </CardHeader>
        <CardContent>
          <div className={`text-2xl font-bold ${balance >= 0 ? 'text-primary' : 'text-destructive'}`}>
            Rs. {Math.abs(balance).toLocaleString(undefined, { minimumFractionDigits: 2 })}
            <span className="text-xs ml-1 font-medium">{balance >= 0 ? '(Credit)' : '(Due)'}</span>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}


"use client"

import { useState, useRef, useMemo, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { LedgerEntry } from "@/app/lib/types";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";
import { parseISO, format } from "date-fns";

interface TransactionFormProps {
  type: 'payment' | 'received' | 'forward';
  initialData?: Partial<LedgerEntry>;
  forwardEntries?: LedgerEntry[];
  onSubmit: (data: Omit<LedgerEntry, 'id' | 'customerId' | 'createdAt'>, settleForwardId?: string) => void;
  onDelete?: () => void;
  onCancel: () => void;
  showButtons?: boolean;
}

export function TransactionForm({ type, initialData, onSubmit, onDelete, onCancel, showButtons = true }: TransactionFormProps) {
  const [amount, setAmount] = useState(initialData?.amount?.toString() || '');
  const [description, setDescription] = useState(initialData?.description || '');
  const [date, setDate] = useState(initialData?.date || format(new Date(), 'yyyy-MM-dd'));
  const [isPayment, setIsPayment] = useState(initialData?.type === 'payment' || (!initialData && type === 'payment'));
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [selectedIndex, setSelectedIndex] = useState(0);
  
  const { toast } = useToast();
  const descriptionRef = useRef<HTMLInputElement>(null);

  // Sync state if initialData or type changes externally
  useEffect(() => {
    if (initialData) {
      setIsPayment(initialData.type === 'payment');
    } else {
      setIsPayment(type === 'payment');
    }
  }, [initialData, type]);

  const suggestionMap: Record<string, string[]> = useMemo(() => {
    const activeType = isPayment ? 'payment' : 'received';
    if (activeType === 'payment') {
      return { c: ["Cash Payment"] };
    }
    return {
      c: ["Cash Received", "Cash Discount"],
      u: ["UPI"],
      n: ["NEFT"],
      r: ["RTGS"],
      b: ["Bad Debts"],
    };
  }, [isPayment]);

  const filteredSuggestions = useMemo(() => {
    if (initialData && type !== 'forward') return [];
    if (!description) return [];
    const firstChar = description.charAt(0).toLowerCase();
    return suggestionMap[firstChar] || [];
  }, [description, initialData, type, suggestionMap]);

  useEffect(() => {
    setSelectedIndex(0);
  }, [filteredSuggestions]);

  const handleSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!amount || !date) {
      toast({ description: "Please fill in amount and date.", variant: "destructive" });
      return;
    }
    
    onSubmit({
      amount: parseFloat(amount),
      description: description.trim(),
      date,
      type: isPayment ? 'payment' : 'received'
    });
  };

  const handleSelectSuggestion = (val: string) => {
    setDescription(val + " ");
    setShowSuggestions(false);
    setTimeout(() => {
      descriptionRef.current?.focus();
    }, 0);
  };

  const handleAmountKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      e.preventDefault(); 
      descriptionRef.current?.focus(); 
    }
  };

  const handleDescriptionKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (showSuggestions && filteredSuggestions.length > 0) {
      if (e.key === 'ArrowDown') {
        e.preventDefault();
        setSelectedIndex((prev) => (prev + 1) % filteredSuggestions.length);
        return;
      }
      if (e.key === 'ArrowUp') {
        e.preventDefault();
        setSelectedIndex((prev) => (prev - 1 + filteredSuggestions.length) % filteredSuggestions.length);
        return;
      }
      if (e.key === 'Enter') {
        e.preventDefault();
        handleSelectSuggestion(filteredSuggestions[selectedIndex]);
        return;
      }
      if (e.key === 'Escape') {
        setShowSuggestions(false);
        return;
      }
    }
    if (e.key === 'Enter') {
      e.preventDefault();
      handleSubmit(); 
    }
  };

  return (
    <form onSubmit={handleSubmit} className="flex flex-col h-full overflow-hidden box-border">
      <div className="flex-1 overflow-y-auto p-6 space-y-6">
        {/* Dynamic Type Toggle */}
        <div className="flex items-center justify-between p-4 bg-muted/30 rounded-xl border-2 border-primary/5">
          <div className="flex flex-col">
            <span className={cn(
              "text-sm font-black uppercase tracking-widest transition-colors",
              isPayment ? "text-[#e74c3c]" : "text-[#27ae60]"
            )}>
              {isPayment ? 'Payment (Dr)' : 'Received (Cr)'}
            </span>
            <span className="text-[9px] font-bold text-muted-foreground uppercase">Transaction Type</span>
          </div>
          <Switch 
            checked={isPayment} 
            onCheckedChange={setIsPayment}
            className="data-[state=checked]:bg-[#e74c3c] data-[state=unchecked]:bg-[#27ae60]"
          />
        </div>

        <div className="grid gap-2">
          <Label htmlFor="amount" className="text-[12px] font-black uppercase tracking-widest text-muted-foreground ml-1">AMOUNT (Rs.)</Label>
          <Input
            id="amount"
            type="text"
            inputMode="numeric"
            value={amount}
            onChange={(e) => {
              const val = e.target.value.replace(/\D/g, '');
              setAmount(val);
            }}
            onKeyDown={handleAmountKeyDown}
            placeholder="0"
            required
            autoFocus
            className="text-lg font-bold h-12 border-primary/20 focus-visible:ring-primary rounded-md bg-background"
          />
        </div>

        <div className="space-y-4">
          <div className="grid gap-2 relative">
            <Label htmlFor="description" className="text-[10px] font-black uppercase tracking-widest text-muted-foreground ml-1">DES NO. / DETAILS</Label>
            <Input
              id="description"
              ref={descriptionRef}
              value={description}
              onChange={(e) => {
                const val = e.target.value;
                setDescription(val);
                setShowSuggestions(val.length === 1);
              }}
              onFocus={() => setShowSuggestions(description.length === 1)}
              onKeyDown={handleDescriptionKeyDown}
              placeholder="Type first letter for presets..."
              className="h-11 font-bold border-primary/10 focus-visible:ring-primary rounded-md bg-background"
              autoComplete="off"
            />

            {showSuggestions && filteredSuggestions.length > 0 && (
              <div className="absolute top-full left-0 right-0 mt-1 bg-card border-2 border-primary/20 rounded-md shadow-xl z-50 overflow-hidden animate-in fade-in slide-in-from-top-1">
                {filteredSuggestions.map((suggestion, index) => (
                  <button
                    key={suggestion}
                    type="button"
                    onClick={() => handleSelectSuggestion(suggestion)}
                    onMouseEnter={() => setSelectedIndex(index)}
                    className={cn(
                      "w-full text-left px-4 py-3 text-[11px] font-black uppercase tracking-widest border-b last:border-b-0 transition-colors",
                      index === selectedIndex ? "bg-primary/10 text-primary" : "hover:bg-primary/5 text-foreground"
                    )}
                  >
                    {suggestion}
                  </button>
                ))}
              </div>
            )}
          </div>

          <div className="grid gap-2">
            <Label htmlFor="date" className="text-[10px] font-black uppercase tracking-widest text-muted-foreground ml-1">DATE</Label>
            <Input
              id="date"
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              required
              className="h-11 font-bold border-primary/10 focus-visible:ring-primary rounded-md bg-background"
            />
          </div>
        </div>
      </div>

      {showButtons && (
        <footer className={cn("p-4 border-t bg-background shrink-0 grid gap-3", initialData ? "grid-cols-3" : "grid-cols-2")}>
          <Button 
            type="submit" 
            className={cn(
              "w-full font-black text-xs uppercase tracking-widest h-12 shadow-lg transition-all active:scale-95 text-white border-none",
              isPayment ? "bg-[#e74c3c]" : "bg-[#27ae60]"
            )}
          >
            {initialData ? 'SAVE CHANGES' : `SAVE ${isPayment ? 'PAYMENT' : 'RECEIVED'}`}
          </Button>

          {initialData && (
            <Button 
              type="button" 
              onClick={onDelete} 
              className="w-full font-black text-xs uppercase tracking-widest h-12 shadow-lg transition-all active:scale-95 bg-primary text-white hover:bg-primary/90 border-none"
            >
              DELETE
            </Button>
          )}

          <Button 
            type="button" 
            variant="outline" 
            onClick={onCancel} 
            className="w-full font-black text-xs uppercase tracking-widest h-12 border-primary/20 text-primary hover:bg-primary/5 transition-all active:scale-95"
          >
            CANCEL
          </Button>
        </footer>
      )}
    </form>
  );
}

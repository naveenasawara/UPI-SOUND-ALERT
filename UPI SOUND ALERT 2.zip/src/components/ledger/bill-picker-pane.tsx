"use client"

import { useMemo, useState, useRef } from 'react';
import { Customer, LedgerEntry } from "@/app/lib/types";
import { Button } from "@/components/ui/button";
import { 
  Search, 
  ArrowUp,
  ArrowDown,
  ArrowLeft
} from "lucide-react";
import { cn, formatCurrency } from "@/lib/utils";
import { format, parseISO } from "date-fns";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

interface BillPickerPaneProps {
  customers: (Customer & { lastActivityAt?: number, isBadDebt?: boolean })[];
  entries: LedgerEntry[];
  selectedCustomerId: string | null;
  setSelectedCustomerId: (id: string | null) => void;
  selectedEntryIds: string[];
  setSelectedEntryIds: (ids: string[] | ((prev: string[]) => string[])) => void;
  batchCustomerIds: string[];
  setBatchCustomerIds: (ids: string[] | ((prev: string[]) => string[])) => void;
  onGenerateBatch: (ids: string[]) => void;
  onClose: () => void;
  businessName: string;
  businessLogo?: string | null;
}

export function BillPickerPane({ 
  customers, 
  entries, 
  selectedCustomerId,
  setSelectedCustomerId,
  selectedEntryIds,
  setSelectedEntryIds,
  batchCustomerIds,
  setBatchCustomerIds,
  onClose
}: BillPickerPaneProps) {
  const [customerSearch, setCustomerSearch] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);
  
  const filteredCustomers = useMemo(() => {
    return customers.filter(c => 
      c.name.toLowerCase().includes(customerSearch.toLowerCase())
    ).sort((a, b) => a.name.localeCompare(b.name));
  }, [customers, customerSearch]);

  const customerEntries = useMemo(() => {
    if (!selectedCustomerId) return [];
    return entries
      .filter(e => e.customerId === selectedCustomerId)
      .sort((a, b) => parseISO(b.date).getTime() - parseISO(a.date).getTime());
  }, [entries, selectedCustomerId]);

  const toggleEntry = (id: string) => {
    setSelectedEntryIds((prev: string[]) => prev.includes(id) ? prev.filter(eId => eId !== id) : [...prev, id]);
  };

  const toggleBatchCustomer = (id: string) => {
    setBatchCustomerIds((prev: string[]) => prev.includes(id) ? prev.filter(cId => cId !== id) : [...prev, id]);
  };

  return (
    <div className="flex flex-col h-full bg-background overflow-hidden box-border">
      {!selectedCustomerId ? (
        <div className="flex flex-col flex-1 min-h-0">
          <div className="search-bar-card" onClick={() => inputRef.current?.focus()}>
            <Search className="h-4 w-4 text-muted-foreground ml-2" />
            <Input 
              ref={inputRef}
              placeholder="Search customer..." 
              value={customerSearch} 
              onChange={(e) => setCustomerSearch(e.target.value)} 
              className="border-none bg-transparent focus-visible:ring-0 h-9 text-[14px] font-bold shadow-none"
            />
          </div>

          <div className="flex-1 overflow-y-auto p-2 custom-scrollbar">
            {filteredCustomers.map(c => {
              const isBatchSelected = batchCustomerIds.includes(c.id);
              const statusColor = c.isBadDebt ? "var(--color-bad-debts)" : (c.balance > 0 ? "var(--color-payment)" : (c.balance === 0 ? "var(--color-settled)" : "var(--color-received)"));
              return (
                <div 
                  key={c.id} 
                  onClick={(e) => {
                    if (e.ctrlKey) toggleBatchCustomer(c.id);
                    else setSelectedCustomerId(c.id);
                  }}
                  className={cn(
                    "ledger-row flex items-center justify-between px-4 h-[60px] cursor-pointer mb-0.5",
                    isBatchSelected && "bg-primary/5"
                  )}
                  style={{ '--status-color': statusColor } as any}
                >
                  <div className="flex items-center gap-4">
                    <Avatar className="h-10 w-10 border-2 border-primary/10 avatar-lock">
                      <AvatarImage src={c.avatarUrl} className="object-cover" />
                      <AvatarFallback className="font-black text-[14px]">{c.name.charAt(0)}</AvatarFallback>
                    </Avatar>
                    <div className="flex flex-col">
                      <span className="font-bold text-[14px] text-foreground truncate">{c.name}</span>
                      <span className="text-[11px] text-slate-400 font-semibold">{c.lastActivityAt ? format(c.lastActivityAt, 'dd/MM/yy') : 'No activity'}</span>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className={cn("font-bold text-[14px]", c.balance > 0 ? "text-[#e74c3c]" : "text-[#27ae60]")}>Rs. {formatCurrency(Math.abs(c.balance))}</div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      ) : (
        <div className="flex flex-col flex-1 min-h-0">
          <div className="p-3 bg-primary/5 border-b shrink-0">
            <div onClick={() => setSelectedCustomerId(null)} className="flex items-center justify-between p-3 bg-background border-2 border-primary rounded-xl cursor-pointer shadow-md">
              <div className="flex items-center gap-3">
                <Avatar className="h-9 w-9 border-2 border-primary avatar-lock">
                  <AvatarFallback className="font-black">{customers.find(c => c.id === selectedCustomerId)?.name.charAt(0)}</AvatarFallback>
                </Avatar>
                <div className="flex flex-col">
                  <span className="font-black text-[13px] text-foreground">{customers.find(c => c.id === selectedCustomerId)?.name}</span>
                  <span className="text-[9px] font-black text-primary uppercase">Selected for Bill</span>
                </div>
              </div>
              <Button variant="ghost" size="sm" className="h-8 font-black text-[10px] uppercase text-primary">Change</Button>
            </div>
          </div>

          <div className="flex-1 overflow-y-auto p-2 custom-scrollbar">
            {customerEntries.map((e) => {
              const isChecked = selectedEntryIds.includes(e.id);
              const statusColor = e.type === 'payment' ? 'var(--color-payment)' : 'var(--color-received)';
              return (
                <div 
                  key={e.id} 
                  onClick={() => toggleEntry(e.id)}
                  className={cn("ledger-row flex items-center justify-between px-4 h-[60px] cursor-pointer mb-0.5", isChecked && "bg-primary/5")}
                  style={{ '--status-color': statusColor } as any}
                >
                  <div className="flex items-center gap-3">
                    <div className={cn("h-10 w-10 rounded-full flex items-center justify-center shrink-0 border border-current/10 status-lock", e.type === 'payment' ? "bg-[#e74c3c]/15 text-[#e74c3c]" : "bg-[#27ae60]/15 text-[#27ae60]")}>
                      {e.type === 'payment' ? <ArrowUp className="h-4 w-4" /> : <ArrowDown className="h-4 w-4" />}
                    </div>
                    <div className="flex flex-col">
                      <span className="font-bold text-[14px]">{e.description || 'Details'}</span>
                      <span className="text-[10px] font-black text-slate-400 uppercase">{format(parseISO(e.date), 'dd/MM/yy')}</span>
                    </div>
                  </div>
                  <div className={cn("font-black text-[14px]", e.type === 'payment' ? "text-[#e74c3c]" : "text-[#27ae60]")}>Rs. {formatCurrency(e.amount)}</div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      <div className="h-[70px] p-3 border-t bg-background shrink-0 flex items-center">
        <Button onClick={onClose} className="w-full h-11 bg-primary text-white font-black text-xs uppercase tracking-widest shadow-lg rounded-xl">
          <ArrowLeft className="h-4 w-4 mr-2" /> RETURN TO LEDGER
        </Button>
      </div>
    </div>
  );
}
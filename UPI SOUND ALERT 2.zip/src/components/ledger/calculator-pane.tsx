
"use client"

import { useState, useEffect, useCallback } from 'react';
import { Button } from "@/components/ui/button";
import { Calculator, X, ArrowLeft } from "lucide-react";
import { Card } from "@/components/ui/card";
import { cn } from "@/lib/utils";
import { CalculationHistory } from '@/app/lib/types';

interface CalculatorPaneProps {
  onClose: () => void;
  onAddHistory: (item: CalculationHistory) => void;
}

export function CalculatorPane({ onClose, onAddHistory }: CalculatorPaneProps) {
  const [display, setDisplay] = useState('0');
  const [equation, setEquation] = useState('');
  const [shouldReset, setShouldReset] = useState(false);

  const handleNumber = useCallback((num: string) => {
    setDisplay(prev => {
      if (prev === '0' || shouldReset) {
        setShouldReset(false);
        return num;
      }
      return prev + num;
    });
  }, [shouldReset]);

  const handleOperator = useCallback((op: string) => {
    setEquation(display + ' ' + op + ' ');
    setShouldReset(true);
  }, [display]);

  const handleEqual = useCallback(() => {
    if (!equation) return;
    try {
      const fullEquation = equation + display;
      const result = eval(fullEquation.replace('×', '*').replace('÷', '/'));
      const formattedResult = String(Number(result.toFixed(4)));
      
      const newHistoryItem: CalculationHistory = {
        id: crypto.randomUUID(),
        equation: fullEquation,
        result: formattedResult,
        timestamp: Date.now()
      };
      onAddHistory(newHistoryItem);

      setDisplay(formattedResult);
      setEquation('');
      setShouldReset(true);
    } catch (e) {
      setDisplay('Error');
      setEquation('');
      setShouldReset(true);
    }
  }, [equation, display, onAddHistory]);

  const handleConversion = useCallback((factor: number, label: string) => {
    try {
      const val = parseFloat(display);
      if (isNaN(val)) return;

      const result = val * factor;
      const formattedResult = String(Number(result.toFixed(4)));

      const newHistoryItem: CalculationHistory = {
        id: crypto.randomUUID(),
        equation: `${display} ${label}`,
        result: formattedResult,
        timestamp: Date.now()
      };
      onAddHistory(newHistoryItem);

      setDisplay(formattedResult);
      setEquation('');
      setShouldReset(true);
    } catch (e) {
      setDisplay('Error');
    }
  }, [display, onAddHistory]);

  const handleClear = useCallback(() => {
    setDisplay('0');
    setEquation('');
    setShouldReset(false);
  }, []);

  const handleDelete = useCallback(() => {
    setDisplay(prev => {
      if (prev.length > 1) {
        return prev.slice(0, -1);
      }
      return '0';
    });
  }, []);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key >= '0' && e.key <= '9') {
        handleNumber(e.key);
      } else if (['+', '-', '*', '/'].includes(e.key)) {
        const op = e.key === '*' ? '×' : e.key === '/' ? '÷' : e.key;
        handleOperator(op);
      } else if (e.key === 'Enter' || e.key === '=') {
        e.preventDefault();
        handleEqual();
      } else if (e.key === 'Backspace') {
        e.preventDefault();
        handleDelete();
      } else if (e.key === 'Escape' || e.key.toLowerCase() === 'c') {
        handleClear();
      } else if (e.key === '.') {
        if (!display.includes('.')) handleNumber('.');
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleNumber, handleOperator, handleEqual, handleClear, handleDelete, display]);

  const CalculatorButton = ({ label, onClick, className, variant = "outline" }: any) => {
    const isBigSymbol = ['+', '-', '×', '÷', '='].includes(label);
    
    return (
      <button
        onClick={onClick}
        className={cn(
          "h-[46px] md:h-[52px] flex items-center justify-center rounded-xl font-black uppercase tracking-[0.1em] transition-all active:scale-95 shadow-md border-2 bg-card",
          isBigSymbol ? "text-[18px] md:text-[20px]" : "text-[14px] md:text-[15px]",
          variant === "destructive" ? "bg-destructive/5 text-destructive border-destructive/20 hover:bg-destructive/10" : "hover:bg-muted/50 border-muted text-foreground",
          className
        )}
      >
        {label}
      </button>
    );
  };

  return (
    <div className="flex flex-col h-full bg-background overflow-hidden">
      <div className="flex-1 p-2 md:p-4 flex flex-col items-center justify-center min-h-0 bg-muted/10">
        <Card className="w-full max-w-[440px] p-3 bg-card border-2 border-primary/10 shadow-2xl rounded-[1.5rem]">
          <div className="bg-background border-2 border-primary/20 rounded-2xl p-4 mb-3 text-right shadow-inner min-h-[80px] md:min-h-[90px] flex flex-col justify-end">
            <div className="text-[10px] font-black text-muted-foreground h-3 uppercase tracking-[0.1em] truncate mb-1">
              {equation}
            </div>
            <div className="text-3xl md:text-4xl font-black text-primary truncate tracking-tighter">
              {display}
            </div>
          </div>

          <div className="grid grid-cols-4 gap-2">
            <CalculatorButton 
              label="mm to inch" 
              onClick={() => handleConversion(0.0393701, "mm to inch")} 
              className="col-span-2 bg-indigo-50/50 text-indigo-700 border-indigo-200/50 hover:bg-indigo-100/50 dark:bg-indigo-900/20 dark:text-indigo-300 dark:border-indigo-800" 
            />
            <CalculatorButton 
              label="inch to mm" 
              onClick={() => handleConversion(25.4, "inch to mm")} 
              className="col-span-2 bg-indigo-50/50 text-indigo-700 border-indigo-200/50 hover:bg-indigo-100/50 dark:bg-indigo-900/20 dark:text-indigo-300 dark:border-indigo-800" 
            />
            <CalculatorButton 
              label="cm to inch" 
              onClick={() => handleConversion(0.393701, "cm to inch")} 
              className="col-span-2 bg-indigo-50/50 text-indigo-700 border-indigo-200/50 hover:bg-indigo-100/50 dark:bg-indigo-900/20 dark:text-indigo-300 dark:border-indigo-800" 
            />
            <CalculatorButton 
              label="inch to cm" 
              onClick={() => handleConversion(2.54, "inch to cm")} 
              className="col-span-2 bg-indigo-50/50 text-indigo-700 border-indigo-200/50 hover:bg-indigo-100/50 dark:bg-indigo-900/20 dark:text-indigo-300 dark:border-indigo-800" 
            />
            
            <CalculatorButton label="C" onClick={handleClear} variant="destructive" className="col-span-2" />
            <CalculatorButton label="DEL" onClick={handleDelete} className="bg-orange-50/50 text-orange-600 border-orange-200/50 hover:bg-orange-100/50 dark:bg-orange-900/20 dark:text-orange-300 dark:border-orange-800" />
            <CalculatorButton label="+" onClick={() => handleOperator('+')} className="text-primary bg-primary/5 border-primary/20" />
            
            <CalculatorButton label="7" onClick={() => handleNumber('7')} />
            <CalculatorButton label="8" onClick={() => handleNumber('8')} />
            <CalculatorButton label="9" onClick={() => handleNumber('9')} />
            <CalculatorButton label="-" onClick={() => handleOperator('-')} className="text-primary bg-primary/5 border-primary/20" />
            
            <CalculatorButton label="4" onClick={() => handleNumber('4')} />
            <CalculatorButton label="5" onClick={() => handleNumber('5')} />
            <CalculatorButton label="6" onClick={() => handleNumber('6')} />
            <CalculatorButton label="×" onClick={() => handleOperator('×')} className="text-primary bg-primary/5 border-primary/20" />
            
            <CalculatorButton label="1" onClick={() => handleNumber('1')} />
            <CalculatorButton label="2" onClick={() => handleNumber('2')} />
            <CalculatorButton label="3" onClick={() => handleNumber('3')} />
            <CalculatorButton label="÷" onClick={() => handleOperator('÷')} className="text-primary bg-primary/5 border-primary/20" />
            
            <CalculatorButton label="0" onClick={() => handleNumber('0')} className="col-span-2" />
            <CalculatorButton label="." onClick={() => !display.includes('.') && handleNumber('.')} />
            <CalculatorButton label="=" onClick={handleEqual} className="bg-primary text-white hover:bg-primary/90 border-primary shadow-xl" />
          </div>
        </Card>
      </div>

      <div className="h-[70px] p-3 border-t bg-background shrink-0 flex items-center justify-center z-20">
        <Button 
          onClick={onClose}
          className="w-full h-11 bg-primary hover:bg-primary/90 text-white font-black text-xs uppercase tracking-[0.2em] shadow-lg flex items-center justify-center gap-2 transition-all active:scale-[0.98] rounded-xl"
        >
          <ArrowLeft className="h-4 w-4" />
          RETURN TO LEDGER
        </Button>
      </div>
    </div>
  );
}

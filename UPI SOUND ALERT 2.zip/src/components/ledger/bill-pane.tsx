
"use client"

// This component has been split into BillPickerPane and BillPreviewPane
// for a professional split-screen dashboard layout.
export { BillPickerPane } from './bill-picker-pane';
export { BillPreviewPane } from './bill-preview-pane';

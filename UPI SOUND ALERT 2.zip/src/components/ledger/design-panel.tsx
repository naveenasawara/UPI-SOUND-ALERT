"use client"

import { Button } from "@/components/ui/button";
import { 
  Sparkles, 
  X, 
  Zap
} from "lucide-react";

interface DesignPanelProps {
  onClose: () => void;
  onMasterReset: () => void;
}

export function DesignPanel({ 
  onClose, 
  onMasterReset
}: DesignPanelProps) {
  return (
    <div className="absolute inset-0 z-[100] bg-background border-l flex flex-col overflow-hidden animate-in slide-in-from-right duration-300 shadow-2xl">
      <header className="sticky top-0 z-50 flex items-center justify-between px-6 h-[60px] border-b shrink-0 bg-background">
        <div className="flex items-center gap-3">
          <Sparkles className="h-5 w-5 text-primary" />
          <h2 className="text-sm font-black uppercase tracking-[0.2em] text-foreground">System Maintenance</h2>
        </div>
        <Button variant="ghost" size="icon" onClick={onClose} className="h-9 w-9 hover:bg-destructive/10 hover:text-destructive transition-colors">
          <X className="h-5 w-5" />
        </Button>
      </header>

      <div className="flex-1 overflow-y-auto custom-scrollbar p-6 space-y-8 bg-muted/10">
        <div className="p-8 text-center space-y-4">
          <div className="h-16 w-16 bg-primary/10 text-primary rounded-full flex items-center justify-center mx-auto mb-4">
            <Zap className="h-8 w-8" />
          </div>
          <h3 className="text-lg font-black uppercase tracking-tight text-foreground">Operational Safety</h3>
          <p className="text-xs font-bold text-muted-foreground uppercase leading-relaxed max-w-xs mx-auto">
            Design preferences have been migrated to System Settings. This desk now handles high-level database recovery.
          </p>
        </div>
      </div>

      <footer className="sticky bottom-0 z-50 p-4 border-t bg-background shrink-0">
        <Button 
          onClick={onMasterReset}
          className="w-full h-14 bg-primary hover:bg-primary/90 text-white font-black text-sm uppercase tracking-[0.2em] shadow-2xl flex items-center justify-center gap-3 transition-all active:scale-95 rounded-2xl"
        >
          <Zap className="h-5 w-5 fill-white" />
          MASTER RESET SYSTEM
        </Button>
      </footer>
    </div>
  );
}
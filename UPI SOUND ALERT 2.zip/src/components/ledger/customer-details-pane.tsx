"use client"

import { Customer, LedgerEntry, Company } from "@/app/lib/types";
import { Button } from "@/components/ui/button";
import { 
  Trash2, Search, ArrowUp, ArrowDown, ArrowLeft
} from "lucide-react";
import { cn, formatCurrency } from '@/lib/utils';
import { useMemo, useRef, useState } from "react";
import { Input } from "@/components/ui/input";
import { format, parseISO } from 'date-fns';
import { TransactionForm } from "./transaction-form";
import { CustomerForm } from "./customer-form";

interface CustomerDetailsPaneProps {
  customer: Customer;
  entries: LedgerEntry[];
  allEntries: LedgerEntry[];
  allCustomers: Customer[];
  businessName: string;
  businessLogo?: string | null;
  currentCompany: Company | null;
  activeAction: 'edit' | 'pdf' | 'delete' | null;
  onActionChange: (action: 'edit' | 'pdf' | 'delete' | null) => void;
  activeEntryType: 'payment' | 'received' | 'forward' | null;
  setActiveEntryType: (type: 'payment' | 'received' | 'forward' | null) => void;
  onSaveEntry: (customerId: string, data: any) => void;
  onUpdateEntry: (id: string, customerId: string, data: any) => void;
  onDeleteEntry: (id: string) => void;
  onUpdateCustomer: (id: string, data: Partial<Customer>) => void;
  onDeleteCustomer: (id: string) => void;
  onCopySummary: (start: Date, end: Date, selectedIds?: string[]) => void;
  selectedIds: string[];
  setSelectedIds: (ids: string[] | ((prev: string[]) => string[])) => void;
  viewDate: Date;
  searchQuery?: string;
  onSearchChange?: (q: string) => void;
  activeHeaderAnimation?: string;
  headerAnimVariants?: Record<string, any>;
  currentPinned?: any[];
  isSplitMode?: boolean;
}

export function CustomerDetailsPane({ 
  customer, 
  entries, 
  allCustomers,
  activeAction, 
  onActionChange, 
  activeEntryType, 
  setActiveEntryType, 
  onSaveEntry, 
  onUpdateEntry, 
  onDeleteEntry, 
  onUpdateCustomer, 
  selectedIds, 
  setSelectedIds, 
  searchQuery = '',
  onSearchChange,
  currentPinned = [],
  isSplitMode = false
}: CustomerDetailsPaneProps) {
  const scrollRef = useRef<HTMLDivElement>(null);
  const [entryToDeleteId, setEntryToDeleteId] = useState<string | null>(null);
  const [entryToEdit, setEntryToEdit] = useState<LedgerEntry | null>(null);
  const [lastClickedId, setLastClickedId] = useState<string | null>(null);

  const displayEntries = useMemo(() => {
    const sorted = [...entries].sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
    let runningTotal = 0;
    const sortedChronologically = [...entries].sort((a, b) => parseISO(a.date).getTime() - parseISO(b.date).getTime());
    const balanceMap: Record<string, number> = {};
    sortedChronologically.forEach(e => {
      if (e.type !== 'forward') runningTotal += (e.type === 'payment' ? e.amount : -e.amount);
      balanceMap[e.id] = runningTotal;
    });

    return sorted.map(e => ({ ...e, runningBalance: balanceMap[e.id] })).filter(e => {
      if (!searchQuery.trim()) return true;
      return e.description.toLowerCase().includes(searchQuery.toLowerCase()) || e.amount.toString().includes(searchQuery);
    });
  }, [entries, searchQuery]);

  const handleEntryClick = (id: string, e: React.MouseEvent) => {
    if (e.ctrlKey || e.metaKey) {
      if (!lastClickedId) {
        setSelectedIds(prev => prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]);
      } else {
        const currentIndex = displayEntries.findIndex(item => item.id === id);
        const lastIndex = displayEntries.findIndex(item => item.id === lastClickedId);
        if (currentIndex !== -1 && lastIndex !== -1) {
          const start = Math.min(currentIndex, lastIndex);
          const end = Math.max(currentIndex, lastIndex);
          const rangeIds = displayEntries.slice(start, end + 1).map(item => item.id);
          setSelectedIds(prev => Array.from(new Set([...prev, ...rangeIds])));
        }
      }
    } else {
      setSelectedIds(prev => prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]);
    }
    setLastClickedId(id);
  };

  const renderEntryRow = (entry: any) => {
    const isBadDebts = entry.description.toLowerCase().trim() === 'bad debts';
    const isSelected = selectedIds.includes(entry.id);
    const statusColor = isBadDebts ? "var(--color-bad-debts)" : (entry.type === 'payment' ? "var(--color-payment)" : "var(--color-received)");

    return (
      <div 
        key={entry.id} 
        onClick={(e) => handleEntryClick(entry.id, e)}
        className={cn(
          "ledger-row group w-full flex items-center justify-between px-4 border-b h-[60px] mb-0.5 cursor-pointer select-none transition-colors",
          isSelected ? "bg-primary/10" : "bg-background"
        )} 
        style={{ '--status-color': statusColor } as any}
        onDoubleClick={() => setEntryToEdit(entry)}
      >
        <div className="flex items-center gap-4 w-full">
          <div className={cn(
            "h-10 w-10 rounded-full flex items-center justify-center shrink-0 border border-current/10 status-lock",
            isBadDebts ? "bg-[#f97316]/15 text-[#f97316]" : (entry.type === 'payment' ? "bg-[#e74c3c]/15 text-[#e74c3c]" : "bg-[#27ae60]/15 text-[#27ae60]")
          )}>
            {entry.type === 'payment' ? <ArrowUp className="h-4 w-4 icon-lock" /> : <ArrowDown className="h-4 w-4 icon-lock" />}
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex justify-between items-center w-full">
              <span className="font-bold text-[14px] text-foreground truncate">
                {/^\d/.test(entry.description) ? `Des No. ${entry.description}` : (entry.description || 'Details')}
              </span>
              <span className={cn(
                "font-black text-[14px] pr-2",
                entry.type === 'payment' ? "text-[#e74c3c]" : "text-[#27ae60]"
              )}>
                Rs. {formatCurrency(entry.amount)}
              </span>
            </div>
            <div className="flex justify-between items-center text-[12px] text-slate-400 font-semibold mt-1">
              <span>{format(parseISO(entry.date), 'dd/MM/yy')}</span>
              <span className="pr-2">Bal: Rs. {formatCurrency(Math.abs(entry.runningBalance || 0))}</span>
            </div>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="flex h-full flex-col bg-background overflow-hidden relative">
      <div className="search-bar-card">
        <div className="flex-1 flex items-center h-full">
          <div className="relative flex-1 h-9">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input 
              placeholder={`Search entries...`} 
              value={searchQuery} 
              onChange={(e) => onSearchChange?.(e.target.value)} 
              onFocus={() => setSelectedIds([])}
              className="pl-9 border-none bg-transparent focus-visible:ring-0 h-9 text-[13px] font-bold shadow-none" 
            />
          </div>
        </div>
        <div className="flex items-center gap-1.5 pr-2">
          {currentPinned.map((action: any) => (
            <Button 
              key={action.id} 
              variant="outline" 
              size="icon" 
              className={cn(
                "h-8 w-8 border-2 border-primary/20 text-primary",
                action.id === 'split' && isSplitMode && "bg-primary text-white"
              )} 
              onClick={action.onClick}
            >
              <action.icon className="h-4 w-4" />
            </Button>
          ))}
        </div>
      </div>

      <div 
        className="flex-1 bg-background custom-scrollbar persistent-scrollbar" 
        ref={scrollRef}
      >
        {displayEntries.map((entry) => renderEntryRow(entry))}
      </div>

      {!activeAction && !activeEntryType && !entryToEdit && !entryToDeleteId && (
        <footer className="h-[70px] p-3 border-t bg-background shrink-0 flex gap-3 items-center z-50">
          <button 
            onClick={() => setActiveEntryType('payment')} 
            className="flex-1 bg-[#e74c3c] hover:bg-[#c0392b] text-white font-black h-12 text-[14px] uppercase tracking-widest shadow-lg rounded-lg transition-all active:scale-95"
          >
            Payment Rs.
          </button>
          <button 
            onClick={() => setActiveEntryType('received')} 
            className="flex-1 bg-[#27ae60] hover:bg-[#1e8449] text-white font-black h-12 text-[14px] uppercase tracking-widest shadow-lg rounded-lg transition-all active:scale-95"
          >
            Received Rs.
          </button>
        </footer>
      )}

      {(activeAction || activeEntryType || entryToEdit || entryToDeleteId) && (
        <div className="absolute inset-0 z-[99] bg-background flex flex-col overflow-hidden animate-in fade-in duration-200">
            {activeAction === 'edit' && (
              <CustomerForm 
                initialData={customer} 
                existingCustomers={allCustomers} 
                onSubmit={(name, phones, emails, avatarUrl) => { 
                  onUpdateCustomer(customer.id, { name, phones, emails, avatarUrl }); 
                  onActionChange(null); 
                }} 
                onCancel={() => onActionChange(null)} 
              />
            )}
            {(activeEntryType || entryToEdit) && (
              <TransactionForm 
                type={entryToEdit ? entryToEdit.type : (activeEntryType === 'forward' ? 'forward' : (activeEntryType === 'received' ? 'received' : 'payment'))} 
                initialData={entryToEdit || undefined} 
                onSubmit={(data) => { 
                  if (entryToEdit) onUpdateEntry(entryToEdit.id, customer.id, data); 
                  else onSaveEntry(customer.id, data); 
                  setActiveEntryType(null); 
                  setEntryToEdit(null); 
                }} 
                onDelete={() => { 
                  if (entryToEdit) { 
                    setEntryToDeleteId(entryToEdit.id); 
                    setEntryToEdit(null); 
                  } 
                }} 
                onCancel={() => { 
                  setActiveEntryType(null); 
                  setEntryToEdit(null); 
                }} 
              />
            )}
            {entryToDeleteId && (
              <div className="flex-1 flex flex-col items-center justify-center p-6 space-y-4">
                 <div className="h-20 w-20 bg-destructive/10 text-destructive rounded-full flex items-center justify-center">
                    <Trash2 className="h-10 w-10" />
                 </div>
                 <h3 className="font-black uppercase tracking-widest text-lg">Remove Entry?</h3>
                 <p className="text-muted-foreground text-sm font-bold uppercase tracking-tighter text-center max-w-xs">
                   This transaction will be moved to the Recycle Bin.
                 </p>
                 <div className="flex gap-3 w-full max-w-xs pt-4">
                   <Button variant="destructive" className="flex-1 h-12 font-black uppercase text-xs" onClick={() => { onDeleteEntry(entryToDeleteId); setEntryToDeleteId(null); }}>DELETE</Button>
                   <Button variant="outline" className="flex-1 h-12 font-black uppercase text-xs" onClick={() => setEntryToDeleteId(null)}>CANCEL</Button>
                 </div>
              </div>
            )}
        </div>
      )}
    </div>
  );
}
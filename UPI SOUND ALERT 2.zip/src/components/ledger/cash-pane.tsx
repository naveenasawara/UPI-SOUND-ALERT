
"use client"

import { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Wallet, ArrowLeft, Plus, Save, X } from "lucide-react";
import { Card } from "@/components/ui/card";
import { cn } from "@/lib/utils";
import { CashEntry } from '@/app/lib/types';

interface CashPaneProps {
  onAddEntry: (amount: number, type: 'in' | 'out', remark: string) => void;
  onUpdateEntry: (id: string, amount: number, type: 'in' | 'out', remark: string) => void;
  onClose: () => void;
  editingEntry: CashEntry | null;
  onCancelEdit: () => void;
}

export function CashPane({ onAddEntry, onUpdateEntry, onClose, editingEntry, onCancelEdit }: CashPaneProps) {
  const [amount, setAmount] = useState('');
  const [isCashOut, setIsCashOut] = useState(false);
  const [remark, setRemark] = useState('');

  useEffect(() => {
    if (editingEntry) {
      setAmount(editingEntry.amount.toString());
      setIsCashOut(editingEntry.type === 'out');
      setRemark(editingEntry.remark || '');
    } else {
      setAmount('');
      setIsCashOut(false);
      setRemark('');
    }
  }, [editingEntry]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!amount || isNaN(parseFloat(amount))) return;
    
    if (editingEntry) {
      onUpdateEntry(editingEntry.id, parseFloat(amount), isCashOut ? 'out' : 'in', remark.trim());
      onCancelEdit();
    } else {
      onAddEntry(parseFloat(amount), isCashOut ? 'out' : 'in', remark.trim());
      setAmount('');
      setRemark('');
      setIsCashOut(false);
    }
  };

  return (
    <div className="flex flex-col h-full bg-background overflow-hidden">
      <div className="flex-1 p-3 flex flex-col bg-muted/20 items-center justify-center overflow-hidden">
        <Card className={cn(
          "w-full max-w-[480px] p-4 border-2 shadow-xl rounded-2xl bg-card transition-all",
          editingEntry ? "border-orange-500/20 shadow-orange-500/5" : "border-primary/10"
        )}>
          <div className="flex flex-col items-center mb-4">
            <div className={cn(
              "h-14 w-14 rounded-2xl flex items-center justify-center shadow-sm transition-colors",
              editingEntry ? "bg-orange-500/10 text-orange-500" : "bg-primary/10 text-primary"
            )}>
              <Wallet className="h-7 w-7" />
            </div>
            {editingEntry && (
              <div className="mt-2 flex items-center gap-2 px-3 py-1 bg-orange-500/10 text-orange-500 rounded-full">
                <span className="text-[10px] font-black uppercase tracking-widest">Update Mode</span>
                <button onClick={onCancelEdit} className="hover:text-orange-700">
                  <X className="h-3 w-3" />
                </button>
              </div>
            )}
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-1.5">
              <Label className="text-[10px] font-black uppercase tracking-widest text-muted-foreground ml-1">Amount (Rs.)</Label>
              <Input 
                type="text"
                inputMode="numeric"
                placeholder="0"
                value={amount}
                onChange={(e) => setAmount(e.target.value.replace(/\D/g, ''))}
                className="h-14 text-2xl font-black border-2 border-primary/10 focus-visible:ring-primary shadow-inner bg-background"
                required
                autoFocus
              />
            </div>

            <div className="flex items-center justify-between p-3.5 bg-muted/30 rounded-xl border-2 border-primary/5">
              <div className="flex flex-col">
                <span className={cn(
                  "text-sm font-black uppercase tracking-widest transition-colors",
                  isCashOut ? "text-[#e74c3c]" : "text-[#27ae60]"
                )}>
                  {isCashOut ? 'Cash Out' : 'Cash In'}
                </span>
                <span className="text-[9px] font-bold text-muted-foreground uppercase">Flow Direction</span>
              </div>
              <Switch 
                checked={isCashOut} 
                onCheckedChange={setIsCashOut}
                className="data-[state=checked]:bg-[#e74c3c] data-[state=unchecked]:bg-[#27ae60]"
              />
            </div>

            <div className="space-y-1.5">
              <Label className="text-[10px] font-black uppercase tracking-widest text-muted-foreground ml-1">Remark / Purpose</Label>
              <Input 
                placeholder="e.g. Office Rent, Tea, Lunch..."
                value={remark}
                onChange={(e) => setRemark(e.target.value)}
                className="h-11 font-bold border-2 border-primary/10 focus-visible:ring-primary shadow-inner bg-background"
              />
            </div>

            <div className="flex gap-3 pt-2">
              {editingEntry && (
                <Button 
                  type="button"
                  variant="outline"
                  onClick={onCancelEdit}
                  className="flex-1 h-12 font-black text-xs uppercase tracking-widest border-2 border-muted"
                >
                  CANCEL
                </Button>
              )}
              <Button 
                type="submit" 
                className={cn(
                  "flex-1 h-12 font-black text-xs uppercase tracking-widest shadow-lg transition-all active:scale-[0.98] text-white border-none",
                  editingEntry 
                    ? "bg-orange-500 hover:bg-orange-600" 
                    : (isCashOut ? "bg-[#e74c3c] hover:bg-[#c0392b]" : "bg-[#27ae60] hover:bg-[#1e8449]")
                )}
                disabled={!amount}
              >
                {editingEntry ? (
                  <><Save className="h-4 w-4 mr-2" /> UPDATE RECORD</>
                ) : (
                  <><Plus className="h-4 w-4 mr-2" /> RECORD {isCashOut ? 'OUT' : 'IN'}</>
                )}
              </Button>
            </div>
          </form>
        </Card>
      </div>

      <div className="h-[70px] p-3 border-t bg-background shrink-0 flex items-center justify-center z-20">
        <Button 
          onClick={onClose}
          className="w-full h-11 bg-primary hover:bg-primary/90 text-white font-black text-xs uppercase tracking-[0.2em] shadow-lg flex items-center justify-center gap-2 transition-all active:scale-[0.98] rounded-xl"
        >
          <ArrowLeft className="h-4 w-4" />
          RETURN TO LEDGER
        </Button>
      </div>
    </div>
  );
}

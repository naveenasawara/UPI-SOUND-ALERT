
"use client"

import { useState, useRef, useEffect, useMemo } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Upload, X, AlertCircle, Plus, Trash2, Phone, Mail, User } from "lucide-react";
import { Customer } from '@/app/lib/types';
import { cn } from '@/lib/utils';
import { formatToTitleCase } from '@/hooks/use-ledger';

interface CustomerFormProps {
  id?: string;
  initialData?: Customer;
  onSubmit: (name: string, phones: string[], emails: string[], avatarUrl?: string) => void;
  onCancel: () => void;
  onDelete?: () => void;
  showButtons?: boolean;
  existingCustomers?: Customer[];
}

export function CustomerForm({ 
  id,
  initialData, 
  onSubmit, 
  onCancel, 
  onDelete, 
  showButtons = true,
  existingCustomers = []
}: CustomerFormProps) {
  const [name, setName] = useState(initialData?.name || '');
  const [phones, setPhones] = useState<string[]>(() => {
    if (initialData?.phones?.length) return [...initialData.phones];
    // Compatibility for legacy data
    if ((initialData as any)?.phone) return [(initialData as any).phone];
    return [''];
  });
  const [emails, setEmails] = useState<string[]>(() => {
    if (initialData?.emails?.length) return [...initialData.emails];
    // Compatibility for legacy data
    if ((initialData as any)?.email) return [(initialData as any).email];
    return [''];
  });
  const [avatarUrl, setAvatarUrl] = useState<string>(initialData?.avatarUrl || '');
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  useEffect(() => {
    if (initialData) {
      setName(initialData.name);
      setPhones(initialData.phones?.length ? [...initialData.phones] : ([(initialData as any).phone || '']));
      setEmails(initialData.emails?.length ? [...initialData.emails] : ([(initialData as any).email || '']));
      setAvatarUrl(initialData.avatarUrl || '');
    }
  }, [initialData]);

  const isDuplicateName = useMemo(() => {
    if (!name.trim()) return false;
    const normalize = (val: string) => val.trim().toLowerCase().replace(/\s+/g, ' ');
    const normalizedNewName = normalize(name);
    return existingCustomers.some(c => {
      if (initialData && c.id === initialData.id) return false;
      return normalize(c.name) === normalizedNewName;
    });
  }, [name, existingCustomers, initialData]);

  const handleAddPhone = () => setPhones([...phones, '']);
  const handleRemovePhone = (index: number) => setPhones(phones.filter((_, i) => i !== index));
  const handlePhoneChange = (index: number, val: string) => {
    const newPhones = [...phones];
    newPhones[index] = val;
    setPhones(newPhones);
  };

  const handleAddEmail = () => setEmails([...emails, '']);
  const handleRemoveEmail = (index: number) => setEmails(emails.filter((_, i) => i !== index));
  const handleEmailChange = (index: number, val: string) => {
    const newEmails = [...emails];
    newEmails[index] = val;
    setEmails(newEmails);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => { setAvatarUrl(reader.result as string); };
      reader.readAsDataURL(file);
    }
  };

  // Relaxed phone validation: allow digits, spaces, dashes, dots, and plus. Minimum 10 characters.
  const isValidPhone = (p: string) => {
    const clean = p.replace(/[\s\-\.\+]/g, '');
    return clean.length >= 10 && /^\d+$/.test(clean);
  };
  
  const isValidEmail = (e: string) => !e.trim() || /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e.trim());

  const isFormValid = useMemo(() => {
    const primaryPhoneValid = phones[0] && isValidPhone(phones[0]);
    return name.trim() && 
           !isDuplicateName && 
           primaryPhoneValid && 
           phones.every(p => !p.trim() || isValidPhone(p)) &&
           emails.every(e => isValidEmail(e));
  }, [name, isDuplicateName, phones, emails]);

  const handleSubmit = (e?: React.FormEvent) => {
    if (e) {
      e.preventDefault();
      e.stopPropagation();
    }
    
    if (!name.trim()) { toast({ description: "Please enter a customer name.", variant: "destructive" }); return; }
    if (isDuplicateName) { toast({ description: "This name already exists.", variant: "destructive" }); return; }
    if (!phones[0] || !isValidPhone(phones[0])) { toast({ description: "Primary number must be at least 10 digits.", variant: "destructive" }); return; }
    
    const formattedName = formatToTitleCase(name);
    onSubmit(formattedName, phones, emails, avatarUrl || '');
  };

  const initials = name.trim() ? name.trim().charAt(0).toUpperCase() : '';

  return (
    <form id={id} onSubmit={handleSubmit} className="flex flex-col h-full overflow-hidden box-border">
      <div className="flex-1 overflow-y-auto p-6 space-y-6">
        <div className="flex flex-col items-center gap-4 mb-4">
          <div className="relative group">
            <Avatar className="h-20 w-20 border-2 border-primary shadow-md">
              <AvatarImage src={avatarUrl || undefined} alt={name} className="object-cover" />
              <AvatarFallback className="text-[24px] font-bold bg-primary text-white">
                {initials || <Upload className="h-6 w-6" />}
              </AvatarFallback>
            </Avatar>
            <button type="button" onClick={() => fileInputRef.current?.click()} className="absolute inset-0 bg-black/40 rounded-full opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center text-white"><Upload className="h-5 w-5" /></button>
          </div>
          <input type="file" ref={fileInputRef} onChange={handleFileChange} accept="image/*" className="hidden" />
          <p className="text-[11px] font-black tracking-widest text-muted-foreground uppercase">Identity Profile</p>
        </div>

        <div className="grid gap-6">
          <div className="grid gap-2">
            <Label htmlFor="name" className="text-[12px] font-black tracking-widest text-muted-foreground uppercase flex items-center gap-2">
              <User className="h-3.5 w-3.5" /> Customer Name
            </Label>
            <Input id="name" value={name} onChange={(e) => setName(e.target.value)} required autoFocus className={cn("h-11 font-bold border-primary/10 bg-background", isDuplicateName && "border-destructive")} />
          </div>

          <div className="grid gap-3">
            <div className="flex items-center justify-between">
              <Label className="text-[12px] font-black tracking-widest text-muted-foreground uppercase flex items-center gap-2">
                <Phone className="h-3.5 w-3.5" /> Mobile Numbers
              </Label>
              <Button type="button" variant="ghost" size="sm" onClick={handleAddPhone} className="h-7 text-[10px] font-black text-primary uppercase hover:bg-primary/5 px-2">
                <Plus className="h-3 w-3 mr-1" /> Add More
              </Button>
            </div>
            <div className="space-y-2">
              {phones.map((phone, index) => (
                <div key={index} className="flex gap-2 group animate-in slide-in-from-left-2 duration-200">
                  <div className="relative flex-1">
                    <Input 
                      value={phone} 
                      onChange={(e) => handlePhoneChange(index, e.target.value)} 
                      placeholder={index === 0 ? "Primary Mobile (Min 10 Digits)" : "Secondary Mobile"}
                      className={cn(
                        "h-10 font-bold border-primary/10 bg-background pl-12",
                        phone.trim() && !isValidPhone(phone) && "border-destructive/50"
                      )}
                    />
                    <div className="absolute left-3 top-1/2 -translate-y-1/2 text-[9px] font-black text-primary/40 uppercase pointer-events-none">
                      {index === 0 ? 'PRM' : `NO${index + 1}`}
                    </div>
                  </div>
                  {index > 0 && (
                    <Button type="button" variant="ghost" size="icon" onClick={() => handleRemovePhone(index)} className="h-10 w-10 text-destructive/40 hover:text-destructive hover:bg-destructive/5 border-2 border-transparent">
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  )}
                </div>
              ))}
            </div>
          </div>

          <div className="grid gap-3">
            <div className="flex items-center justify-between">
              <Label className="text-[12px] font-black tracking-widest text-muted-foreground uppercase flex items-center gap-2">
                <Mail className="h-3.5 w-3.5" /> Email Addresses
              </Label>
              <Button type="button" variant="ghost" size="sm" onClick={handleAddEmail} className="h-7 text-[10px] font-black text-primary uppercase hover:bg-primary/5 px-2">
                <Plus className="h-3 w-3 mr-1" /> Add More
              </Button>
            </div>
            <div className="space-y-2">
              {emails.map((email, index) => (
                <div key={index} className="flex gap-2 group animate-in slide-in-from-left-2 duration-200">
                  <div className="relative flex-1">
                    <Input 
                      type="email"
                      value={email} 
                      onChange={(e) => handleEmailChange(index, e.target.value)} 
                      placeholder={index === 0 ? "Primary Email" : "Secondary Email"}
                      className={cn(
                        "h-10 font-bold border-primary/10 bg-background pl-12",
                        email.trim() && !isValidEmail(email) && "border-destructive/50"
                      )}
                    />
                    <div className="absolute left-3 top-1/2 -translate-y-1/2 text-[9px] font-black text-primary/40 uppercase pointer-events-none">
                      {index === 0 ? 'EML' : `EM${index + 1}`}
                    </div>
                  </div>
                  {index > 0 && (
                    <Button type="button" variant="ghost" size="icon" onClick={() => handleRemoveEmail(index)} className="h-10 w-10 text-destructive/40 hover:text-destructive hover:bg-destructive/5 border-2 border-transparent">
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
      
      {showButtons && (
        <footer className={cn("p-4 border-t bg-background shrink-0 grid gap-3", initialData && onDelete ? "grid-cols-3" : "grid-cols-2")}>
          <Button type="submit" disabled={!isFormValid} className="w-full font-black text-xs uppercase tracking-widest h-12 bg-primary text-white hover:bg-primary/90 shadow-lg disabled:opacity-50">
            {initialData ? 'SAVE CHANGES' : 'ADD CUSTOMER'}
          </Button>
          {initialData && onDelete && (
            <Button type="button" variant="destructive" onClick={onDelete} className="w-full font-black text-xs uppercase tracking-widest h-12 shadow-lg">
              DELETE
            </Button>
          )}
          <Button type="button" variant="outline" onClick={onCancel} className="w-full font-black text-xs uppercase tracking-widest h-12 border-primary/20 text-primary hover:bg-primary/5">
            CANCEL
          </Button>
        </footer>
      )}
    </form>
  );
}

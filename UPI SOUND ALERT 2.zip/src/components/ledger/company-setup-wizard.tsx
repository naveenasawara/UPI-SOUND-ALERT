
"use client"

import { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Building2, ArrowRight, ArrowLeft, Loader2, ShieldCheck, User, Phone, MapPin, Mail } from 'lucide-react';
import { cn } from '@/lib/utils';

interface CompanySetupWizardProps {
  onSetup: (name: string, ownerName: string, mobile: string, address: string, email: string) => void;
  isLoading?: boolean;
}

export function CompanySetupWizard({ onSetup, isLoading }: CompanySetupWizardProps) {
  const [page, setPage] = useState(1);
  const [formData, setFormData] = useState({
    name: '',
    ownerName: '',
    mobile: '',
    address: '',
    email: ''
  });

  const handleNext = () => {
    if (formData.name && formData.ownerName && formData.mobile) {
      setPage(2);
    }
  };

  const handleBack = () => {
    setPage(1);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (page === 1) {
      handleNext();
    } else {
      onSetup(formData.name, formData.ownerName, formData.mobile, formData.address, formData.email);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-50 p-4">
      <Card className="w-full max-w-[480px] shadow-2xl border-2 animate-in zoom-in-95 duration-300">
        <CardHeader className="text-center space-y-2 pb-6">
          <div className="flex justify-center gap-1 mb-4">
            <div className={cn("h-1.5 w-12 rounded-full transition-colors", page >= 1 ? "bg-primary" : "bg-slate-200")} />
            <div className={cn("h-1.5 w-12 rounded-full transition-colors", page >= 2 ? "bg-primary" : "bg-slate-200")} />
          </div>
          <div className="h-14 w-14 bg-primary/10 text-primary rounded-2xl flex items-center justify-center mx-auto mb-2 shadow-sm">
            {page === 1 ? <Building2 className="h-7 w-7" /> : <MapPin className="h-7 w-7" />}
          </div>
          <CardTitle className="text-2xl font-black uppercase tracking-tight">
            {page === 1 ? 'Business Identity' : 'Business Location'}
          </CardTitle>
          <CardDescription className="text-[11px] font-bold uppercase tracking-widest text-muted-foreground max-w-xs mx-auto">
            {page === 1 ? "Tell us about your business & ownership" : "Provide your full business address"}
          </CardDescription>
        </CardHeader>

        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-5">
            {page === 1 ? (
              <div className="space-y-4 animate-in slide-in-from-right-4 duration-300">
                <div className="space-y-1.5">
                  <Label className="text-[10px] font-black uppercase tracking-widest text-muted-foreground ml-1 flex items-center gap-2">
                    <Building2 className="h-3 w-3" /> Company Name
                  </Label>
                  <Input 
                    autoFocus
                    placeholder="e.g. NA Designs" 
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    required
                    className="h-11 font-bold border-primary/20 bg-white shadow-inner"
                  />
                </div>
                <div className="space-y-1.5">
                  <Label className="text-[10px] font-black uppercase tracking-widest text-muted-foreground ml-1 flex items-center gap-2">
                    <User className="h-3 w-3" /> Owner Name
                  </Label>
                  <Input 
                    placeholder="Full Name" 
                    value={formData.ownerName}
                    onChange={(e) => setFormData({ ...formData, ownerName: e.target.value })}
                    required
                    className="h-11 font-bold border-primary/20 bg-white shadow-inner"
                  />
                </div>
                <div className="space-y-1.5">
                  <Label className="text-[10px] font-black uppercase tracking-widest text-muted-foreground ml-1 flex items-center gap-2">
                    <Phone className="h-3 w-3" /> Mobile Number
                  </Label>
                  <Input 
                    type="tel"
                    placeholder="+91-XXXXXXXXXX" 
                    value={formData.mobile}
                    onChange={(e) => setFormData({ ...formData, mobile: e.target.value })}
                    required
                    className="h-11 font-bold border-primary/20 bg-white shadow-inner"
                  />
                </div>
              </div>
            ) : (
              <div className="space-y-4 animate-in slide-in-from-right-4 duration-300">
                <div className="space-y-1.5">
                  <Label className="text-[10px] font-black uppercase tracking-widest text-muted-foreground ml-1 flex items-center gap-2">
                    <Mail className="h-3 w-3" /> Business Email
                  </Label>
                  <Input 
                    type="email"
                    placeholder="name@company.com" 
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    required
                    className="h-11 font-bold border-primary/20 bg-white shadow-inner"
                  />
                </div>
                <div className="space-y-1.5">
                  <Label className="text-[10px] font-black uppercase tracking-widest text-muted-foreground ml-1 flex items-center gap-2">
                    <MapPin className="h-3 w-3" /> Full Business Address
                  </Label>
                  <Textarea 
                    autoFocus
                    placeholder="Shop No, Street, City, Pincode..." 
                    value={formData.address}
                    onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                    required
                    className="min-h-[120px] font-bold border-primary/20 bg-white shadow-inner resize-none"
                  />
                </div>
                <div className="bg-primary/5 p-4 rounded-xl border border-primary/10 flex items-start gap-3">
                  <ShieldCheck className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                  <p className="text-[10px] font-bold text-primary/70 uppercase leading-relaxed">
                    This information will be used for your official ledger headers and PDF reports.
                  </p>
                </div>
              </div>
            )}

            <div className="flex gap-3 pt-2">
              {page === 2 && (
                <Button 
                  type="button" 
                  variant="outline"
                  onClick={handleBack}
                  className="w-1/3 h-12 font-black text-xs uppercase tracking-widest border-2"
                >
                  <ArrowLeft className="h-4 w-4 mr-2" /> Back
                </Button>
              )}
              <Button 
                type="submit" 
                disabled={isLoading || (page === 1 ? (!formData.name || !formData.ownerName || !formData.mobile) : !formData.address)}
                className={cn(
                  "h-12 font-black text-xs uppercase tracking-widest shadow-xl transition-all active:scale-[0.98]",
                  page === 1 ? "w-full" : "w-2/3 bg-primary hover:bg-primary/90 text-white"
                )}
              >
                {isLoading ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <>
                    {page === 1 ? (
                      <>Next Step <ArrowRight className="h-4 w-4 ml-2" /></>
                    ) : (
                      <>Finish Setup <ArrowRight className="h-4 w-4 ml-2" /></>
                    )}
                  </>
                )}
              </Button>
            </div>
          </form>
        </CardContent>
        <CardFooter className="justify-center pb-8 opacity-40">
           <p className="text-[9px] font-black uppercase tracking-widest text-center">
             High-Density Financial Onboarding • Page {page} of 2
           </p>
        </CardFooter>
      </Card>
    </div>
  );
}


"use client"

import { useMemo } from 'react';
import { LedgerEntry, Customer } from "@/app/lib/types";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Search, X, ChevronRight, ArrowLeft } from "lucide-react";
import { cn, formatCurrency } from "@/lib/utils";
import { format, parseISO } from "date-fns";

interface SearchPaneProps {
  entries: LedgerEntry[];
  customers: Customer[];
  query: string;
  setQuery: (q: string) => void;
  onSelectEntry: (entry: LedgerEntry) => void;
  onClose: () => void;
}

export function SearchPane({ entries, customers, query, setQuery, onSelectEntry, onClose }: SearchPaneProps) {
  const searchResults = useMemo(() => {
    if (!query.trim()) return [];
    
    const searchLower = query.toLowerCase();
    
    return entries.filter(e => {
      const dateStr = format(parseISO(e.date), 'dd/MM/yy').toLowerCase();
      return (
        e.description.toLowerCase().includes(searchLower) ||
        dateStr.includes(searchLower)
      );
    }).sort((a, b) => b.createdAt - a.createdAt);
  }, [entries, query]);

  const formatDescription = (desc: string) => {
    if (/^(\d{3,5}|\d+-\d+)$/.test(desc)) return <>Des No. <span style={{ fontSize: 'calc(1em + 1px)' }}>{desc}</span></>;
    return desc || 'No details';
  };

  return (
    <div className="flex flex-col h-full bg-background overflow-hidden box-border">
      <div className="h-[60px] border-b bg-muted/30 flex items-center px-4 shrink-0">
        <div className="relative w-full">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
          <Input 
            autoFocus
            placeholder="Des No or Date..." 
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="pl-12 h-11 border-2 border-primary/10 focus-visible:ring-primary font-bold text-sm bg-background"
          />
        </div>
      </div>

      <div className="flex-1 p-2 flex flex-col min-0 overflow-y-auto">
        {!query.trim() ? (
          <div className="flex-1 flex flex-col items-center justify-center text-center opacity-30 gap-4">
            <Search className="h-10 w-10" />
            <p className="font-black text-xs uppercase tracking-widest text-foreground">Global Ledger Search</p>
          </div>
        ) : searchResults.length === 0 ? (
          <div className="flex-1 flex flex-col items-center justify-center text-center p-8">
            <X className="h-10 w-10 text-destructive/40 mb-4" />
            <p className="text-sm font-bold text-muted-foreground uppercase">No matches found</p>
          </div>
        ) : (
          <div className="space-y-2 pb-4">
            {searchResults.map((entry) => {
              const customer = customers.find(c => c.id === entry.customerId);
              const statusColor = entry.type === 'payment' ? "var(--color-payment)" : "var(--color-received)";
              return (
                <div 
                  key={entry.id} 
                  className="ledger-row flex flex-col p-4 bg-card border-2 border-muted rounded-lg cursor-pointer transition-all active:scale-[0.99] group shadow-sm hover:border-primary/30"
                  style={{ '--status-color': statusColor } as any}
                  onClick={() => onSelectEntry(entry)}
                >
                  <div className="flex items-center justify-between mb-1">
                    <div className="flex items-center gap-2 min-w-0">
                      <div className="flex flex-col min-w-0">
                        <span className="text-[14px] font-black text-foreground truncate">
                          {customer?.name || 'Unknown'}
                        </span>
                        <span className="text-[10px] font-black text-muted-foreground uppercase tracking-widest flex items-center gap-1">
                          {format(parseISO(entry.date), 'dd MMM yyyy')}
                        </span>
                      </div>
                    </div>
                    <div className="flex flex-col items-end shrink-0 pl-4">
                      <span className={cn(
                        "font-black text-[16px] leading-tight",
                        entry.type === 'payment' ? "text-[#e74c3c]" : "text-[#27ae60]"
                      )}>
                        {formatCurrency(entry.amount)}
                      </span>
                    </div>
                  </div>
                  <div className="flex items-center justify-between pt-2 border-t border-muted mt-1">
                    <span className="text-[12px] font-bold text-muted-foreground">
                      {formatDescription(entry.description)}
                    </span>
                    <ChevronRight className="h-4 w-4 text-muted group-hover:text-primary transition-colors" />
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      <div className="h-[70px] p-3 border-t bg-background shrink-0 flex items-center justify-center">
        <Button 
          onClick={onClose}
          className="w-full h-11 bg-primary hover:bg-primary/90 text-white font-black text-xs uppercase tracking-[0.2em] shadow-lg flex items-center justify-center gap-2 transition-all active:scale-[0.98] rounded-xl"
        >
          <ArrowLeft className="h-4 w-4" />
          RETURN TO LEDGER
        </Button>
      </div>
    </div>
  );
}

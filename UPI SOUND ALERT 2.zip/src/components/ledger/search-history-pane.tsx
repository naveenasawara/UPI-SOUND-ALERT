
"use client"

import { LedgerEntry, Customer } from "@/app/lib/types";
import { Button } from "@/components/ui/button";
import { History, Trash2, Search, ChevronRight } from "lucide-react";
import { Card } from "@/components/ui/card";
import { format, parseISO } from 'date-fns';
import { cn, formatCurrency } from "@/lib/utils";

interface SearchHistoryPaneProps {
  history: LedgerEntry[];
  customers: Customer[];
  onSelectEntry: (entry: LedgerEntry) => void;
  onClear: () => void;
}

export function SearchHistoryPane({ history, customers, onSelectEntry, onClear }: SearchHistoryPaneProps) {
  const formatDescription = (desc: string) => {
    if (/^(\d{3,5}|\d+-\d+)$/.test(desc)) return <>Des No. <span style={{ fontSize: 'calc(1em + 1px)' }}>{desc}</span></>;
    return desc || 'No details';
  };

  return (
    <div className="h-full flex flex-col bg-background animate-in fade-in duration-500 overflow-hidden">
      <div className="flex-1 overflow-y-auto p-6 space-y-4 bg-muted/20">
        {history.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center text-center max-md mx-auto space-y-4 opacity-30">
            <div className="h-20 w-20 bg-muted text-muted-foreground rounded-3xl flex items-center justify-center shadow-inner">
               <Search className="h-10 w-10" />
            </div>
            <p className="font-black text-sm uppercase tracking-[0.3em] text-foreground">No Recent History</p>
            <p className="text-[10px] font-bold uppercase text-muted-foreground">Search for Des No. on the left</p>
          </div>
        ) : (
          <div className="max-w-2xl mx-auto w-full space-y-3">
            {history.map((entry) => {
              const customer = customers.find(c => c.id === entry.customerId);
              return (
                <Card 
                  key={entry.id} 
                  className="p-4 border-2 border-muted hover:border-primary/20 transition-all cursor-pointer shadow-sm bg-card group flex items-center justify-between select-none active:scale-[0.99]"
                  onClick={() => onSelectEntry(entry)}
                >
                  <div className="flex flex-col min-w-0 flex-1">
                    <span className="font-black text-[14px] text-foreground truncate group-hover:text-primary transition-colors">
                      {customer?.name || 'Unknown'}
                    </span>
                    <div className="flex items-center gap-2 mt-1">
                      <span className="text-[10px] font-black text-muted-foreground uppercase tracking-widest">
                        {format(parseISO(entry.date), 'dd MMM yyyy')}
                      </span>
                      <span className="text-[12px] font-bold text-muted-foreground">
                        • {formatDescription(entry.description)}
                      </span>
                    </div>
                  </div>
                  <div className="flex items-center gap-4 shrink-0 pl-4">
                    <span className={cn(
                      "font-black text-[15px] tracking-tight",
                      entry.type === 'payment' ? "text-[#e74c3c]" : "text-[#27ae60]"
                    )}>
                      Rs. {formatCurrency(entry.amount)}
                    </span>
                    <ChevronRight className="h-4 w-4 text-muted group-hover:text-primary transition-colors" />
                  </div>
                </Card>
              );
            })}
          </div>
        )}
      </div>

      {/* Action Footer */}
      {history.length > 0 && (
        <div className="h-[70px] p-3 border-t bg-background shrink-0 flex items-center justify-center">
          <Button 
            onClick={onClear}
            className="w-full h-11 bg-background border-2 border-destructive text-destructive hover:bg-destructive/5 font-black text-xs uppercase tracking-[0.2em] shadow-lg flex items-center justify-center gap-2 transition-all active:scale-[0.98] rounded-xl"
          >
            <Trash2 className="h-4 w-4" />
            PURGE SEARCH HISTORY
          </Button>
        </div>
      )}
    </div>
  );
}

"use client"

import { useState, useMemo, useRef, useEffect } from 'react';
import { Customer } from "@/app/lib/types";
import { Button } from "@/components/ui/button";
import { 
  Phone, 
  Mail, 
  ArrowLeft,
  Briefcase,
  ShieldCheck,
  X,
  Search
} from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Card } from "@/components/ui/card";
import { cn, formatCurrency } from "@/lib/utils";
import { Label } from "../ui/label";
import { Input } from "../ui/input";

interface CustomerInfoPaneProps {
  customer: Customer;
  customers: Customer[];
  onSelectCustomer: (id: string) => void;
  onClose: () => void;
}

export function CustomerInfoPane({ customer, customers, onSelectCustomer, onClose }: CustomerInfoPaneProps) {
  const [query, setQuery] = useState('');
  const [isOpen, setIsOpen] = useState(false);
  const searchRef = useRef<HTMLDivElement>(null);

  const filtered = useMemo(() => {
    if (!query.trim()) return [];
    return customers.filter(c => 
      c.name.toLowerCase().includes(query.toLowerCase())
    ).slice(0, 5);
  }, [query, customers]);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const initials = customer.name.charAt(0).toUpperCase();
  const isBadDebt = customer.isBadDebt;
  const isPayment = customer.balance > 0;
  const isSettled = customer.balance === 0;
  const statusColor = isBadDebt ? "var(--color-bad-debts)" : (isPayment ? "var(--color-payment)" : (isSettled ? "var(--color-settled)" : "var(--color-received)"));

  return (
    <div className="flex flex-col h-full bg-background overflow-hidden animate-in fade-in slide-in-from-left-2 duration-300">
      <header className="flex items-center gap-3 px-4 h-[60px] border-b shrink-0 bg-background relative z-[100]">
        <div className="flex-1 relative" ref={searchRef}>
           <div className="search-bar-card !m-0 !h-[40px] !w-full">
              <Search className="h-4 w-4 text-muted-foreground ml-2" />
              <Input 
                placeholder="Search customers..." 
                value={query}
                onChange={(e) => { setQuery(e.target.value); setIsOpen(true); }}
                onFocus={() => setIsOpen(true)}
                className="border-none bg-transparent focus-visible:ring-0 h-full text-[13px] font-bold shadow-none"
              />
           </div>
           
           {isOpen && filtered.length > 0 && (
             <div className="absolute top-full left-0 right-0 mt-2 bg-background border-2 border-primary/20 shadow-2xl rounded-xl overflow-hidden animate-in fade-in slide-in-from-top-2 duration-200">
               {filtered.map(c => (
                 <div 
                   key={c.id} 
                   className="p-3 hover:bg-primary/5 cursor-pointer border-b last:border-b-0 flex items-center justify-between group"
                   onClick={() => { onSelectCustomer(c.id); setQuery(''); setIsOpen(false); }}
                 >
                   <div className="flex flex-col">
                     <span className="font-bold text-[13px] group-hover:text-primary transition-colors">{c.name}</span>
                     <span className="text-[10px] font-bold text-muted-foreground uppercase">{c.phones?.[0] || 'Contact'}</span>
                   </div>
                   <div className="text-right flex flex-col items-end">
                     <span className={cn(
                       "font-black text-[12px]",
                       c.balance > 0 ? "text-[#e74c3c]" : (c.balance < 0 ? "text-[#27ae60]" : "text-[#1468F0]")
                     )}>
                       Rs. {formatCurrency(Math.abs(c.balance || 0))}
                     </span>
                   </div>
                 </div>
               ))}
             </div>
           )}
        </div>
        <Button variant="ghost" size="icon" onClick={onClose} className="h-9 w-9 shrink-0 text-muted-foreground hover:text-foreground">
          <X className="h-5 w-5" />
        </Button>
      </header>

      <div className="flex-1 overflow-hidden p-4 space-y-4 bg-muted/10">
        {/* Profile Card */}
        <section className="flex flex-col items-center text-center space-y-3 pt-2">
          <div className="relative">
            <Avatar className="h-24 w-24 border-4 border-white shadow-xl bg-card">
              <AvatarImage src={customer.avatarUrl} alt={customer.name} className="object-cover" />
              <AvatarFallback 
                className={cn(
                  "text-3xl font-black border-2 border-current/10",
                  isBadDebt ? "bg-[#f97316]/15 text-[#f97316]" : 
                  (isPayment ? "bg-[#e74c3c]/15 text-[#e74c3c]" : 
                  (isSettled ? "bg-[#1468F0]/15 text-[#1468F0]" : "bg-[#27ae60]/15 text-[#27ae60]"))
                )}
              >
                {initials}
              </AvatarFallback>
            </Avatar>
            <div 
              className="absolute -bottom-1 -right-1 h-8 w-8 rounded-full border-2 border-white flex items-center justify-center shadow-lg"
              style={{ backgroundColor: statusColor }}
            >
              <ShieldCheck className="h-4 w-4 text-white" />
            </div>
          </div>
          <h2 className="text-xl font-black text-foreground tracking-tight">{customer.name}</h2>
        </section>

        {/* Contact Logic Blocks */}
        <section>
          <div className="grid gap-2">
            <Card className="p-3 border-2 border-primary/5 bg-card space-y-4 shadow-sm">
              <div className="space-y-2">
                <Label className="text-[10px] font-black uppercase tracking-widest text-muted-foreground flex items-center justify-center gap-1.5">
                  <Phone className="h-3 w-3" /> Registered Mobiles
                </Label>
                <div className="space-y-1.5 text-center">
                  {customer.phones.map((phone, idx) => (
                    <div key={idx} className="p-2 bg-muted/20 rounded-lg border border-muted group hover:border-primary/20 transition-all">
                      <span className="text-[13px] font-black text-foreground">{phone}</span>
                    </div>
                  ))}
                  {customer.phones.length === 0 && <p className="text-[11px] font-bold text-slate-400 italic text-center px-2">No phone records found</p>}
                </div>
              </div>

              <div className="space-y-2 pt-2 border-t border-muted">
                <Label className="text-[10px] font-black uppercase tracking-widest text-muted-foreground flex items-center justify-center gap-1.5">
                  <Mail className="h-3 w-3" /> Electronic Mail
                </Label>
                <div className="space-y-1.5 text-center">
                  {customer.emails.map((email, idx) => (
                    <div key={idx} className="p-2 bg-muted/20 rounded-lg border border-muted group hover:border-primary/20 transition-all">
                      <span className="text-[14px] font-black text-foreground truncate max-w-[220px] inline-block">{email}</span>
                    </div>
                  ))}
                  {customer.emails.length === 0 && <p className="text-[11px] font-bold text-slate-400 italic text-center px-2">No email records found</p>}
                </div>
              </div>
            </Card>
          </div>
        </section>

        {/* Quick Audit Block */}
        <section>
          <Card className="p-4 border-2 border-primary/10 bg-primary/5 flex flex-col items-center justify-center text-center shadow-inner rounded-2xl">
            <span className={cn(
              "text-2xl font-black tracking-tighter mb-1",
              customer.isBadDebt ? 'text-[#f97316]' : 
              (customer.balance > 0 ? 'text-[#e74c3c]' : 
              (customer.balance < 0 ? 'text-[#27ae60]' : 'text-[#1468F0]'))
            )}>
              Rs. {formatCurrency(Math.abs(customer.balance))}
            </span>
            <span className="text-[11px] font-black text-muted-foreground uppercase tracking-[0.2em]">
              {customer.isBadDebt ? 'Bad Debt Volume' : (customer.balance > 0 ? 'Current Balance' : (customer.balance < 0 ? 'Advance Credit' : 'Fully Settled'))}
            </span>
          </Card>
        </section>
      </div>

      <div className="h-[70px] p-3 border-t bg-background shrink-0 flex items-center justify-center z-20">
        <Button 
          onClick={onClose}
          className="w-full h-11 bg-primary hover:bg-primary/90 text-white font-black text-xs uppercase tracking-[0.2em] shadow-lg flex items-center justify-center gap-2 transition-all active:scale-[0.98] rounded-xl"
        >
          <ArrowLeft className="h-4 w-4" />
          RETURN TO LIST
        </Button>
      </div>
    </div>
  );
}
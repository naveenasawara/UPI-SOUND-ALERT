
"use client"

import { LedgerEntry, Customer } from "@/app/lib/types";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Trash2, RotateCcw, AlertCircle } from "lucide-react";
import { cn } from "@/lib/utils";
import { format } from "date-fns";

interface RecycleBinDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  deletedEntries: LedgerEntry[];
  customers: Customer[];
  onRestore: (id: string) => void;
  onPermanentlyDelete: (id: string) => void;
}

export function RecycleBinDialog({
  open,
  onOpenChange,
  deletedEntries,
  customers,
  onRestore,
  onPermanentlyDelete,
}: RecycleBinDialogProps) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[700px] max-h-[80vh] flex flex-col">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-destructive">
            <Trash2 className="h-5 w-5" />
            Recycle Bin
          </DialogTitle>
          <DialogDescription>
            View and restore deleted transactions. Permanent deletion cannot be undone.
          </DialogDescription>
        </DialogHeader>

        <div className="flex-1 overflow-y-auto mt-4 border rounded-md">
          <Table>
            <TableHeader className="bg-muted/50 sticky top-0 z-10">
              <TableRow>
                <TableHead className="text-[10px] font-bold uppercase">Date & Customer</TableHead>
                <TableHead className="text-[10px] font-bold uppercase">Details</TableHead>
                <TableHead className="text-right text-[10px] font-bold uppercase">Amount</TableHead>
                <TableHead className="text-right text-[10px) font-bold uppercase">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {deletedEntries.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={4} className="h-32 text-center text-muted-foreground italic">
                    Recycle bin is empty.
                  </TableCell>
                </TableRow>
              ) : (
                deletedEntries.map((entry) => {
                  const customer = customers.find((c) => c.id === entry.customerId);
                  return (
                    <TableRow key={entry.id} className="group">
                      <TableCell>
                        <div className="flex flex-col">
                          <span className="font-bold text-xs">
                            {format(new Date(entry.date), "dd MMM yyyy")}
                          </span>
                          <span className="text-[10px] text-muted-foreground truncate max-w-[150px]">
                            {customer?.name || "Deleted Customer"}
                          </span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <span className="text-xs text-muted-foreground italic">
                          {entry.description || "No description"}
                        </span>
                      </TableCell>
                      <TableCell className="text-right font-bold">
                        <div className={cn(
                          "text-xs",
                          entry.type === 'payment' ? "text-red-600" : "text-green-600"
                        )}>
                          {entry.type === 'payment' ? '-' : '+'} Rs. {entry.amount.toLocaleString()}
                        </div>
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          <Button
                            variant="outline"
                            size="sm"
                            className="h-8 px-2 text-primary border-primary/20 hover:bg-primary/5"
                            onClick={() => onRestore(entry.id)}
                          >
                            <RotateCcw className="h-3.5 w-3.5" />
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            className="h-8 px-2 text-destructive border-destructive/20 hover:bg-destructive/5"
                            onClick={() => onPermanentlyDelete(entry.id)}
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  );
                })
              )}
            </TableBody>
          </Table>
        </div>

        {deletedEntries.length > 0 && (
          <div className="mt-4 p-3 bg-destructive/5 rounded-md flex items-center gap-2 text-[10px] font-medium text-destructive border border-destructive/10">
            <AlertCircle className="h-3.5 w-3.5" />
            Restoring an entry will update the customer's current balance instantly.
          </div>
        )}

        <DialogFooter className="mt-4">
          <Button variant="ghost" onClick={() => onOpenChange(false)}>
            Close Bin
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

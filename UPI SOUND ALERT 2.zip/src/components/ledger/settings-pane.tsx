
"use client"

import { useState, useEffect, useMemo, useRef } from 'react';
import { Button } from "@/components/ui/button";
import { 
  ArrowLeft, FileUp, FileDown, Type, Eye, ArrowRight, ArrowDown, Maximize, RotateCcw, Zap, Activity, MoveUp,
  Palette, Copy, Check
} from "lucide-react";
import { Card } from "@/components/ui/card";
import { Slider } from "@/components/ui/slider";
import { cn, hexToHSL } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";

interface SettingsPaneProps {
  theme: 'light' | 'dark';
  onSetTheme: (theme: 'light' | 'dark') => void;
  themeColor: string;
  onSetThemeColor: (color: string) => void;
  onClose: () => void;
  activeHeaderAnimation: string;
  onSetHeaderAnimation: (anim: string) => void;
}

// Helper to convert HSL to Hex for display
function hslToHex(h: number, s: number, l: number) {
  l /= 100;
  const a = s * Math.min(l, 1 - l) / 100;
  const f = (n: number) => {
    const k = (n + h / 30) % 12;
    const color = l - a * Math.max(Math.min(k - 3, 9 - k, 1), -1);
    return Math.round(255 * color).toString(16).padStart(2, '0');
  };
  return `#${f(0)}${f(8)}${f(4)}`.toUpperCase();
}

export function SettingsPane({
  theme,
  onSetTheme,
  themeColor,
  onSetThemeColor,
  onClose,
  activeHeaderAnimation,
  onSetHeaderAnimation
}: SettingsPaneProps) {
  const { toast } = useToast();
  const [hue, setHue] = useState(210);
  const [saturation, setSaturation] = useState(1);
  const [lightness, setLightness] = useState(45);
  const [bgLightness, setBgLightness] = useState(theme === 'dark' ? 11 : 100);
  const [copied, setCopied] = useState(false);
  
  const isUpdatingInternally = useRef(false);

  // Initialize from current themeColor on mount only
  useEffect(() => {
    if (themeColor) {
      const hsl = hexToHSL(themeColor);
      const parts = hsl.split(' ');
      setHue(parseInt(parts[0]));
      setSaturation(parseInt(parts[1]));
      setLightness(parseInt(parts[2]));
    }
  }, []); // Only on mount

  // Sync with system variables and notify parent
  useEffect(() => {
    const newHex = hslToHex(hue, saturation, lightness);
    const hslString = `${hue} ${saturation}% ${lightness}%`;
    document.documentElement.style.setProperty('--primary', hslString);
    document.documentElement.style.setProperty('--ring', hslString);
    
    // Background handling
    const bgHslString = `222 47% ${bgLightness}%`;
    document.documentElement.style.setProperty('--background', bgHslString);
    document.documentElement.style.setProperty('--card', bgHslString);
    document.documentElement.style.setProperty('--popover', bgHslString);
    
    // Text contrast handling
    const foregroundL = bgLightness > 50 ? '11%' : '98%';
    document.documentElement.style.setProperty('--foreground', `222 47% ${foregroundL}`);
    
    // Update parent only if it's a real change to avoid infinite loop
    if (newHex.toUpperCase() !== themeColor.toUpperCase()) {
      onSetThemeColor(newHex);
    }
  }, [hue, saturation, lightness, bgLightness]);

  const currentHex = useMemo(() => hslToHex(hue, saturation, lightness), [hue, saturation, lightness]);

  const handleCopyHex = () => {
    navigator.clipboard.writeText(currentHex);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
    toast({ title: "Color Code Copied", description: currentHex });
  };

  const headerAnimations = [
    { id: 'fade', name: 'Fade', icon: Eye },
    { id: 'slide-right', name: 'Slide', icon: ArrowRight },
    { id: 'slide-down', name: 'Down', icon: ArrowDown },
    { id: 'zoom', name: 'Zoom', icon: Maximize },
    { id: 'rotate', name: 'Rotate', icon: RotateCcw },
    { id: 'bounce', name: 'Bounce', icon: Zap },
    { id: 'pulse', name: 'Pulse', icon: Activity },
    { id: 'scale-up', name: 'Scale', icon: MoveUp },
  ];

  return (
    <div className="flex flex-col h-full bg-background overflow-hidden box-border">
      <div className="flex-1 p-2 space-y-2 overflow-y-auto custom-scrollbar bg-muted/10">
        
        {/* THEME & COLOUR CONFIGURATOR */}
        <Card className="p-4 border-2 shadow-sm bg-card space-y-5 rounded-2xl border-primary/10">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Palette className="h-5 w-5 text-primary" />
              <h3 className="text-[12px] font-black uppercase tracking-[0.1em] text-foreground">Theme & Colour</h3>
            </div>
            <div 
              onClick={handleCopyHex}
              className="flex items-center gap-2 bg-primary/5 border border-primary/20 rounded-lg px-3 py-1.5 cursor-pointer hover:bg-primary/10 transition-colors"
            >
              <span className="text-[10px] font-black font-mono text-primary"># {currentHex.replace('#', '')}</span>
              {copied ? <Check className="h-3 w-3 text-green-500" /> : <Copy className="h-3 w-3 text-primary opacity-40" />}
            </div>
          </div>

          <div className="bg-muted/10 rounded-xl p-4 border border-muted/20">
            <div className="grid grid-cols-2 gap-x-8 gap-y-6">
              {/* Hue */}
              <div className="space-y-3">
                <label className="text-[9px] font-black uppercase tracking-widest text-muted-foreground ml-1">Colour Selection</label>
                <div className="relative pt-1">
                  <Slider 
                    value={[hue]} 
                    max={360} 
                    step={1} 
                    onValueChange={(v) => setHue(v[0])}
                    className="cursor-pointer"
                    style={{ 
                      '--slider-track-bg': 'linear-gradient(to right, #ff0000, #ffff00, #00ff00, #00ffff, #0000ff, #ff00ff, #ff0000)' 
                    } as any}
                  />
                </div>
              </div>

              {/* Saturation */}
              <div className="space-y-3">
                <label className="text-[9px] font-black uppercase tracking-widest text-muted-foreground ml-1">Saturation Selection</label>
                <div className="relative pt-1">
                  <Slider 
                    value={[saturation]} 
                    max={100} 
                    step={1} 
                    onValueChange={(v) => setSaturation(v[0])}
                    className="cursor-pointer"
                    style={{ 
                      '--slider-track-bg': `linear-gradient(to right, hsl(${hue}, 0%, ${lightness}%), hsl(${hue}, 100%, ${lightness}%))` 
                    } as any}
                  />
                </div>
              </div>

              {/* Light-Dark */}
              <div className="space-y-3">
                <label className="text-[9px] font-black uppercase tracking-widest text-muted-foreground ml-1">Light-Dark Selection</label>
                <div className="relative pt-1">
                  <Slider 
                    value={[lightness]} 
                    max={100} 
                    step={1} 
                    onValueChange={(v) => setLightness(v[0])}
                    className="cursor-pointer"
                    style={{ 
                      '--slider-track-bg': `linear-gradient(to right, #000, hsl(${hue}, ${saturation}%, 50%), #fff)` 
                    } as any}
                  />
                </div>
              </div>

              {/* Background */}
              <div className="space-y-3">
                <label className="text-[9px] font-black uppercase tracking-widest text-muted-foreground ml-1">Background Selection</label>
                <div className="relative pt-1">
                  <Slider 
                    value={[bgLightness]} 
                    max={100} 
                    step={1} 
                    onValueChange={(v) => {
                      setBgLightness(v[0]);
                      // Update theme mode based on lightness threshold
                      if (v[0] < 50 && theme === 'light') onSetTheme('dark');
                      if (v[0] >= 50 && theme === 'dark') onSetTheme('light');
                    }}
                    className="cursor-pointer"
                    style={{ 
                      '--slider-track-bg': 'linear-gradient(to right, #000, #fff)' 
                    } as any}
                  />
                </div>
              </div>
            </div>
          </div>
        </Card>

        <Card className="p-3 border-2 shadow-sm bg-card min-h-[160px] flex flex-col rounded-2xl border-primary/10">
          <div className="flex items-center gap-2 mb-2"><Type className="h-4 w-4 text-primary" /><h3 className="text-[11px] font-black uppercase text-muted-foreground tracking-widest">Header Dynamics</h3></div>
          <div className="grid grid-cols-4 gap-1.5">
            {headerAnimations.map((a) => (
              <button key={a.id} onClick={() => onSetHeaderAnimation(a.id)} className={cn("flex flex-col items-center justify-center p-2 rounded-xl border-2 transition-all gap-1 relative", activeHeaderAnimation === a.id ? "bg-primary text-white border-primary" : "bg-background text-muted-foreground border-muted hover:border-primary/30")}>
                <a.icon className="h-3.5 w-3.5" /><span className="text-[8px] font-black uppercase truncate w-full text-center">{a.name}</span>
              </button>
            ))}
          </div>
        </Card>
        
        <Card className="p-3 border-2 shadow-sm bg-card flex flex-col gap-3 rounded-2xl border-primary/10">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-black uppercase text-muted-foreground">System Theme Override</span>
            <div className="flex gap-1.5">
              <Button size="sm" onClick={() => onSetTheme('light')} variant={theme === 'light' ? 'default' : 'outline'} className="h-7 text-[10px] font-black">LIGHT</Button>
              <Button size="sm" onClick={() => onSetTheme('dark')} variant={theme === 'dark' ? 'default' : 'outline'} className="h-7 text-[10px] font-black">DARK</Button>
            </div>
          </div>
        </Card>

        <Card className="p-3 border-2 shadow-sm bg-card space-y-3 rounded-2xl border-primary/10">
           <h3 className="text-[11px] font-black uppercase text-muted-foreground">Data Management Tools</h3>
           <div className="grid grid-cols-2 gap-2">
             <Button variant="outline" className="h-10 text-[9px] font-black uppercase border-2"><FileUp className="h-3 w-3 mr-1" /> Import Excel</Button>
             <Button variant="outline" className="h-10 text-[9px] font-black uppercase border-2"><FileDown className="h-3 w-3 mr-1" /> Export Excel</Button>
           </div>
        </Card>
      </div>
      <div className="h-[70px] p-3 border-t bg-background shrink-0 flex items-center justify-center">
        <Button onClick={onClose} className="w-full h-11 bg-primary text-white font-black text-xs uppercase tracking-widest rounded-xl shadow-lg transition-all active:scale-[0.98]"><ArrowLeft className="h-4 w-4 mr-2" /> RETURN TO LEDGER</Button>
      </div>
    </div>
  );
}

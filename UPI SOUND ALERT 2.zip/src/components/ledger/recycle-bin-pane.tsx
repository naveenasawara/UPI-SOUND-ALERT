"use client"

import { LedgerEntry, Customer } from "@/app/lib/types";
import { Button } from "@/components/ui/button";
import { ReceiptText, Users, ArrowLeft } from "lucide-react";
import { Card } from "@/components/ui/card";

interface RecycleBinPaneProps {
  deletedEntries: LedgerEntry[];
  deletedCustomers: Customer[];
  deletedMemos: any[]; // Kept for prop compatibility but unused
  onClose: () => void;
}

export function RecycleBinPane({
  deletedEntries,
  deletedCustomers,
  onClose,
}: RecycleBinPaneProps) {
  return (
    <div className="flex flex-col h-full bg-background overflow-hidden">
      <div className="flex-1 p-4 overflow-y-auto space-y-4">
        <div className="px-1">
          <h3 className="text-[11px] font-black uppercase text-muted-foreground tracking-widest mb-4">Bin Overview</h3>
          
          <div className="grid gap-3">
            <Card className="p-4 border-2 border-muted bg-card flex items-center justify-between shadow-sm">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-xl bg-orange-500/10 text-orange-600 flex items-center justify-center">
                  <ReceiptText className="h-5 w-5" />
                </div>
                <div className="flex flex-col">
                  <span className="text-[13px] font-black text-foreground uppercase tracking-tight">Entries</span>
                  <span className="text-[10px] font-bold text-muted-foreground uppercase">Transactions</span>
                </div>
              </div>
              <span className="text-lg font-black text-orange-600">{deletedEntries.length}</span>
            </Card>

            <Card className="p-4 border-2 border-muted bg-card flex items-center justify-between shadow-sm">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-xl bg-blue-500/10 text-blue-600 flex items-center justify-center">
                  <Users className="h-5 w-5" />
                </div>
                <div className="flex flex-col">
                  <span className="text-[13px] font-black text-foreground uppercase tracking-tight">Names</span>
                  <span className="text-[10px] font-bold text-muted-foreground uppercase">Customers</span>
                </div>
              </div>
              <span className="text-lg font-black text-blue-600">{deletedCustomers.length}</span>
            </Card>
          </div>
        </div>

        <div className="p-4 bg-muted/30 rounded-xl border-2 border-dashed border-muted mt-6">
          <p className="text-[10px] font-bold text-muted-foreground uppercase leading-relaxed text-center">
            You can restore or permanently delete these records from the history list on the right.
          </p>
        </div>
      </div>

      <div className="h-[70px] p-3 border-t bg-background shrink-0 flex items-center justify-center">
        <Button 
          onClick={onClose}
          className="w-full h-11 bg-primary hover:bg-primary/90 text-white font-black text-xs uppercase tracking-[0.2em] shadow-lg flex items-center justify-center gap-2 transition-all active:scale-[0.98] rounded-xl"
        >
          <ArrowLeft className="h-4 w-4" />
          RETURN TO LEDGER
        </Button>
      </div>
    </div>
  );
}

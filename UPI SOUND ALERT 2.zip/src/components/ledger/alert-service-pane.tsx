
"use client"

import { useState, useEffect, useCallback, useRef } from 'react';
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { 
  Volume2, 
  Zap, 
  Terminal, 
  Speaker, 
  Activity, 
  Wifi,
  BatteryCharging,
  Power,
  Settings2,
  Infinity as InfinityIcon,
  Languages,
  Bug
} from "lucide-react";
import { Card } from "@/components/ui/card";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

// HELPER: Convert number to Hindi phonetic words
function numberToHindiWords(num: number): string {
  const ones = ['', 'ek', 'do', 'teen', 'chaar', 'paanch', 'chhe', 'saat', 'aath', 'nau', 'dus', 'gyarah', 'baarah', 'terah', 'chaudah', 'pandrah', 'solah', 'satrah', 'atharah', 'unnees'];
  const tens = ['', '', 'bees', 'tees', 'chaalees', 'pachaas', 'saath', 'sattar', 'assee', 'nabbe'];
  
  const amount = Math.floor(num);
  if (amount === 0) return 'shunya';
  
  function convert(n: number): string {
    if (n < 20) return ones[n];
    if (n < 100) return tens[Math.floor(n / 10)] + (n % 10 !== 0 ? ' ' + ones[n % 10] : '');
    if (n < 1000) return ones[Math.floor(n / 100)] + ' sau ' + (n % 100 !== 0 ? convert(n % 100) : '');
    if (n < 100000) return convert(Math.floor(n / 1000)) + ' hazaar ' + (n % 1000 !== 0 ? convert(n % 1000) : '');
    if (n < 10000000) return convert(Math.floor(n / 100000)) + ' lakh ' + (n % 100000 !== 0 ? convert(n % 100000) : '');
    return convert(Math.floor(n / 10000000)) + ' crore ' + (n % 10000000 !== 0 ? convert(n % 10000000) : '');
  }
  
  return convert(amount).trim();
}

export function AlertServicePane({ onNewAlert }: { onNewAlert: (log: any) => void }) {
  const { toast } = useToast();
  const [isActive, setIsActive] = useState(true); // Always ON by default
  const [signalStrength, setSignalStrength] = useState(0);
  const [isPowerOptimized, setIsPowerOptimized] = useState(true);
  const [language, setLanguage] = useState<'hindi' | 'english'>('hindi');
  const [debugText, setDebugText] = useState('');
  const [hasWakeLock, setHasWakeLock] = useState(false);
  const [availableVoices, setAvailableVoices] = useState<SpeechSynthesisVoice[]>([]);
  
  const wakeLockRef = useRef<any>(null);

  // Voice Initialization
  useEffect(() => {
    const synth = window.speechSynthesis;
    const updateVoices = () => {
      setAvailableVoices(synth.getVoices());
    };
    updateVoices();
    if (synth.onvoiceschanged !== undefined) {
      synth.onvoiceschanged = updateVoices;
    }
  }, []);

  // Wake Lock Management
  const requestWakeLock = async () => {
    if ('wakeLock' in navigator) {
      try {
        wakeLockRef.current = await (navigator as any).wakeLock.request('screen');
        setHasWakeLock(true);
      } catch (err: any) {
        setHasWakeLock(false);
      }
    }
  };

  const releaseWakeLock = async () => {
    if (wakeLockRef.current) {
      await wakeLockRef.current.release();
      wakeLockRef.current = null;
      setHasWakeLock(false);
    }
  };

  useEffect(() => {
    if (isActive) requestWakeLock();
    else releaseWakeLock();
    
    const handleVisibilityChange = () => {
      if (isActive && wakeLockRef.current !== null && document.visibilityState === 'visible') {
        requestWakeLock();
      }
    };

    document.addEventListener('visibilitychange', handleVisibilityChange);
    return () => {
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      releaseWakeLock();
    };
  }, [isActive]);

  useEffect(() => {
    let interval: any;
    if (isActive) {
      interval = setInterval(() => {
        setSignalStrength(Math.floor(Math.random() * 30) + 70);
      }, 2000);
    } else {
      setSignalStrength(0);
    }
    return () => clearInterval(interval);
  }, [isActive]);

  const speakAmount = useCallback((amount: number) => {
    if (!isActive || amount <= 0) return;
    const synth = window.speechSynthesis;
    synth.cancel();

    let text = '';
    if (language === 'hindi') {
      const hindiAmountWords = numberToHindiWords(amount);
      text = `${hindiAmountWords} rupaye prapt hue`;
    } else {
      text = `Received ${amount} rupees`;
    }

    const utterance = new SpeechSynthesisUtterance(text);
    const voices = availableVoices.length > 0 ? availableVoices : synth.getVoices();
    
    // STRICT FEMALE INDIAN VOICE SELECTION
    const femaleKeywords = ['heera', 'kalpana', 'sangeeta', 'sharda', 'veena', 'rani', 'neerja', 'priya', 'vani', 'google हिन्दी', 'female', 'zira', 'karen'];
    const indianKeywords = ['india', 'indian', 'in'];
    const langPrefix = language === 'hindi' ? 'hi' : 'en';
    
    const langVoices = voices.filter(v => v.lang.toLowerCase().startsWith(langPrefix));

    // Priority 1: Indian Female
    let targetVoice = langVoices.find(v => 
      (v.lang.toLowerCase().includes('in') || indianKeywords.some(k => v.name.toLowerCase().includes(k))) &&
      femaleKeywords.some(k => v.name.toLowerCase().includes(k))
    );

    // Priority 2: Any Female for language
    if (!targetVoice) {
      targetVoice = langVoices.find(v => femaleKeywords.some(k => v.name.toLowerCase().includes(k)));
    }

    // Priority 3: Any Indian Locale
    if (!targetVoice) {
      targetVoice = langVoices.find(v => 
        v.lang.toLowerCase().includes('in') || indianKeywords.some(k => v.name.toLowerCase().includes(k))
      );
    }

    if (targetVoice) {
      utterance.voice = targetVoice;
      utterance.lang = targetVoice.lang;
    } else {
      utterance.lang = language === 'hindi' ? 'hi-IN' : 'en-IN';
    }
    
    utterance.rate = language === 'hindi' ? 0.85 : 0.90;
    utterance.pitch = 1.0;
    utterance.volume = 1.0;

    synth.speak(utterance);
  }, [isActive, language, availableVoices]);

  const extractAmountFromSignal = (text: string) => {
    const regexes = [
      /(?:Rs\.?|₹|INR)\s?([\d,]+(?:\.\d{1,2})?)/i,
      /([\d,]+(?:\.\d{1,2})?)\s?(?:rupees|rupaiya|INR|Rs\.?|₹)/i,
      /(?:credited|received|paid you)\s?(?:of\s?)?(?:Rs\.?|₹|INR)?\s?([\d,]+(?:\.\d{1,2})?)/i
    ];

    for (const re of regexes) {
      const match = text.match(re);
      if (match) {
        const cleaned = match[1].replace(/,/g, '');
        const val = parseFloat(cleaned);
        if (!isNaN(val)) return val;
      }
    }
    return 0;
  };

  const handleCaptureSignal = (payload: { app: string, pkg: string, msg: string, color?: string, title?: string }) => {
    const extractedAmount = extractAmountFromSignal(payload.msg);
    
    const log = {
      id: crypto.randomUUID(),
      amount: extractedAmount,
      app: payload.app,
      package: payload.pkg,
      rawMessage: payload.msg,
      title: payload.title || payload.app,
      color: payload.color || '#727374',
      timestamp: Date.now(),
      isDebug: !['GPay', 'PhonePe', 'Paytm', 'BHIM', 'Bank SMS'].includes(payload.app)
    };

    onNewAlert(log);
    
    if (isActive && extractedAmount > 0) {
      speakAmount(extractedAmount);
    }
  };

  const injectDebugSignal = () => {
    if (!debugText.trim()) return;
    handleCaptureSignal({
      app: "Raw Signal",
      pkg: "com.upisoundalert.debug",
      msg: debugText,
      title: "Incoming Debug Text",
      color: "#f59e0b"
    });
    setDebugText('');
  };

  const simulateIncomingPayment = () => {
    const rawSignals = [
      { app: "GPay", pkg: "com.google.android.apps.nbu.paisa.user", color: "#4285F4", msg: "You received ₹450 from John Smith" },
      { app: "PhonePe", pkg: "com.phonepe.app", color: "#5f259f", msg: "Rs. 1200 credited to your account" },
      { app: "Paytm", pkg: "net.one97.paytm", color: "#00baf2", msg: "Paid you ₹75 for morning tea" },
      { app: "Bank SMS", pkg: "com.android.mms", color: "#607d8b", msg: "Your a/c XXXXX123 is credited with INR 5,000.00" },
      { app: "BHIM", pkg: "in.org.npci.upiapp", color: "#e91e63", msg: "Payment of Rs 250.00 received" }
    ];
    
    const selected = rawSignals[Math.floor(Math.random() * rawSignals.length)];
    handleCaptureSignal(selected);
  };

  return (
    <div className="flex flex-col h-full bg-background overflow-hidden animate-in fade-in slide-in-from-left-2 duration-300">
      <div className="flex-1 p-4 space-y-4 overflow-y-auto custom-scrollbar bg-muted/10 pb-8">
        
        <section className="text-center py-4 bg-background border-2 border-primary/5 rounded-2xl shadow-inner">
          <div className="h-14 w-14 bg-primary/10 text-primary rounded-2xl flex items-center justify-center mx-auto mb-3 shadow-sm relative">
             <Volume2 className="h-7 w-7" />
             {isActive && (
               <span className="absolute -top-1 -right-1 flex h-4 w-4">
                 <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#27ae60] opacity-75"></span>
                 <span className="relative inline-flex rounded-full h-4 w-4 bg-[#27ae60]"></span>
               </span>
             )}
          </div>
          <h2 className="text-md font-black uppercase tracking-tight">Monitoring Station</h2>
          <div className="flex items-center justify-center gap-2 mt-2">
            <div className={cn("h-1.5 w-1.5 rounded-full", isActive ? "bg-[#27ae60]" : "bg-muted")} />
            <span className="text-[9px] font-black uppercase text-muted-foreground tracking-widest">
              {isActive ? 'Live Listener Active' : 'Station Offline'}
            </span>
          </div>
        </section>

        <section className="space-y-3">
          <div className="px-1 flex items-center gap-2">
            <BatteryCharging className="h-3 w-3 text-primary/40" />
            <h3 className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">System Stability</h3>
          </div>
          <Card className="p-3 border-2 border-primary/10 bg-card space-y-3 shadow-md rounded-xl relative overflow-hidden">
              <div className="flex items-center justify-between">
                <div className="flex flex-col">
                  <span className="text-[11px] font-black uppercase tracking-tight">Foreground Service</span>
                  <span className={cn("text-[8px] font-bold uppercase", isPowerOptimized ? "text-amber-500" : "text-[#27ae60]")}>
                    {isPowerOptimized ? 'Android may kill background' : 'Unrestricted Persistence'}
                  </span>
                </div>
                {isPowerOptimized ? (
                  <Button onClick={() => {
                    toast({ 
                      title: "How to stay active:", 
                      description: "Go to Settings > Apps > Chrome > Battery > Select 'Unrestricted'.",
                      duration: 6000
                    });
                    setIsPowerOptimized(false);
                  }} className="h-8 bg-amber-500 hover:bg-amber-600 text-white font-black text-[9px] uppercase tracking-widest rounded-lg">Fix Now</Button>
                ) : (
                  <div className="flex items-center gap-1.5 text-[#27ae60] bg-[#27ae60]/10 px-2 py-1 rounded-lg border border-[#27ae60]/20">
                    <InfinityIcon className="h-3 w-3" />
                    <span className="text-[9px] font-black uppercase">Persistent</span>
                  </div>
                )}
              </div>
              <div className="flex items-center gap-3 pt-2 border-t border-muted">
                <div className="flex items-center gap-1">
                  <Power className={cn("h-3 w-3", hasWakeLock ? "text-[#27ae60]" : "text-primary")} />
                  <span className="text-[9px] font-bold text-muted-foreground uppercase">
                    Wake Lock: {hasWakeLock ? 'ON' : 'OFF'}
                  </span>
                </div>
              </div>
          </Card>
        </section>

        <section className="space-y-3">
          <div className="px-1 flex items-center gap-2">
            <Bug className="h-3 w-3 text-amber-500" />
            <h3 className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">Raw Signal Debugger</h3>
          </div>
          <Card className="p-4 border-2 border-amber-500/10 bg-card space-y-3 shadow-md rounded-2xl">
             <div className="space-y-1.5">
               <Label className="text-[9px] font-black uppercase text-muted-foreground ml-1">Paste Raw Notification Text</Label>
               <Input 
                 placeholder="e.g. ₹500 received or credited with Rs 1000"
                 value={debugText}
                 onChange={(e) => setDebugText(e.target.value)}
                 className="h-10 font-bold border-amber-500/20 bg-amber-500/5 text-[12px] focus-visible:ring-amber-500"
                 onKeyDown={(e) => e.key === 'Enter' && injectDebugSignal()}
               />
             </div>
             <Button 
               onClick={injectDebugSignal}
               disabled={!debugText.trim()}
               className="w-full h-9 bg-amber-500 hover:bg-amber-600 text-white font-black text-[10px] uppercase tracking-widest rounded-xl shadow-lg transition-all active:scale-95"
             >
               Capture Raw Signal
             </Button>
          </Card>
        </section>

        <section className="space-y-3">
          <div className="px-1 flex items-center gap-2">
            <Languages className="h-3 w-3 text-primary/40" />
            <h3 className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">Audio Personality</h3>
          </div>
          <Card className="p-4 border-2 border-primary/10 bg-card space-y-4 shadow-md rounded-2xl">
              <Tabs value={language} onValueChange={(v: any) => setLanguage(v)} className="w-full">
                <TabsList className="grid grid-cols-2 h-10 bg-muted/50 p-1">
                  <TabsTrigger value="hindi" className="text-[10px] font-black uppercase tracking-tighter">Hindi (Indian)</TabsTrigger>
                  <TabsTrigger value="english" className="text-[10px] font-black uppercase tracking-tighter">English (Indian)</TabsTrigger>
                </TabsList>
              </Tabs>
              <div className="pt-1 flex items-center gap-2 px-1">
                <div className="h-2 w-2 rounded-full bg-[#27ae60]" />
                <span className="text-[9px] font-black text-[#27ae60] uppercase tracking-widest">Voice: Indian Female Assist</span>
              </div>
          </Card>
        </section>

        <section className="space-y-3">
          <div className="px-1 flex items-center gap-2">
            <Activity className="h-3 w-3 text-primary/40" />
            <h3 className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">Engine Control</h3>
          </div>
          <Card className="p-4 border-2 border-primary/10 bg-card space-y-4 shadow-md rounded-2xl">
             <div className="flex items-center justify-between">
               <div className="flex items-center gap-3">
                 <div className={cn("h-10 w-10 rounded-xl flex items-center justify-center transition-all", isActive ? "bg-[#27ae60]/10 text-[#27ae60] shadow-inner" : "bg-muted text-muted-foreground")}>
                   <Zap className="h-5 w-5" />
                 </div>
                 <div className="flex flex-col">
                   <span className="text-[12px] font-black uppercase tracking-tight">Audio Listener</span>
                   <span className="text-[9px] font-bold text-muted-foreground uppercase">{isActive ? 'Monitoring Signals' : 'Station Offline'}</span>
                 </div>
               </div>
               <Switch checked={isActive} onCheckedChange={setIsActive} className="data-[state=checked]:bg-[#27ae60]" />
             </div>
             {isActive && (
               <div className="space-y-2 pt-2 border-t">
                 <div className="flex justify-between items-center text-[9px] font-black uppercase text-muted-foreground">
                   <div className="flex items-center gap-1"><Wifi className="h-3 w-3" /><span>Signal Strength</span></div>
                   <span>{signalStrength}%</span>
                 </div>
                 <Progress value={signalStrength} className="h-1 bg-muted" />
               </div>
             )}
          </Card>
          
          <div className="grid grid-cols-2 gap-3">
            <Button 
              onClick={() => speakAmount(100)} 
              className="h-12 bg-green-600 hover:bg-green-700 text-white font-black text-[10px] uppercase tracking-widest shadow-lg rounded-xl transition-all active:scale-95"
            >
              <Speaker className="h-4 w-4 mr-2" />
              Test Voice (100)
            </Button>
            
            <Button 
              onClick={simulateIncomingPayment} 
              className="h-12 bg-primary/5 hover:bg-primary/10 text-primary border-2 border-primary/10 font-black text-[10px] uppercase tracking-widest shadow-sm rounded-xl transition-all active:scale-95"
            >
              <Terminal className="h-4 w-4 mr-2" />
              Mock UPI Alert
            </Button>
          </div>
        </section>

      </div>
    </div>
  );
}

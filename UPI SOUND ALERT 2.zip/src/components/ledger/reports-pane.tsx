
"use client"

import { useState, useMemo } from 'react';
import { Button } from "@/components/ui/button";
import { 
  FileDown, 
  X, 
  Eye, 
  Loader2,
  FileText,
  Users,
  ReceiptText,
  TrendingUp,
  TrendingDown,
  IndianRupee
} from "lucide-react";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { 
  format, 
  parseISO, 
  startOfMonth, 
  startOfDay,
  endOfDay
} from 'date-fns';
import { cn, formatCurrency } from "@/lib/utils";
import { LedgerEntry, Customer } from "@/app/lib/types";

type ReportType = 'custom' | 'day' | 'week' | 'month' | 'calendar-month' | 'year';

interface ReportsPaneProps {
  entries: LedgerEntry[];
  customers: Customer[];
  onGenerate: (type: ReportType, startDate: string, endDate?: string, action?: 'save' | 'view') => void;
  onClose: () => void;
}

export function ReportsPane({ entries, customers, onGenerate, onClose }: ReportsPaneProps) {
  const [refDate, setRefDate] = useState(format(startOfMonth(new Date()), 'yyyy-MM-dd'));
  const [endDate, setEndDate] = useState(format(new Date(), 'yyyy-MM-dd'));
  const [isGenerating, setIsGenerating] = useState(false);

  const handleGenerateClick = (action: 'save' | 'view') => {
    setIsGenerating(true);
    setTimeout(() => {
      onGenerate('custom', refDate, endDate, action);
      setIsGenerating(false);
    }, 1000);
  };

  const businessSummary = useMemo(() => {
    const start = startOfDay(parseISO(refDate));
    const end = endOfDay(parseISO(endDate));

    if (isNaN(start.getTime()) || isNaN(end.getTime())) return null;

    const filteredEntries = entries.filter(e => {
      const d = parseISO(e.date);
      return d >= start && d <= end;
    });

    const uniqueCustomerIds = new Set(filteredEntries.map(e => e.customerId));
    const totalPayment = filteredEntries.filter(e => e.type === 'payment').reduce((s, e) => s + e.amount, 0);
    const totalReceived = filteredEntries.filter(e => e.type === 'received').reduce((s, e) => s + e.amount, 0);
    const netBalance = totalPayment - totalReceived;

    return {
      customerCount: uniqueCustomerIds.size,
      entryCount: filteredEntries.length,
      totalPayment,
      totalReceived,
      netBalance
    };
  }, [entries, refDate, endDate]);

  return (
    <div className="flex flex-col h-full bg-white dark:bg-card overflow-hidden">
      <div className="flex items-center justify-between px-4 h-[60px] border-b shrink-0 bg-primary/5">
        <div className="flex items-center gap-2 text-primary font-black uppercase tracking-tighter text-[14px]">
          <FileDown className="h-5 w-5" />
          BUSINESS REPORTS
        </div>
        <Button variant="ghost" size="icon" onClick={onClose} className="h-8 w-8">
          <X className="h-4 w-4" />
        </Button>
      </div>

      <div className="flex-1 overflow-y-auto">
        <div className="p-3 bg-slate-50/50 border-b">
          <Card className="p-3 bg-white border-2 border-primary/5 space-y-3 shadow-sm">
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <label className="text-[9px] font-black uppercase tracking-[0.1em] text-slate-400 px-1">
                  From Date
                </label>
                <Input 
                  type="date"
                  value={refDate}
                  onChange={(e) => setRefDate(e.target.value)}
                  className="h-9 font-bold border-slate-100 focus-visible:ring-primary shadow-inner bg-slate-50/50 text-xs"
                />
              </div>
              <div className="space-y-1">
                <label className="text-[9px] font-black uppercase tracking-[0.1em] text-slate-400 px-1">To Date</label>
                <Input 
                  type="date"
                  value={endDate}
                  onChange={(e) => setEndDate(e.target.value)}
                  className="h-9 font-bold border-slate-100 focus-visible:ring-primary shadow-inner bg-slate-50/50 text-xs"
                />
              </div>
            </div>
          </Card>
        </div>

        <div className="p-3 space-y-3">
          {businessSummary && (
            <Card className="border-2 border-primary/10 shadow-sm overflow-hidden bg-white animate-in zoom-in-95 duration-300">
              <div className="bg-primary/5 px-4 py-2 border-b border-primary/10">
                <div className="flex items-center gap-2 text-primary font-black text-[10px] uppercase tracking-[0.2em]">
                  <ReceiptText className="h-3 w-3" /> Business Summary
                </div>
              </div>
              <div className="p-3 space-y-2">
                <div className="flex items-center justify-between py-1">
                  <div className="flex items-center gap-2">
                    <Users className="h-3.5 w-3.5 text-slate-400" />
                    <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Total Customers</span>
                  </div>
                  <span className="text-[12px] font-black text-slate-700">{businessSummary.customerCount} Active</span>
                </div>
                
                <div className="flex items-center justify-between py-1 border-t border-slate-50">
                  <div className="flex items-center gap-2">
                    <FileText className="h-3.5 w-3.5 text-slate-400" />
                    <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Total Entries</span>
                  </div>
                  <span className="text-[12px] font-black text-slate-700">{businessSummary.entryCount} Records</span>
                </div>

                <div className="flex items-center justify-between py-1 border-t border-slate-50">
                  <div className="flex items-center gap-2">
                    <TrendingUp className="h-3.5 w-3.5 text-[#e74c3c]" />
                    <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Total Payment</span>
                  </div>
                  <span className="text-[12px] font-black text-[#e74c3c]">Rs. {formatCurrency(businessSummary.totalPayment)}</span>
                </div>

                <div className="flex items-center justify-between py-1 border-t border-slate-50">
                  <div className="flex items-center gap-2">
                    <TrendingDown className="h-3.5 w-3.5 text-[#27ae60]" />
                    <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Total Received</span>
                  </div>
                  <span className="text-[12px] font-black text-[#27ae60]">Rs. {formatCurrency(businessSummary.totalReceived)}</span>
                </div>

                <div className="pt-2 mt-1 border-t-2 border-primary/5 flex items-center justify-between">
                  <span className="text-[11px] font-black text-primary uppercase tracking-widest">Net Balance</span>
                  <div className="flex items-center gap-1">
                    <IndianRupee className="h-3 w-3 text-primary" />
                    <span className={cn(
                      "text-base font-black tracking-tighter",
                      businessSummary.netBalance > 0 ? "text-[#e74c3c]" : "text-primary"
                    )}>
                      {formatCurrency(Math.abs(businessSummary.netBalance))}
                    </span>
                  </div>
                </div>
              </div>
            </Card>
          )}
        </div>
      </div>

      <div className="h-[70px] p-3 border-t bg-white shrink-0 flex items-center">
        <div className="grid grid-cols-2 gap-2 w-full">
          <Button 
            variant="outline"
            disabled={isGenerating}
            onClick={() => handleGenerateClick('view')} 
            className="h-11 border-2 border-slate-200 text-slate-600 hover:bg-white font-black text-[11px] shadow-sm uppercase tracking-widest rounded-lg transition-all"
          >
            <Eye className="h-4 w-4 mr-2" />
            PREVIEW
          </Button>
          <Button 
            disabled={isGenerating}
            onClick={() => handleGenerateClick('save')} 
            className={cn(
              "h-11 bg-primary hover:bg-primary/90 text-primary-foreground font-black text-[11px] shadow-lg uppercase tracking-widest rounded-lg transition-all active:scale-[0.98]",
              isGenerating && "opacity-80"
            )}
          >
            {isGenerating ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <><FileDown className="h-4 w-4 mr-2" /> GENERATE</>
            )}
          </Button>
        </div>
      </div>
    </div>
  );
}


'use client';

import { useState, useEffect } from 'react';
import { Company } from '@/app/lib/types';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card } from '@/components/ui/card';
import { Landmark, QrCode, Save, Info, Wallet, MapPin } from 'lucide-react';

interface BankDetailsPaneProps {
  currentCompany: Company | null;
  onUpdate: (data: Partial<Company>) => void;
}

export function BankDetailsPane({ currentCompany, onUpdate }: BankDetailsPaneProps) {
  const [formData, setFormData] = useState({
    bankName: '',
    accountNumber: '',
    ifscCode: '',
    branchAddress: '',
    upiId: ''
  });

  useEffect(() => {
    if (currentCompany) {
      setFormData({
        bankName: currentCompany.bankName || '',
        accountNumber: currentCompany.accountNumber || '',
        ifscCode: currentCompany.ifscCode || '',
        branchAddress: currentCompany.branchAddress || '',
        upiId: currentCompany.upiId || ''
      });
    }
  }, [currentCompany]);

  const handleSave = () => {
    onUpdate(formData);
  };

  const qrUrl = formData.upiId 
    ? `https://api.qrserver.com/v1/create-qr-code/?size=240x240&data=${encodeURIComponent(`upi://pay?pa=${formData.upiId}&pn=${currentCompany?.name || 'Business'}&cu=INR`)}`
    : null;

  return (
    <div className="h-full flex flex-col bg-background animate-in fade-in slide-in-from-right-2 duration-500 overflow-hidden">
      <div className="flex-1 overflow-y-auto custom-scrollbar p-4 bg-muted/10">
        <div className="max-w-5xl mx-auto h-full flex flex-col justify-center space-y-4">
          
          {/* Top Identity Grid - SYMMETRICAL HEIGHT LOCK */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {/* Bank Form Card */}
            <Card className="p-4 border-2 border-primary/5 shadow-sm space-y-3.5 bg-card rounded-2xl">
              <div className="flex items-center gap-2 mb-1">
                <Landmark className="h-5 w-5 text-primary" />
                <div className="h-1 w-1 rounded-full bg-primary" />
                <span className="text-[10px] font-black uppercase tracking-widest text-muted-foreground ml-1">Bank Identity</span>
              </div>

              <div className="grid gap-3">
                <div className="space-y-1">
                  <Label className="text-[9px] font-black uppercase tracking-widest text-muted-foreground ml-1">Bank Name</Label>
                  <Input 
                    value={formData.bankName} 
                    onChange={(e) => setFormData({...formData, bankName: e.target.value})}
                    className="h-9 font-bold border-muted bg-muted/5 focus-visible:ring-primary rounded-xl text-[12px]"
                    placeholder="e.g. State Bank of India"
                  />
                </div>
                <div className="space-y-1">
                  <Label className="text-[9px] font-black uppercase tracking-widest text-muted-foreground ml-1">Account Number</Label>
                  <Input 
                    value={formData.accountNumber} 
                    onChange={(e) => setFormData({...formData, accountNumber: e.target.value})}
                    className="h-9 font-bold border-muted bg-muted/5 focus-visible:ring-primary rounded-xl text-[12px]"
                    placeholder="0000 0000 0000"
                  />
                </div>
                <div className="space-y-1">
                  <Label className="text-[9px] font-black uppercase tracking-widest text-muted-foreground ml-1">IFSC Code</Label>
                  <Input 
                    value={formData.ifscCode} 
                    onChange={(e) => setFormData({...formData, ifscCode: e.target.value.toUpperCase()})}
                    className="h-9 font-black uppercase border-muted bg-muted/5 focus-visible:ring-primary rounded-xl text-[11px]"
                    placeholder="SBIN000XXXX"
                  />
                </div>
                <div className="space-y-1">
                  <Label className="text-[9px] font-black uppercase tracking-widest text-muted-foreground ml-1">UPI ID</Label>
                  <Input 
                    value={formData.upiId} 
                    onChange={(e) => setFormData({...formData, upiId: e.target.value})}
                    className="h-9 font-bold border-muted bg-muted/5 focus-visible:ring-primary rounded-xl text-[11px]"
                    placeholder="name@upi"
                  />
                </div>
              </div>
            </Card>

            {/* QR Preview Card - MATCHED HEIGHT TO FORM */}
            <Card className="p-5 border-2 border-primary/10 shadow-xl bg-card flex flex-col items-center justify-center text-center relative overflow-hidden rounded-2xl group min-h-[318px] h-full">
              <div className="absolute top-0 left-0 w-full h-1 bg-primary" />
              
              <div className="mb-4">
                <div className="h-10 w-10 bg-primary/10 text-primary rounded-xl flex items-center justify-center mx-auto mb-1.5 shadow-sm">
                  <QrCode className="h-5 w-5" />
                </div>
                <h4 className="text-[9px] font-black uppercase tracking-[0.2em] text-muted-foreground">Digital Settlement</h4>
              </div>

              {qrUrl ? (
                <div className="p-3 bg-white rounded-xl border-2 border-primary/5 shadow-2xl transition-transform group-hover:scale-[1.02] duration-500">
                  <img 
                    src={qrUrl} 
                    alt="Payment QR" 
                    className="w-32 h-32 object-contain"
                  />
                </div>
              ) : (
                <div className="w-32 h-32 rounded-xl bg-muted/30 border-2 border-dashed border-muted flex flex-col items-center justify-center p-4 opacity-30">
                  <Info className="h-5 w-5 mb-1" />
                  <p className="text-[8px] font-bold uppercase tracking-widest">No UPI ID</p>
                </div>
              )}

              <div className="mt-5 w-full max-w-[240px]">
                <div className="flex items-center justify-center gap-2 p-2 bg-primary/5 rounded-xl border border-primary/10">
                  <Wallet className="h-3 w-3 text-primary" />
                  <span className="text-[11px] font-black text-primary tracking-tight truncate">{formData.upiId || 'NOT CONFIGURED'}</span>
                </div>
              </div>
            </Card>
          </div>

          {/* Full-Width Branch Module */}
          <Card className="p-4 border-2 border-primary/5 bg-card shadow-sm rounded-2xl">
            <div className="flex items-center gap-2 mb-2">
              <MapPin className="h-4 w-4 text-primary" />
              <Label className="text-[9px] font-black uppercase tracking-widest text-muted-foreground">Branch Location Details</Label>
            </div>
            <Textarea 
              value={formData.branchAddress} 
              onChange={(e) => setFormData({...formData, branchAddress: e.target.value})}
              className="min-h-[60px] font-bold border-muted bg-muted/5 focus-visible:ring-primary resize-none rounded-xl text-[12px] py-2"
              placeholder="Full bank branch address and location info..."
            />
          </Card>

        </div>
      </div>

      <div className="h-[70px] bg-background border-t flex items-center justify-center px-4 shrink-0 z-50">
        <Button 
          onClick={handleSave}
          className="w-full max-w-md h-12 bg-primary hover:bg-primary/90 text-white font-black text-xs uppercase tracking-widest shadow-lg rounded-xl transition-all active:scale-[0.98]"
        >
          <Save className="h-4 w-4 mr-2" /> UPDATE BANKING INFO
        </Button>
      </div>
    </div>
  );
}


"use client"

import { useState } from 'react';
import { Button } from "@/components/ui/button";
import { 
  History, 
  Trash2, 
  Database, 
  Download, 
  FileUp, 
  Wrench, 
  RefreshCw,
  CloudUpload,
  ShieldAlert,
  CheckCircle2,
  CheckCircle,
  AlertTriangle
} from "lucide-react";
import { Card } from "@/components/ui/card";
import { format } from 'date-fns';
import { SystemActivity } from '@/app/lib/types';
import { cn } from "@/lib/utils";
import { Progress } from "@/components/ui/progress";

interface SystemHistoryPaneProps {
  history: SystemActivity[];
  onClear: () => void;
  onManualSave: () => void;
  onImport: () => void;
  onSyncSettings: () => void;
  connectedFileName?: string;
  needsPermission?: boolean;
  onVerifyPermission?: () => void;
  onRepairDatabase: (onProgress: (p: number) => void) => Promise<{ errorsFound: number; fixedCount: number; } | null>;
}

export function SystemHistoryPane({ 
  history, 
  onClear,
  onManualSave,
  onSyncSettings,
  connectedFileName,
  needsPermission,
  onVerifyPermission,
  onRepairDatabase
}: SystemHistoryPaneProps) {
  const [isRepairing, setIsRepairing] = useState(false);
  const [repairProgress, setRepairProgress] = useState(0);
  const [repairSummary, setRepairSummary] = useState<{ errors: number; fixed: number; } | null>(null);

  const handleRepair = async () => {
    onManualSave(); // Backup first
    setIsRepairing(true);
    setRepairSummary(null);
    setRepairProgress(0);

    try {
      const result = await onRepairDatabase((p) => setRepairProgress(p));
      if (result) {
        setRepairSummary({ errors: result.errorsFound, fixed: result.fixedCount });
      }
    } catch (e) {
      console.error("Repair failed", e);
    } finally {
      setIsRepairing(false);
    }
  };

  const getIcon = (type: string) => {
    switch (type) {
      case 'export': return <Download className="h-4 w-4" />;
      case 'import': return <FileUp className="h-4 w-4" />;
      case 'repair': return <Wrench className="h-4 w-4" />;
      case 'sync': return <RefreshCw className="h-4 w-4" />;
      default: return <Database className="h-4 w-4" />;
    }
  };

  const getColor = (type: string) => {
    switch (type) {
      case 'export': return "text-emerald-600 bg-emerald-50 dark:bg-emerald-950/20 border-emerald-100 dark:border-emerald-900/20";
      case 'import': return "text-blue-600 bg-blue-50 dark:bg-blue-950/20 border-blue-100 dark:border-blue-900/20";
      case 'repair': return "text-amber-600 bg-amber-50 dark:bg-amber-950/20 border-amber-100 dark:border-amber-900/20";
      case 'sync': return "text-primary bg-primary/5 border-primary/10";
      default: return "text-slate-600 bg-slate-50 dark:bg-slate-900/20 border-slate-100 dark:border-slate-800";
    }
  };

  return (
    <div className="h-full flex flex-col bg-background animate-in fade-in duration-500 overflow-hidden">
      {/* FIXED TOP MANAGEMENT SECTION */}
      <div className="p-2 pb-1 space-y-2 bg-muted/20 shrink-0">
        <div className="max-w-4xl mx-auto w-full">
          {/* Maintenance & Sync Row - Height Locked to 130px for proper clearance */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {/* Database Maintenance Card */}
            <Card className="p-3 border-2 border-primary/10 shadow-sm bg-card h-[130px] flex flex-col">
              <div className="flex items-center gap-2 text-primary mb-1 shrink-0">
                <Wrench className="h-4 w-4" />
                <h3 className="text-[11px] font-black uppercase tracking-widest">Database Maintenance</h3>
              </div>
              
              <div className="flex-1 flex flex-col justify-center">
                {isRepairing ? (
                  <div className="space-y-3 py-1">
                    <div className="flex justify-between items-center text-[10px] font-black uppercase text-primary">
                      <span>Optimizing Data...</span>
                      <span>{repairProgress}%</span>
                    </div>
                    <Progress value={repairProgress} className="h-2" />
                  </div>
                ) : repairSummary ? (
                  <div className="bg-background p-2 rounded-lg border border-primary/20 animate-in zoom-in-95 h-full overflow-hidden flex flex-col">
                    <div className="flex items-center gap-2 text-primary mb-1 shrink-0">
                      <CheckCircle className="h-3.5 w-3.5" />
                      <span className="text-[9px] font-black uppercase">Optimization Complete</span>
                    </div>
                    <div className="grid grid-cols-2 gap-2 mt-auto">
                      <div className="p-1 bg-muted rounded border text-center">
                        <div className="text-[12px] font-black text-foreground">{repairSummary.errors}</div>
                        <div className="text-[7px] font-bold text-muted-foreground uppercase">Errors</div>
                      </div>
                      <div className="p-1 bg-primary/5 rounded border border-primary/10 text-center">
                        <div className="text-[12px] font-black text-primary">{repairSummary.fixed}</div>
                        <div className="text-[7px] font-bold text-primary/60 uppercase">Fixed</div>
                      </div>
                    </div>
                    <Button variant="ghost" className="w-full h-6 text-[8px] font-black uppercase mt-1" onClick={() => setRepairSummary(null)}>
                      Dismiss
                    </Button>
                  </div>
                ) : (
                  <div className="mt-auto">
                    <Button onClick={handleRepair} className="w-full h-10 bg-primary/10 hover:bg-primary/20 text-primary border-2 border-primary/30 font-black text-[10px] uppercase tracking-widest shadow-sm rounded-xl">
                      <Wrench className="h-4 w-4 mr-2" /> OPTIMIZE & REPAIR
                    </Button>
                  </div>
                )}
              </div>
            </Card>

            {/* Auto Overwrite Sync Card */}
            <Card className="p-3 border-2 shadow-sm bg-card border-primary/10 h-[130px] flex flex-col">
              <div className="flex items-center gap-2 text-primary mb-1 shrink-0">
                <Database className="h-4 w-4" />
                <h3 className="text-[11px] font-black uppercase tracking-widest">Auto Overwrite Sync</h3>
              </div>
              
              <div className="flex-1 flex flex-col justify-end gap-1.5">
                <div className="p-1.5 bg-muted/30 border rounded text-[10px] font-mono text-primary break-all select-all flex items-center justify-between min-h-[32px]">
                  <span className="truncate max-w-[150px]">{connectedFileName || "No local file"}</span>
                  <div className="flex items-center">
                    {connectedFileName && !needsPermission && <CheckCircle2 className="h-3 w-3 text-primary shrink-0 ml-1" />}
                    {connectedFileName && needsPermission && <ShieldAlert className="h-3 w-3 text-amber-500 shrink-0 ml-1" />}
                    <Button onClick={onSyncSettings} variant="ghost" size="icon" className="h-5 w-5 ml-1 text-primary">
                       <RefreshCw className="h-3 w-3" />
                    </Button>
                  </div>
                </div>
                
                <div className="flex flex-col gap-1.5">
                  {needsPermission && (
                    <Button variant="destructive" size="sm" onClick={onVerifyPermission} className="w-full h-7 text-[8px] font-black uppercase animate-pulse">
                      Verify Permission
                    </Button>
                  )}
                  <Button onClick={onSyncSettings} className="w-full h-10 bg-background border-2 border-primary text-primary hover:bg-primary/5 font-black text-[10px] uppercase tracking-widest shadow-lg rounded-xl">
                    <CloudUpload className="h-4 w-4 mr-2" /> 
                    {connectedFileName ? "CHANGE FILE" : "CONNECT FILE"}
                  </Button>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </div>

      {/* SCROLLABLE SYSTEM HISTORY LOG */}
      <div className="flex-1 flex flex-col min-h-0 bg-muted/20">
        <div className="max-w-4xl mx-auto w-full flex-1 flex flex-col min-h-0 px-6">
          <div className="flex items-center gap-2 mb-2 shrink-0 pt-2">
            <History className="h-4 w-4 text-muted-foreground" />
            <h3 className="text-[11px] font-black uppercase text-muted-foreground tracking-widest">System Activity Log</h3>
          </div>
          
          <div className="flex-1 overflow-y-auto custom-scrollbar space-y-2 pb-8">
            {history.length === 0 ? (
              <div className="h-32 flex flex-col items-center justify-center text-center opacity-30">
                <Database className="h-8 w-8 text-slate-400 mb-2" />
                <p className="font-black text-[9px] uppercase tracking-widest">No activity logged yet</p>
              </div>
            ) : (
              history.map((item) => (
                <Card key={item.id} className="p-3 border-2 border-slate-100 dark:border-slate-800 hover:border-primary/20 transition-all shadow-sm bg-background group flex items-start gap-3">
                  <div className={cn("h-9 w-9 rounded-xl border flex items-center justify-center shrink-0", getColor(item.type))}>
                    {getIcon(item.type)}
                  </div>
                  <div className="flex flex-col flex-1 min-w-0">
                    <div className="flex justify-between items-center mb-0.5">
                      <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest">{format(item.timestamp, 'dd MMM yyyy • hh:mm a')}</span>
                      <span className={cn("text-[8px] font-black px-1.5 py-0.5 rounded-full uppercase", getColor(item.type))}>{item.type}</span>
                    </div>
                    <div className="text-[13px] font-bold text-foreground leading-tight">{item.details}</div>
                  </div>
                </Card>
              ))
            )}
          </div>
        </div>
      </div>

      {/* CLEAR HISTORY FOOTER */}
      {history.length > 0 && (
        <div className="h-[70px] p-3 border-t bg-background shrink-0 flex items-center justify-center">
          <Button onClick={onClear} className="w-full h-11 bg-background border-2 border-destructive text-destructive hover:bg-destructive/5 font-black text-xs uppercase tracking-[0.2em] shadow-lg flex items-center justify-center gap-2 transition-all active:scale-[0.98] rounded-xl">
            <Trash2 className="h-4 w-4" />
            CLEAR ACTIVITY LOG
          </Button>
        </div>
      )}
    </div>
  );
}

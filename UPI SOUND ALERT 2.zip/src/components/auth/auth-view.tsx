
"use client"

import { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { useAuth } from '@/firebase';
import { initiateEmailSignUp, initiateEmailSignIn } from '@/firebase/non-blocking-login';
import { LogIn, UserPlus, ShieldCheck, Loader2, AlertCircle } from 'lucide-react';
import { useToast } from "@/hooks/use-toast";

interface AuthViewProps {
  businessName: string;
}

export function AuthView({ businessName }: AuthViewProps) {
  const auth = useAuth();
  const { toast } = useToast();
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleAuthError = (error: any) => {
    setIsLoading(false);
    let message = "An error occurred during authentication.";
    if (error.code === 'auth/invalid-credential') {
      message = "Account not found or password incorrect. If this is your first time, click 'Switch to Sign Up'.";
    } else if (error.code === 'auth/email-already-in-use') {
      message = "This email is already registered. Please Login instead.";
    } else if (error.code === 'auth/weak-password') {
      message = "Password should be at least 6 characters.";
    }
    
    toast({ 
      title: "Authentication Info",
      description: message, 
      variant: "destructive" 
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) {
      toast({ description: "Please enter both email and password.", variant: "destructive" });
      return;
    }
    
    setIsLoading(true);
    if (isLogin) {
      initiateEmailSignIn(auth, email, password, handleAuthError);
    } else {
      initiateEmailSignUp(auth, email, password, handleAuthError);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-white p-4">
      <Card className="w-full max-w-[420px] shadow-2xl border-2">
        <CardHeader className="text-center space-y-1">
          <div className="h-12 w-12 bg-primary/10 text-primary rounded-full flex items-center justify-center mx-auto mb-4">
            <ShieldCheck className="h-6 w-6" />
          </div>
          <CardTitle className="text-2xl font-black uppercase tracking-tight">{businessName}</CardTitle>
          <CardDescription className="text-[11px] font-bold uppercase tracking-widest text-muted-foreground">
            {isLogin ? 'Control Station Login' : 'Register New Station'}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label className="text-[10px] font-black uppercase tracking-widest text-muted-foreground ml-1">Admin Email</Label>
              <Input 
                type="email" 
                placeholder="admin@station.com" 
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                className="h-12 font-bold border-primary/20 shadow-sm"
              />
            </div>
            <div className="space-y-2">
              <Label className="text-[10px] font-black uppercase tracking-widest text-muted-foreground ml-1">Access Key</Label>
              <Input 
                type="password" 
                placeholder="••••••••" 
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                className="h-12 font-bold border-primary/20 shadow-sm"
              />
            </div>
            <Button 
              type="submit" 
              disabled={isLoading}
              className="w-full h-14 bg-primary hover:bg-primary/90 font-black text-sm uppercase tracking-widest shadow-xl mt-4 transition-all active:scale-[0.98]"
            >
              {isLoading ? (
                <Loader2 className="h-5 w-5 animate-spin" />
              ) : isLogin ? (
                <><LogIn className="h-5 w-5 mr-2" /> Enter Station</>
              ) : (
                <><UserPlus className="h-5 w-5 mr-2" /> Initialize Account</>
              )}
            </Button>
          </form>
        </CardContent>
        <CardFooter className="flex flex-col gap-5 border-t pt-6 bg-slate-50/30">
          <div className="flex flex-col items-center gap-2">
            <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">
              {isLogin ? "Need a new account?" : "Returning Admin?"}
            </span>
            <Button 
              variant="outline" 
              size="sm" 
              onClick={() => setIsLogin(!isLogin)}
              className="w-full h-11 text-[11px] font-black uppercase tracking-widest border-2 border-primary/20 text-primary hover:bg-primary/5 shadow-sm"
            >
              {isLogin ? "Switch to Register" : "Switch to Login"}
            </Button>
          </div>
          <div className="flex items-start gap-2 p-3 bg-primary/5 rounded-lg border border-primary/10">
            <AlertCircle className="h-4 w-4 text-primary shrink-0 mt-0.5" />
            <p className="text-[9px] text-muted-foreground font-bold uppercase leading-relaxed">
              Upi Sound Alert uses encrypted cloud storage to protect your auditing history.
            </p>
          </div>
        </CardFooter>
      </Card>
    </div>
  );
}

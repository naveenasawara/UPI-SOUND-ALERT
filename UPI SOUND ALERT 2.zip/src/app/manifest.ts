
import type { MetadataRoute } from 'next'

export const dynamic = 'force-static';

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: 'Upi Sound Alert Professional',
    short_name: 'Upi Sound Alert',
    description: 'High-density financial auditing and voice alert station',
    start_url: '/',
    display: 'standalone',
    background_color: '#ffffff',
    theme_color: '#727374',
    icons: [
      {
        src: 'https://picsum.photos/seed/upisoundicon/192/192',
        sizes: '192x192',
        type: 'image/png',
      },
      {
        src: 'https://picsum.photos/seed/upisoundicon/512/512',
        sizes: '512x512',
        type: 'image/png',
      },
    ],
  }
}

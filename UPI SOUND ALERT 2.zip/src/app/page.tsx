
"use client"

import { useState, useEffect } from 'react';
import { useLedger, useUserCompanies } from '@/hooks/use-ledger';
import { AlertServicePane } from '@/components/ledger/alert-service-pane';
import { AlertHistoryPane } from '@/components/ledger/alert-history-pane';
import { AuthView } from '@/components/auth/auth-view';
import { CompanySetupWizard } from '@/components/ledger/company-setup-wizard';
import { useUser } from '@/firebase';
import { cn } from '@/lib/utils';
import { Loader2, Activity, History as HistoryIcon } from 'lucide-react';
import { useIsMobile } from '@/hooks/use-mobile';
import { 
  TooltipProvider 
} from "@/components/ui/tooltip";
import { motion, AnimatePresence } from "framer-motion";

export default function Home() {
  const { user, isUserLoading: isAuthLoading } = useUser();
  const isMobile = useIsMobile();
  
  const [mounted, setMounted] = useState(false);
  const [selectedCompanyId, setSelectedCompanyId] = useState<string | null>(null);
  const [activePanel, setActivePanel] = useState<'left' | 'right'>('left');
  const [alertLogs, setAlertLogs] = useState<any[]>([]);

  const { companies, addCompany, isLoading: isCompaniesLoading } = useUserCompanies();

  // Load persistence data
  useEffect(() => {
    setMounted(true);
    const savedCompany = localStorage.getItem('upisound_selected_company_id');
    if (savedCompany) setSelectedCompanyId(savedCompany);

    const savedLogs = localStorage.getItem('upisound_alert_history_v2');
    if (savedLogs) {
      try {
        setAlertLogs(JSON.parse(savedLogs));
      } catch (e) {
        console.error("Failed to load alert history", e);
      }
    }
  }, []);

  // Save logs whenever they change
  useEffect(() => {
    if (mounted) {
      localStorage.setItem('upisound_alert_history_v2', JSON.stringify(alertLogs));
    }
  }, [alertLogs, mounted]);

  // Save company selection
  useEffect(() => {
    if (selectedCompanyId) {
      localStorage.setItem('upisound_selected_company_id', selectedCompanyId);
    }
  }, [selectedCompanyId]);

  // Set default company if none selected but available
  useEffect(() => {
    if (!selectedCompanyId && companies.length > 0) {
      setSelectedCompanyId(companies[0].id);
    }
  }, [companies, selectedCompanyId]);

  const { 
    isLoaded, isSyncing
  } = useLedger(selectedCompanyId);

  const handleNewAlert = (log: any) => {
    setAlertLogs(prev => [log, ...prev].slice(0, 100));
  };

  const handleClearLogs = () => {
    setAlertLogs([]);
    localStorage.removeItem('upisound_alert_history_v2');
  };

  if (isAuthLoading || isCompaniesLoading || !mounted) return <div className="h-screen w-screen flex items-center justify-center bg-background"><Loader2 className="h-10 w-10 animate-spin text-primary" /></div>;
  if (!user) return <AuthView businessName="Upi Sound Alert" />;
  if (companies.length === 0) return <CompanySetupWizard onSetup={addCompany} isLoading={isSyncing} />;
  if (!isLoaded || !selectedCompanyId) return <div className="h-screen w-screen flex items-center justify-center bg-background"><Loader2 className="h-10 w-10 animate-spin text-primary" /></div>;

  return (
    <TooltipProvider delayDuration={0}>
      <div className="flex flex-col h-screen w-screen overflow-hidden bg-background">
        <main className="flex-1 flex flex-col overflow-hidden relative">
          <div className="flex-1 flex overflow-hidden relative">
            {isMobile ? (
              <motion.div 
                className="flex w-[200%] h-full"
                animate={{ x: activePanel === 'left' ? '0%' : '-50%' }}
                transition={{ type: "spring", bounce: 0, duration: 0.4 }}
              >
                <div className="w-1/2 h-full flex flex-col overflow-hidden border-r">
                  <AlertServicePane onNewAlert={handleNewAlert} />
                </div>
                <div className="w-1/2 h-full flex flex-col overflow-hidden">
                  <AlertHistoryPane logs={alertLogs} onClear={handleClearLogs} />
                </div>
              </motion.div>
            ) : (
              <div className="flex-1 flex overflow-hidden">
                <div className="w-1/2 flex flex-col min-h-0 bg-background border-r transition-all overflow-hidden h-full">
                  <AlertServicePane onNewAlert={handleNewAlert} />
                </div>
                <div className="flex-1 min-w-0 flex flex-col h-full bg-background relative">
                  <AlertHistoryPane logs={alertLogs} onClear={handleClearLogs} />
                </div>
              </div>
            )}
          </div>
        </main>

        {/* Mobile View Switcher */}
        {isMobile && (
          <nav className="h-[65px] bg-background border-t flex shrink-0 z-[100] pb-safe shadow-[0_-4px_20px_-5px_rgba(0,0,0,0.1)]">
            <button 
              onClick={() => setActivePanel('left')}
              className={cn(
                "flex-1 flex flex-col items-center justify-center gap-1 transition-all relative",
                activePanel === 'left' ? "text-primary" : "text-muted-foreground opacity-60"
              )}
            >
              {activePanel === 'left' && (
                <motion.div layoutId="activeTab" className="absolute top-0 h-0.5 w-16 bg-primary" />
              )}
              <Activity className={cn("h-5 w-5", activePanel === 'left' && "fill-primary/10")} />
              <span className="text-[10px] font-black uppercase tracking-[0.2em]">Station</span>
            </button>
            <button 
              onClick={() => setActivePanel('right')}
              className={cn(
                "flex-1 flex flex-col items-center justify-center gap-1 transition-all relative",
                activePanel === 'right' ? "text-primary" : "text-muted-foreground opacity-60"
              )}
            >
              {activePanel === 'right' && (
                <motion.div layoutId="activeTab" className="absolute top-0 h-0.5 w-16 bg-primary" />
              )}
              <div className="relative">
                <HistoryIcon className={cn("h-5 w-5", activePanel === 'right' && "fill-primary/10")} />
                {alertLogs.length > 0 && (
                  <span className="absolute -top-1.5 -right-2 h-3.5 min-w-[14px] px-1 bg-[#27ae60] text-white text-[7px] font-black rounded-full flex items-center justify-center border border-background">
                    {alertLogs.length > 99 ? '99+' : alertLogs.length}
                  </span>
                )}
              </div>
              <span className="text-[10px] font-black uppercase tracking-[0.2em]">History</span>
            </button>
          </nav>
        )}
      </div>
    </TooltipProvider>
  );
}

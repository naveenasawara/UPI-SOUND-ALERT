
export interface Company {
  id: string;
  name: string;
  logoUrl?: string;
  ownerId: string;
  members: Record<string, string>; // uid: role
  memberUids: string[]; // For efficient list querying
  createdAt: number;
  ownerName: string;
  mobile: string;
  email: string;
  address: string;
  gstNumber?: string;
  bankName?: string;
  accountNumber?: string;
  ifscCode?: string;
  branchAddress?: string;
  upiId?: string;
}

export interface Customer {
  id: string;
  companyId: string;
  name: string;
  phones: string[]; // Changed to Array
  emails: string[]; // Changed to Array
  avatarUrl?: string;
  balance: number; // Computed on client
  createdAt: number;
  isBadDebt?: boolean;
  companyMembers: Record<string, string>;
  memberUids: string[];
}

export interface LedgerEntry {
  id: string;
  companyId: string;
  customerId: string;
  date: string;
  createdAt: number;
  description: string;
  amount: number;
  type: 'payment' | 'received' | 'forward';
  runningBalance?: number;
  companyMembers: Record<string, string>;
  memberUids: string[];
}

export interface CashEntry {
  id: string;
  companyId: string;
  amount: number;
  type: 'in' | 'out';
  remark: string;
  date: string;
  createdAt: number;
  companyMembers: Record<string, string>;
  memberUids: string[];
}

export interface SystemActivity {
  id: string;
  type: 'export' | 'import' | 'repair' | 'sync';
  timestamp: number;
  details: string;
}

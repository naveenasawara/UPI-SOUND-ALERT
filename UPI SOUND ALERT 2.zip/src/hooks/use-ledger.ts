
"use client"

import { useMemo, useCallback } from 'react';
import { LedgerEntry, Customer, Company, CashEntry } from '@/app/lib/types';
import { 
  useFirestore, 
  useUser, 
  useCollection, 
  useMemoFirebase,
  setDocumentNonBlocking,
  updateDocumentNonBlocking,
  deleteDocumentNonBlocking
} from '@/firebase';
import { collection, doc, query, where } from 'firebase/firestore';
import { format } from 'date-fns';

export const formatToTitleCase = (name: string) => {
  if (!name) return "";
  return name
    .trim()
    .toLowerCase()
    .split(/\s+/)
    .map(word => word.charAt(0).toUpperCase() + word.slice(1))
    .join(' ');
};

export function useUserCompanies() {
  const db = useFirestore();
  const { user } = useUser();

  const companiesQuery = useMemoFirebase(() => {
    if (!db || !user) return null;
    return query(
      collection(db, 'companies'), 
      where('memberUids', 'array-contains', user.uid)
    );
  }, [db, user]);

  const { data: companies, isLoading } = useCollection<Company>(companiesQuery);

  const addCompany = useCallback((name: string, ownerName: string, mobile: string, address: string, email: string) => {
    if (!db || !user) return;
    const id = crypto.randomUUID();
    const newCompany: Company = {
      id,
      name: formatToTitleCase(name),
      ownerName: formatToTitleCase(ownerName),
      mobile: mobile || "",
      email: email || "",
      address: address || "",
      ownerId: user.uid,
      members: { [user.uid]: 'owner' },
      memberUids: [user.uid],
      createdAt: Date.now()
    };
    setDocumentNonBlocking(doc(db, 'companies', id), newCompany, { merge: true });
    return newCompany;
  }, [db, user]);

  const deleteCompany = useCallback((id: string) => {
    if (!db) return;
    deleteDocumentNonBlocking(doc(db, 'companies', id));
  }, [db]);

  return { companies: companies ?? [], isLoading, addCompany, deleteCompany };
}

export function useLedger(companyId: string | null = null) {
  const db = useFirestore();
  const { user, isUserLoading } = useUser();
  const { companies } = useUserCompanies();

  const currentCompany = useMemo(() => companies.find(c => c.id === companyId), [companies, companyId]);
  
  const companyMembers = useMemo(() => {
    if (currentCompany?.members && Object.keys(currentCompany.members).length > 0) {
      return currentCompany.members;
    }
    return user ? { [user.uid]: 'owner' } : {};
  }, [currentCompany, user]);

  const memberUids = useMemo(() => {
    if (currentCompany?.memberUids && currentCompany.memberUids.length > 0) {
      return currentCompany.memberUids;
    }
    return user ? [user.uid] : [];
  }, [currentCompany, user]);

  // Active Queries
  const customersQuery = useMemoFirebase(() => {
    if (!db || !companyId || !user) return null;
    return query(collection(db, 'customers'), where('companyId', '==', companyId), where('memberUids', 'array-contains', user.uid));
  }, [db, companyId, user]);

  const entriesQuery = useMemoFirebase(() => {
    if (!db || !companyId || !user) return null;
    return query(collection(db, 'ledgerEntries'), where('companyId', '==', companyId), where('memberUids', 'array-contains', user.uid));
  }, [db, companyId, user]);

  const cashQuery = useMemoFirebase(() => {
    if (!db || !companyId || !user) return null;
    return query(collection(db, 'cashLedger'), where('companyId', '==', companyId), where('memberUids', 'array-contains', user.uid));
  }, [db, companyId, user]);

  // Trash Queries
  const trashCustomersQuery = useMemoFirebase(() => {
    if (!db || !companyId || !user) return null;
    return query(collection(db, 'deleted_customers'), where('companyId', '==', companyId), where('memberUids', 'array-contains', user.uid));
  }, [db, companyId, user]);

  const trashEntriesQuery = useMemoFirebase(() => {
    if (!db || !companyId || !user) return null;
    return query(collection(db, 'deleted_ledgerEntries'), where('companyId', '==', companyId), where('memberUids', 'array-contains', user.uid));
  }, [db, companyId, user]);

  const { data: rawCustomers, isLoading: isCustomersLoading } = useCollection<Customer>(customersQuery);
  const { data: rawEntries, isLoading: isEntriesLoading } = useCollection<LedgerEntry>(entriesQuery);
  const { data: rawCashEntries } = useCollection<CashEntry>(cashQuery);
  const { data: deletedCustomers } = useCollection<Customer>(trashCustomersQuery);
  const { data: deletedEntries } = useCollection<LedgerEntry>(trashEntriesQuery);

  const entries = useMemo(() => {
    if (!rawEntries) return [];
    return [...rawEntries].filter(e => !!e.date).sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
  }, [rawEntries]);

  const cashEntries = useMemo(() => {
    if (!rawCashEntries) return [];
    return [...rawCashEntries].sort((a, b) => b.createdAt - a.createdAt);
  }, [rawCashEntries]);

  const customers = useMemo(() => {
    const balanceMap: Record<string, number> = {};
    const latestEntryMap: Record<string, LedgerEntry> = {};

    entries.forEach(entry => {
      if (entry.type !== 'forward') {
        const amount = entry.type === 'payment' ? entry.amount : -entry.amount;
        balanceMap[entry.customerId] = (balanceMap[entry.customerId] || 0) + amount;
      }
      if (!latestEntryMap[entry.customerId]) {
        latestEntryMap[entry.customerId] = entry;
      }
    });

    return (rawCustomers ?? []).map(customer => {
      const latest = latestEntryMap[customer.id];
      const isBadDebt = latest?.description?.toLowerCase().trim() === 'bad debts';
      
      const phones = (customer as any).phones || ((customer as any).phone ? [(customer as any).phone] : []);
      const emails = (customer as any).emails || ((customer as any).email ? [(customer as any).email] : []);

      return {
        ...customer,
        name: formatToTitleCase(customer.name), 
        phones,
        emails,
        balance: balanceMap[customer.id] || 0,
        createdAt: customer.createdAt || 0,
        isBadDebt: isBadDebt
      };
    });
  }, [rawCustomers, entries]);

  const addCustomer = useCallback((name: string, phones: string[], emails: string[], avatarUrl?: string) => {
    if (!db || !companyId) throw new Error("No active company");
    const id = crypto.randomUUID();
    const newCustomer: any = {
      id, companyId,
      name: formatToTitleCase(name),
      phones: phones.filter(p => !!p.trim()),
      emails: emails.filter(e => !!e.trim()),
      avatarUrl: avatarUrl || "",
      createdAt: Date.now(),
      companyMembers, memberUids
    };
    setDocumentNonBlocking(doc(db, 'customers', id), newCustomer, { merge: true });
    return { ...newCustomer, balance: 0 } as Customer;
  }, [db, companyId, companyMembers, memberUids]);

  const updateCustomer = useCallback((id: string, data: Partial<Customer>) => {
    if (!db) return;
    const sanitized = { ...data };
    if (sanitized.name) sanitized.name = formatToTitleCase(sanitized.name);
    if (sanitized.phones) sanitized.phones = sanitized.phones.filter(p => !!p.trim());
    if (sanitized.emails) sanitized.emails = sanitized.emails.filter(e => !!e.trim());
    delete (sanitized as any).balance;
    delete (sanitized as any).isBadDebt;
    setDocumentNonBlocking(doc(db, 'customers', id), sanitized, { merge: true });
  }, [db]);

  const deleteCustomer = useCallback((id: string) => {
    if (!db) return;
    const customer = customers.find(c => c.id === id);
    if (!customer) return;
    const { balance, isBadDebt, ...cleanCustomer } = customer as any;
    setDocumentNonBlocking(doc(db, 'deleted_customers', id), cleanCustomer, { merge: true });
    deleteDocumentNonBlocking(doc(db, 'customers', id));
  }, [db, customers]);

  const restoreCustomer = useCallback((id: string) => {
    if (!db || !deletedCustomers) return;
    const customer = deletedCustomers.find(c => c.id === id);
    if (!customer) return;
    setDocumentNonBlocking(doc(db, 'customers', id), customer, { merge: true });
    deleteDocumentNonBlocking(doc(db, 'deleted_customers', id));
  }, [db, deletedCustomers]);

  const permanentDeleteCustomer = useCallback((id: string) => {
    if (!db) return;
    deleteDocumentNonBlocking(doc(db, 'deleted_customers', id));
  }, [db]);

  const addEntry = useCallback((customerId: string, data: Omit<LedgerEntry, 'id' | 'customerId' | 'createdAt' | 'companyId' | 'companyMembers' | 'memberUids'>) => {
    if (!db || !companyId) return;
    const id = crypto.randomUUID();
    const newEntry: LedgerEntry = { ...data, id, companyId, customerId, createdAt: Date.now(), companyMembers, memberUids };
    setDocumentNonBlocking(doc(db, 'ledgerEntries', id), newEntry, { merge: true });
  }, [db, companyId, companyMembers, memberUids]);

  const addCashEntry = useCallback((amount: number, type: 'in' | 'out', remark: string) => {
    if (!db || !companyId) return;
    const id = crypto.randomUUID();
    const entry: CashEntry = {
      id, companyId, amount, type, remark,
      date: format(new Date(), 'yyyy-MM-dd'),
      createdAt: Date.now(),
      companyMembers, memberUids
    };
    setDocumentNonBlocking(doc(db, 'cashLedger', id), entry, { merge: true });
  }, [db, companyId, companyMembers, memberUids]);

  const updateCashEntry = useCallback((id: string, amount: number, type: 'in' | 'out', remark: string) => {
    if (!db) return;
    updateDocumentNonBlocking(doc(db, 'cashLedger', id), { amount, type, remark });
  }, [db]);

  const deleteCashEntry = useCallback((id: string) => {
    if (!db) return;
    deleteDocumentNonBlocking(doc(db, 'cashLedger', id));
  }, [db]);

  const clearCashEntries = useCallback(() => {
    if (!db || !rawCashEntries) return;
    rawCashEntries.forEach(entry => {
      deleteDocumentNonBlocking(doc(db, 'cashLedger', entry.id));
    });
  }, [db, rawCashEntries]);

  const updateEntry = useCallback((id: string, customerId: string, data: Partial<LedgerEntry>) => {
    if (!db) return;
    const sanitized = { ...data };
    delete (sanitized as any).runningBalance;
    updateDocumentNonBlocking(doc(db, 'ledgerEntries', id), sanitized);
  }, [db]);

  const deleteEntry = useCallback((id: string) => {
    if (!db) return;
    const entry = entries.find(e => e.id === id);
    if (!entry) return;
    const { runningBalance, ...cleanEntry } = entry as any;
    setDocumentNonBlocking(doc(db, 'deleted_ledgerEntries', id), cleanEntry, { merge: true });
    deleteDocumentNonBlocking(doc(db, 'ledgerEntries', id));
  }, [db, entries]);

  const restoreEntry = useCallback((id: string) => {
    if (!db || !deletedEntries) return;
    const entry = deletedEntries.find(e => e.id === id);
    if (!entry) return;
    setDocumentNonBlocking(doc(db, 'ledgerEntries', id), entry, { merge: true });
    deleteDocumentNonBlocking(doc(db, 'deleted_ledgerEntries', id));
  }, [db, deletedEntries]);

  const permanentDeleteEntry = useCallback((id: string) => {
    if (!db) return;
    deleteDocumentNonBlocking(doc(db, 'deleted_ledgerEntries', id));
  }, [db]);

  const updateCompany = useCallback((data: Partial<Company>) => {
    if (!db || !companyId) return;
    updateDocumentNonBlocking(doc(db, 'companies', companyId), data);
  }, [db, companyId]);

  return {
    customers, entries, cashEntries,
    deletedCustomers: deletedCustomers ?? [],
    deletedEntries: deletedEntries ?? [],
    addCustomer, updateCustomer, deleteCustomer, restoreCustomer, permanentDeleteCustomer,
    addEntry, updateEntry, deleteEntry, restoreEntry, permanentDeleteEntry,
    addCashEntry, updateCashEntry, deleteCashEntry, clearCashEntries,
    updateCompany,
    isSyncing: isCustomersLoading || isEntriesLoading,
    isLoaded: !isUserLoading && !!user && !isCustomersLoading && !isEntriesLoading
  };
}

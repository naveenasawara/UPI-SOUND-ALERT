'use server';
/**
 * @fileOverview This file provides an AI tool for suggesting categories for financial transactions.
 *
 * - categorizeTransaction - A function that suggests a category for a given transaction description.
 * - CategorizeTransactionInput - The input type for the categorizeTransaction function.
 * - CategorizeTransactionOutput - The return type for the categorizeTransaction function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const CategorizeTransactionInputSchema = z.object({
  description: z
    .string()
    .describe('The description of the financial transaction.'),
});
export type CategorizeTransactionInput = z.infer<
  typeof CategorizeTransactionInputSchema
>;

const CategorizeTransactionOutputSchema = z.object({
  categorySuggestion: z
    .string()
    .describe(
      'The AI-suggested category for the transaction, chosen from common financial categories like Groceries, Dining Out, Utilities, Rent/Mortgage, Transportation, Entertainment, Salary, Freelance Income, Shopping, Health, Education, Gifts, Travel, or Other.'
    ),
});
export type CategorizeTransactionOutput = z.infer<
  typeof CategorizeTransactionOutputSchema
>;

export async function categorizeTransaction(
  input: CategorizeTransactionInput
): Promise<CategorizeTransactionOutput> {
  return categorizeTransactionFlow(input);
}

const prompt = ai.definePrompt({
  name: 'categorizeTransactionPrompt',
  input: {schema: CategorizeTransactionInputSchema},
  output: {schema: CategorizeTransactionOutputSchema},
  prompt: `You are an AI financial assistant tasked with categorizing financial transactions.
Given the transaction description, suggest a single, concise category that best fits.
Choose from the following common financial categories: Groceries, Dining Out, Utilities, Rent/Mortgage, Transportation, Entertainment, Salary, Freelance Income, Shopping, Health, Education, Gifts, Travel, or Other.

Transaction Description: {{{description}}}`,
});

const categorizeTransactionFlow = ai.defineFlow(
  {
    name: 'categorizeTransactionFlow',
    inputSchema: CategorizeTransactionInputSchema,
    outputSchema: CategorizeTransactionOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);

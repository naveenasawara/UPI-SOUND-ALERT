'use server';
/**
 * @fileOverview This file implements a Genkit flow to analyze spending patterns and provide personalized insights and suggestions.
 *
 * - generateSpendingInsights - A function that handles the spending insights generation process.
 * - GenerateSpendingInsightsInput - The input type for the generateSpendingInsights function.
 * - GenerateSpendingInsightsOutput - The return type for the generateSpendingInsights function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const LedgerEntrySchema = z.object({
  date: z.string().describe('The date of the transaction in YYYY-MM-DD format.'),
  description: z.string().describe('A brief description of the transaction.'),
  amount: z.number().describe('The amount of the transaction. Positive for income, negative for expense.'),
  category: z.string().describe('The category of the transaction (e.g., "Food", "Transport", "Income").'),
});

const GenerateSpendingInsightsInputSchema = z.object({
  ledgerEntries: z.array(LedgerEntrySchema).describe('A list of financial transactions.'),
  startDate: z.string().describe('The start date for the analysis in YYYY-MM-DD format.'),
  endDate: z.string().describe('The end date for the analysis in YYYY-MM-DD format.'),
});
export type GenerateSpendingInsightsInput = z.infer<typeof GenerateSpendingInsightsInputSchema>;

const CategoryInsightSchema = z.object({
  category: z.string().describe('The category name.'),
  totalAmount: z.number().describe('The total amount spent/earned in this category.'),
  percentageOfTotal: z.number().describe('The percentage of total spending/income this category represents.'),
  insight: z.string().describe('A specific insight or observation for this category.'),
});

const GenerateSpendingInsightsOutputSchema = z.object({
  overallSummary: z.string().describe('A high-level summary of the spending patterns.'),
  categoryInsights: z.array(CategoryInsightSchema).describe('Detailed insights for each spending category.'),
  spendingPatterns: z.string().describe('Observations about spending trends over the selected period.'),
  suggestions: z.array(z.string()).describe('Actionable suggestions to improve financial habits.'),
});
export type GenerateSpendingInsightsOutput = z.infer<typeof GenerateSpendingInsightsOutputSchema>;

export async function generateSpendingInsights(input: GenerateSpendingInsightsInput): Promise<GenerateSpendingInsightsOutput> {
  return generateSpendingInsightsFlow(input);
}

const prompt = ai.definePrompt({
  name: 'generateSpendingInsightsPrompt',
  input: { schema: GenerateSpendingInsightsInputSchema },
  output: { schema: GenerateSpendingInsightsOutputSchema },
  prompt: `You are a financial analyst expert in providing personalized spending insights and suggestions.
Your task is to analyze the provided ledger entries for the period from {{{startDate}}} to {{{endDate}}} and provide comprehensive insights into the user's spending habits.

Here are the ledger entries:
{{#each ledgerEntries}}
- Date: {{{date}}}, Description: {{{description}}}, Amount: {{{amount}}}, Category: {{{category}}}
{{/each}}

Based on the data, identify:
1.  An overall summary of the spending patterns.
2.  Detailed insights for each category, including total amount spent/earned, its percentage of the total, and a specific observation.
3.  Any noticeable spending trends or patterns over the specified period.
4.  Actionable suggestions for improving financial habits.

Ensure the output strictly adheres to the provided JSON schema for GenerateSpendingInsightsOutputSchema.`,
});

const generateSpendingInsightsFlow = ai.defineFlow(
  {
    name: 'generateSpendingInsightsFlow',
    inputSchema: GenerateSpendingInsightsInputSchema,
    outputSchema: GenerateSpendingInsightsOutputSchema,
  },
  async (input) => {
    const { output } = await prompt(input);
    return output!;
  }
);

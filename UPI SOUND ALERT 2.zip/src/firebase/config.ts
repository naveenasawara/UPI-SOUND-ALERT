export const firebaseConfig = {
  "projectId": "ledger-flow-17-77799011-11916",
  "appId": "1:1067840255693:web:259f8982195daaff83db84",
  "apiKey": "AIzaSyCsQd2F1-TqiAtRKgQfwVOI77fCSRfeouY",
  "authDomain": "ledger-flow-17-77799011-11916.firebaseapp.com",
  "measurementId": "",
  "messagingSenderId": "1067840255693"
};

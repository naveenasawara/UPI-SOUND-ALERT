
# Upi Sound Alert - Automated Ledger Sync

This application is designed for professional financial tracking with mandatory automated local backups and direct file overwriting.

## MOBILE APP INSTALLATION (Android/iOS)
Upi Sound Alert is a Progressive Web App (PWA). You don't need an APK. To install:
1. **Open the App**: Open your Upi Sound Alert URL in Chrome (Android) or Safari (iOS).
2. **Install**: 
   - On **Android**: Tap the three dots (menu) and select **"Install App"** or **"Add to Home Screen"**.
   - On **iOS**: Tap the **Share** button and select **"Add to Home Screen"**.
3. **Result**: A Upi Sound Alert icon will appear on your phone. It runs in full-screen mode, just like a native app.

## RUNNING ON ANOTHER PC (Step-by-Step)
If you want to move or run this app on a different computer, follow these steps:

1.  **Install Node.js**: Download and install Node.js (Version 18.x or higher) from [nodejs.org](https://nodejs.org/).
2.  **Copy Project**: Copy this entire project folder to the new PC (e.g., using a USB drive or cloud storage).
3.  **Install Dependencies**: 
    - Open the project folder.
    - Type `cmd` in the address bar to open the terminal.
    - Run the command: `npm install`
4.  **Set Environment**: Create a file named `.env` in the root folder and add:
    `GOOGLE_GENAI_API_KEY=your_key_here`
5.  **Production Release**: To create a release build, run:
    `npm run build`
    Then start it with:
    `npm start`

## Features
- **Voice Alerts**: Hinglish TTS for incoming payment signals.
- **Direct Local Sync**: Professional file overwriting using modern browser APIs.
- **PWA Ready**: Installable on Android/iOS for full-screen mobile usage.

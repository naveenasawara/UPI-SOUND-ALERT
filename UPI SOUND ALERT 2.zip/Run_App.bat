
@echo off
title LedgerFlow Server
echo Starting LedgerFlow...
echo Please wait for the server to initialize.
start cmd /k "npm run dev"
timeout /t 5 /nobreak > nul
echo Opening LedgerFlow in your browser...
start http://localhost:9002
exit

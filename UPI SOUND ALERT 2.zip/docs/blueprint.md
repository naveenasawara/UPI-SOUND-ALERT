# **App Name**: LedgerFlow

## Core Features:

- Add/Edit Ledger Entries: Users can manually input new financial transactions with fields for date, description, amount, and category. Existing entries can be easily modified.
- View and Filter Transactions: Display a comprehensive list of all ledger entries. Users can filter entries by date range and category, and sort by amount or date.
- Delete Entry: Allow users to remove individual ledger entries permanently.
- Basic Summary & Reporting: Provide a simple overview of financial activity, showing total income and expenses for selected periods, and category-based spending totals.
- AI Categorization Tool: Utilize an AI tool to suggest appropriate categories for new entries based on the description, simplifying data input.
- AI Spending Insights Tool: An AI tool that analyzes spending patterns over time, providing personalized observations and suggestions for financial habits based on entry data.

## Style Guidelines:

- Color Palette based on clarity and trust: Primary blue: #466ABF (a stable, professional blue). Background: #F5F7FA (a light, subtly blue-tinged white for readability). Accent: #2E81AA (a cooler blue-green, providing a crisp contrast).
- Font family: 'Inter' (sans-serif) for all text elements. Chosen for its clean, neutral, and highly readable design, suitable for displaying financial data clearly across the application.
- Use a set of simple, crisp line icons to represent actions (add, edit, delete), categories, and navigation elements. Prioritize clarity and intuitive recognition.
- Maintain a clean, organized, and uncluttered layout with clear section separation for ledger entries, summaries, and input forms. Utilize ample white space to improve data readability and focus.
- Implement subtle and purposeful animations for UI feedback, such as slight fades for page transitions, gentle expansions on form field focus, and discreet loading indicators. Avoid excessive or distracting motion.
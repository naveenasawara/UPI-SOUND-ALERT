package com.upisoundalert.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
